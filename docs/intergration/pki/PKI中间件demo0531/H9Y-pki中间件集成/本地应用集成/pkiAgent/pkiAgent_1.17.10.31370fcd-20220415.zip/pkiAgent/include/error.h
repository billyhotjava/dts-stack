#ifndef ERROR_H_20200313
#define ERROR_H_20200313

#include <map>
#include <string>

namespace koal {

//通用错误信息
#define ERR_MSG_DEVICEID_INVAILD "device id is invaild"
#define ERR_MSG_CONTAINERNAME_INVAILD "container name is invaild"
#define ERR_MSG_APPNAME_INVAILD "app name is invaild"
#define ERR_MSG_TOKEN_INVAILD "token is invaild"
#define ERR_MSG_APPID_INVAILD "appid is invaild"
#define ERR_MSG_BASE64_DECODE_FAILURE "base64data decode failure"
#define ERR_MSG_BASE64_ENCODE_FAILURE "data encode base64 failure"

// device插件错误信息
#define ERR_MSG_RANDOMLEN_INVAILD "randomLen is invaild"

// enroll插件错误信息
#define ERR_MSG_B64KEYSIZE_INVAILD "b64key length is invaild"
#define ERR_MGS_KETYTYPE_INVAILD "keyType is invaild"
#define ERR_MGS_KEYLEN_INVAILD "keyLen is invaild"
#define ERR_MGS_PURPOSE_INVAILD "Purpose is invaild"

// signx插件错误信息
#define ERR_MSG_SIGNFLAG_INVAILD "signflag is invaild"
#define ERR_MSG_SIGN_TYPE "sign type is invaild"
#define ERR_MSG_ISBASE64SRCDATA "isBase64SrcData is invaild"
#define ERR_MSG_MD_TYPE "digest type is invaild"

#define ERR_OK 0
#define ERR_SUCCESS 0
#define ERR_FAILURE -1

// modules
#define ERR_COMMON 0x01000000
#define ERR_KPKISERVICE 0x02000000
#define ERR_DEVSERVICE 0x03000000
#define ERR_ENROLLSERVICE 0x04000000
#define ERR_SIGNXSERVICE 0x05000000
#define ERR_KMAILSERVICE 0x06000000

#define ERR_KEYDRIVER 0x10000000

/* TODO: 错误码统一管理，
 * 01：PKI中间件主干代码错误码
 * 02：插件
 * 03：插件
 * ...
 * 0A: 驱动错误码
 * 0E：SSL 建链错误码
 */

// 新增模块错误码暂定SSL建链模块错误码
#define ERROR_SSL_BASE 0x0E008000                        // TCP SSL通信错误
#define ERROR_SSL_VERSION_PARAM (ERROR_SSL_BASE | 0x01)  // SSL协议无效
#define ERROR_SSL_CIPHER_PARAM (ERROR_SSL_BASE | 0x02)   //错误的SSL Cipher
#define ERROR_BUF_INSUFFICIENT (ERROR_SSL_BASE | 0x03)   //传入的数据缓存区长度不够
#define ERROR_PARAM_NULL (ERROR_SSL_BASE | 0x04)         //接口调用时传入的参数为空
#define ERROR_PARAM_INVALID (ERROR_SSL_BASE | 0x05)      //接口调用时传入的参数不正确
#define ERROR_SSL_CONNECT (ERROR_SSL_BASE | 0x06)        // ssl握手失败，检查连接的ssl服务是否正常
#define ERROR_SSL_CTX_ERR (ERROR_SSL_BASE | 0x07)        //传入的sslctx上下文不正确
#define ERROR_SSL_SET_SOCKET (ERROR_SSL_BASE | 0x08)     //设置socket失败
#define ERROR_SSL_DISCONNECTED (ERROR_SSL_BASE | 0x09)   //连接已断开
#define SMF_ERROR_SSL_CONNECT_TIMEOUT (ERROR_SSL_BASE | 0x10)  // ssl握手超时，可能传入的地址不是一个正常的服务器或者服务器数据没有返回

#define ERROR_HTTP_BASE 0x0E009000                 // HTTP SSL通信错误
#define ERROR_HTTP_PARSE (ERROR_HTTP_BASE | 0x01)  //解析http失败

// thrift rpc接口对外提供的错误，根据业务情况，可以扩充这个错误码
enum rpcError {
    rpcError_ok,                        ///调用正常
    rpcError_noSession,                 /// session不存在
    rpcError_loginInvalid,              ///登录状态已注销
    rpcError_notifyExsited,             ///已经注册了Notify
    rpcError_msgTypeError,              ///消息类型错误
    rpcError_jsonBodyError,             ///消息JsonBody无效/缺少参数
    rpcError_logined,                   /// app已经登录
    rpcError_notifyTimeOut,             ///超时
    rpcError_LoginParamNotAuth,         //登录参数未授权认证
    rpcError_trustedProvAlreadySet,     //可信驱动已设置
    rpcError_trustedProvNotSet,         //可信驱动未设置
    rpcError_getLoginTempParam_failed,  //获取登录临时参数失败

    /*********************SKF标准错误码*************************/
    rpcError_key_failed = 0x0A000001,          //失败
    rpcError_key_notSupport = 0x0A000003,      //不支持的服务
    rpcError_key_errorParameter = 0x0A000006,  // 参数不正确
    rpcError_key_keyNotFound = 0x0A00001B,     //密钥未发现
    rpcError_key_certNotFound = 0x0A00001C,    //证书未发现
    rpcError_key_deviceRemoved = 0x0A000023,   //设备已移除
    rpcError_key_pinIncorrect = 0x0A000024,    // PIN不正确 0x0A000026 PIN无效
    rpcError_key_pinLocked = 0x0A000025,       // PIN被锁死
    rpcError_key_pinLengthError = 0x0A000027,  // PIN长度错误
    rpcError_key_pinTypeInvalid = 0x0A00002A,  // PIN类型错误
    rpcError_key_appExisted = 0x0A00002C,      //应用已经存在
    rpcError_key_userNotLogined = 0x0A00002D,  //用户没有登录
    rpcError_key_appNotExisted = 0x0A00002E,   //应用不存在
    rpcError_key_fileExisted = 0x0A00002F,     //文件已存在
    rpcError_key_fileNotExisted = 0x0A000031,  //文件不存在
    rpcError_key_maxContainer = 0x0A000032,    //已达到最大可管理容器数
    rpcError_key_conNotExisted = 0x0B000035,   //容器不存在
    rpcError_key_conExisted = 0x0B000036,      //容器已存在

    /*********************自定义通用错误码*************************/
    // common start with 0x0D000000
    rpcError_custom_srcDataTooLong = 0x0D000000,  // 源数据过长
    // common end with 0x0D00001F

    // 设备相关 device start with 0x0D000020
    rpcError_custom_deviceNotExisted = 0x0D000020,  // 设备不存在
    // 设备相关 device end with   0x0D00003F

    // 应用相关 app start with 0x0D000030
    rpcError_custom_appOpenFailure = 0x0D000030,  //应用打开失败
    // 应用相关 app end with 0x0D00004F

    // 容器相关 con start with 0x0D000050
    rpcError_custom_conOpenFailure = 0x0D000050,     //容器打开失败
    rpcError_custom_conNoKeyPair = 0x0D000051,       //容器中无密钥对
    rpcError_custom_enckeyPairInvaild = 0x0D000052,  //加密密钥对结构转换失败
    // 容器相关 con end with 0x0D00006F

    // PIN缓存相关 PIN cache start with 0x0D000070
    rpcError_custom_fieldEncFailure = 0x0D000070,    //字段加密失败
    rpcError_custom_fieldDecFailure = 0x0D000071,    //字段解密失败
    rpcError_custom_writeCacheFailure = 0x0D000072,  //写缓存失败
    rpcError_custom_readCacheFailure = 0x0D000073,   //读缓存失败
    // PIN缓存相关 PIN cache end with 0x0D00008F

    // 0x0E000001 自定义大类

    /*********************FIDO业务错误返回码***********************/
    rpcError_reg_failed = 0x0F000001,                  // fido注册认证失败
    rpcError_auth_failed = 0x0F000001,                 // fido用户认证失败
    rpcError_regRequest_failed = 0x0F000002,           //注册请求返回失败
    rpcError_regResponse_failed = 0x0F000003,          //注册响应请求返回失败
    rpcError_authResponse_failed = 0x0F000003,         //认证响应请求返回失败
    rpcError_logout_fido_user_failed = 0x0F000004,     // fido 注销用户请求返回失败
    rpcError_get_authRequest_failed = 0x0F000005,      // fido 获取认证请求失败
    rpcError_parse_regResponse_failed = 0x0F000006,    //解析注册请求返回数据错误
    rpcError_parse_authRequest_failed = 0x0F000007,    //解析认证请求返回数据错误
    rpcError_parse_regResp_resp_failed = 0x0F000008,   //解析注册响应请求返回数据错误
    rpcError_parse_authResp_resp_failed = 0x0F000008,  //解析认证响应请求返回数据错误
    rpcError_general_keyPaire_failed = 0x0F000009,     //生成用户密钥对失败
    rpcError_build_TLV_failed = 0x0F00000A,            //生成TLV格式数据失败
    rpcError_local_fidoInfo_notExist = 0x0F00000B,     //本地用户认证信息不存在
    rpcError_start_auth_program_failed = 0x0F00000C,   //启动生物识别程序失败
    rpcError_parse_uniSecMsg_failed = 0x0F00000D,      //解析统一托盘消息失败
    rpcError_red_devil_auth_failed = 0x0F00000E,       //红魔认证失败

    /*********************公安统一认证业务错误返回码***********************/
    rpcError_unified_usertoken_exist = 0x10000000,   //用户令牌已经存在
    rpcError_unified_auth_busy = 0x10000001,         //认证正在进行
    rpcError_get_terminfo_failed = 0x10000002,       //采集终端设备信息失败
    rpcError_get_servercfg_failed = 0x10000003,      //获取认证服务器配置失败
    rpcError_unified_login_failed = 0x10000004,      //认证登录初始化失败
    rpcError_parse_loginmsg_failed = 0x10000005,     //解析登录初始化应答失败
    rpcError_parse_userrequest_failed = 0x10000006,  //解析用户认证请求失败
    rpcError_get_usertoken_failed = 0x10000007,      //获取用户令牌请求失败
    rpcError_get_authlist_failed = 0x10000008,       //获取认证方式列表失败
    rpcError_get_dlg_auth_failed = 0x10000009,       //获取对话框认证参数失败
    rpcError_parse_usertoken_failed = 0x1000000A,    //解析获取用户令牌应答失败
    rpcError_verify_usertoken_failed = 0x1000000B,   //校验用户令牌请求失败
    rpcError_logout_usertoken_failed = 0x1000000C,   //注销用户令牌请求失败
    rpcError_usertoken_not_generated = 0x1000000D,   //用户令牌不存在
    rpcError_start_verify_auth_failed = 0x1000000E,  //启动认证界面失败
    rpcError_apptoken_not_generated = 0x1000000F,    //应用令牌不存在
    rpcError_verifyauth_not_exist = 0x10000010,      //认证客户端界面程序不存在
    rpcError_request_apptoken_failed = 0x10000011,   //请求获取应用令牌失败
    rpcError_parse_apptoken_failed = 0x10000012,     //解析应用令牌失败
    rpcError_renew_usrtoken_failed = 0x10000013,     //续期用户令牌失败
    rpcError_parse_signin_req_failed = 0x10000014,   //解析单点登录认证请求失败
    /*********************JD多认证业务错误返回码***********************/
    rpcError_jd_auth_busy = 0x10000020,                //认证正在进行
    rpcError_jd_getcredentials_failed = 0x10000021,    //获取认证凭据失败
    rpcError_request_gettoken_failed = 0x10000022,     //获取令牌请求失败
    rpcError_parse_gettoken_resp_failed = 0x10000023,  //解析获取令牌应答失败
    rpcError_jd_usertoken_exist = 0x10000024,          //用户令牌已经存在
    rpcError_jd_parsegettokenreq_failed = 0x10000025,  //解析gettoken请求失败
    rpcError_jd_startauthdlg_failed = 0x10000026,      //打开认证界面失败
    rpcError_jd_auth_method_error = 0x10000027,        //认证方式参数不正确
    rpcError_parse_auth_data_error = 0x10000028,       //解析托盘回调认证数据失败
    rpcError_parse_auth_param_error = 0x10000029,      //解析认证界面返回参数失败
    rpcError_jd_auth_user_login_error = 0x1000002A,    //认证客户端登录失败
    /*********************证书助手错误返回码***********************/
    rpcError_parameter = 0x11000001,              //参数错误
    rpcError_cds_version = 0x11000002,            //不支持的cds版本
    rpcError_open_lua = 0x11000003,               //打开lua脚本失败
    rpcError_exec_lua = 0x11000004,               //执行lua脚本失败
    rpcError_insufficient_buffer = 0x11000005,    //申请的空间不足
    rpcError_convert_object = 0x11000006,         //动态转换对象失败
    rpcError_generate_bizid = 0x11000007,         //生成bizid失败
    rpcError_no_available_dev = 0x11000008,       //本地无可用设备
    rpcError_get_common_policy = 0x11000009,      //获取通用策略失败
    rpcError_get_person_policy = 0x11000010,      //获取个人策略失败
    rpcError_parse_cds_response = 0x11000011,     //无法解析cds响应
    rpcError_cds_response_error = 0x11000012,     // cds返回失败数据
    rpcError_cds_get_fun_id = 0x11000013,         //获取url错误
    rpcError_initialize_resources = 0x11000014,   //初始化资源失败
    rpcError_local_no_cert = 0x11000015,          //本地没有找到对应的证书
    rpcError_get_authtype = 0x11000016,           //获取认证类型失败
    rpcError_key_status = 0x11000017,             //介质状态不正确
    rpcError_key_no_policy = 0x11000018,          //服务端没有配置可用介质
    rpcError_key_not_register = 0x11000019,       //不能注册介质
    rpcError_not_have_sopin = 0x11000020,         //服务端策略未返回管理员PIN
    rpcError_cert_unlock = 0x11000021,            // 解锁证书失败
    rpcError_cert_lock = 0x11000022,              //锁定证书失败
    rpcError_upload_log = 0x11000023,             //上报日志失败
    rpcError_personal_policy = 0x11000024,        //个人策略错误
    rpcError_local_no_key = 0x11000025,           // 本地没有可用介质
    rpcError_set_cds_address = 0x11000026,        //设置cds地址失败
    rpcError_register_terminal = 0x11000027,      //终端注册失败
    rpcError_curl_send_request = 0x11000028,      //发送请求失败
    rpcError_cert_status_incorrect = 0x11000029,  //证书状态错误
    rpcError_json_parson = 0x11000100,            // parson库错误
    /*********************360可信身份管控错误返回码***********************/
    rpcError_360_auth_getrandom_failed = 0x10000040,       //获取sso随机数失败
    rpcError_360_parseloginreq_failed = 0x10000041,        //解析登录请求消息失败
    rpcError_360_auth_ssologin_failed = 0x10000042,        // sso登录失败
    rpcError_360_auth_ssoinit_failed = 0x10000043,         // sso初始化失败
    rpcError_360_parse_init_resp_failed = 0x10000044,      // sso解析初始化应答失败
    rpcError_parse_getticket_req_failed = 0x10000045,      // 解析获取票据请求失败
    rpcErro_360_auth_get_ticket_failed = 0x10000046,       // 获取sso票据失败
    rpcErro_360_build_ticket_json_failed = 0x10000047,     // 构造票据json失败
    rpcError_parse_getautoticket_req_failed = 0x10000048,  // 解析获取自动登录票据请求失败
    rpcError_generate_auto_ticket_failed = 0x10000049,     // 获取自动登录票据失败
    rpcErro_build_autoticket_json_failed = 0x1000004A,     // 创建自动登录票据json失败
    rpcError_build_logout_req_failed = 0x1000004B,         // 创建注销会话请求json失败
    rpcError_360_auth_logout_failed = 0x1000004C,          // 注销会话失败
    rpcError_parse_logout_resp_failed = 0x1000004D,        // 解析注销会话应答失败
    rpcError_360_auth_renew_session_failed = 0x1000004E,   // sso续期会话失败
    rpcError_parse_renew_resp_failed = 0x1000004F,         // 解析续期会话应答失败
    rpcError_360_parse_mobilereq_failed = 0x10000050,      // 解析手机验证码请求失败
    rpcError_get_mobilecode_failed = 0x10000051,           // 获取手机验证码失败
    rpcError_parse_mobilecode_resp_failed = 0x10000052,    // 解析手机验证码应答失败
    rpcError_360_auth_random_empty = 0x10000053,           // 获取随机码为空
    rpcError_360_cert_verifypin_failed = 0x10000054,       // 证书验pin失败
    rpcError_360_random_signdata_failed = 0x10000055,      // 证书生成随机数签名失败
    rpcError_360_build_login_req_failed = 0x10000056,      // 创建登录请求失败
    rpcError_360_cert_login_failed = 0x10000057,           // 证书登录失败
    rpcError_parse_cert_login_resp_failed = 0x10000058,    // 解析证书登录应答失败
    rpcError_360_pwd_login_failed = 0x10000059,            // 口令登录失败
    rpcError_parse_pwd_login_resp_failed = 0x1000005A,     // 解析口令登录应答失败
};

#define SET_ERR_CODE(X, Y)                         \
    switch (Y) {                                   \
        case rpcError_ok: {                        \
            X = rpcError_ok;                       \
            break;                                 \
        }                                          \
        case rpcError_noSession: {                 \
            X = rpcError_noSession;                \
            break;                                 \
        }                                          \
        case rpcError_loginInvalid: {              \
            X = rpcError_loginInvalid;             \
            break;                                 \
        }                                          \
        case rpcError_notifyExsited: {             \
            X = rpcError_notifyExsited;            \
            break;                                 \
        }                                          \
        case rpcError_msgTypeError: {              \
            X = rpcError_msgTypeError;             \
            break;                                 \
        }                                          \
        case rpcError_jsonBodyError: {             \
            X = rpcError_jsonBodyError;            \
            break;                                 \
        }                                          \
        case rpcError_logined: {                   \
            X = rpcError_logined;                  \
            break;                                 \
        }                                          \
        case rpcError_key_failed: {                \
            X = rpcError_key_failed;               \
            break;                                 \
        }                                          \
        case rpcError_key_notSupport: {            \
            X = rpcError_key_notSupport;           \
            break;                                 \
        }                                          \
        case rpcError_key_keyNotFound: {           \
            X = rpcError_key_keyNotFound;          \
            break;                                 \
        }                                          \
        case rpcError_key_certNotFound: {          \
            X = rpcError_key_certNotFound;         \
            break;                                 \
        }                                          \
        case rpcError_key_pinIncorrect: {          \
            X = rpcError_key_pinIncorrect;         \
            break;                                 \
        }                                          \
        case rpcError_key_pinLocked: {             \
            X = rpcError_key_pinLocked;            \
            break;                                 \
        }                                          \
        case rpcError_key_pinLengthError: {        \
            X = rpcError_key_pinLengthError;       \
            break;                                 \
        }                                          \
        case rpcError_key_pinTypeInvalid: {        \
            X = rpcError_key_pinTypeInvalid;       \
            break;                                 \
        }                                          \
        case rpcError_key_appExisted: {            \
            X = rpcError_key_appExisted;           \
            break;                                 \
        }                                          \
        case rpcError_key_userNotLogined: {        \
            X = rpcError_key_userNotLogined;       \
            break;                                 \
        }                                          \
        case rpcError_key_appNotExisted: {         \
            X = rpcError_key_appNotExisted;        \
            break;                                 \
        }                                          \
        case rpcError_key_fileExisted: {           \
            X = rpcError_key_fileExisted;          \
            break;                                 \
        }                                          \
        case rpcError_key_fileNotExisted: {        \
            X = rpcError_key_fileNotExisted;       \
            break;                                 \
        }                                          \
        case rpcError_key_maxContainer: {          \
            X = rpcError_key_maxContainer;         \
            break;                                 \
        }                                          \
        case rpcError_key_conNotExisted: {         \
            X = rpcError_key_conNotExisted;        \
            break;                                 \
        }                                          \
        case rpcError_key_conExisted: {            \
            X = rpcError_key_conExisted;           \
            break;                                 \
        }                                          \
        case rpcError_custom_deviceNotExisted: {   \
            X = rpcError_custom_deviceNotExisted;  \
            break;                                 \
        }                                          \
        case rpcError_custom_srcDataTooLong: {     \
            X = rpcError_custom_srcDataTooLong;    \
            break;                                 \
        }                                          \
        case rpcError_custom_conNoKeyPair: {       \
            X = rpcError_custom_conNoKeyPair;      \
            break;                                 \
        }                                          \
        case rpcError_custom_enckeyPairInvaild: {  \
            X = rpcError_custom_enckeyPairInvaild; \
            break;                                 \
        }                                          \
        case rpcError_LoginParamNotAuth: {         \
            X = rpcError_LoginParamNotAuth;        \
            break;                                 \
        }                                          \
        case rpcError_trustedProvAlreadySet: {     \
            X = rpcError_trustedProvAlreadySet;    \
            break;                                 \
        }                                          \
        case rpcError_trustedProvNotSet: {         \
            X = rpcError_trustedProvNotSet;        \
            break;                                 \
        }                                          \
        case rpcError_getLoginTempParam_failed: {  \
            X = rpcError_getLoginTempParam_failed; \
            break;                                 \
        }                                          \
        default: {                                 \
            X = Y;                                 \
            break;                                 \
        }                                          \
    }

class errMgr {
   public:
    static errMgr &getInstance() {
        static errMgr err;
        return err;
    }

    const char *getErrorString(unsigned long error) {
        std::map<unsigned long, const char *>::iterator it = getInstance().mErrInfo.find(error);
        if (it != getInstance().mErrInfo.end()) {
            return getInstance().mErrInfo[error];
        } else {
            return "";
        }
    }

    bool isErrorExisted(unsigned long error) {
        std::map<unsigned long, const char *>::iterator it = mErrInfo.find(error);
        if (it != mErrInfo.end()) {
            return true;
        } else {
            return false;
        }
    }

   private:
    errMgr() {
        mErrInfo[rpcError_ok] = "successful";
        mErrInfo[rpcError_noSession] = "session is not exist, try login again";
        mErrInfo[rpcError_loginInvalid] = "the status of login is invalid, try login again";
        mErrInfo[rpcError_notifyExsited] = "notify is existed";
        mErrInfo[rpcError_msgTypeError] = "msgType is error";
        mErrInfo[rpcError_jsonBodyError] = "json body param invalid";
        mErrInfo[rpcError_logined] = "logined";
        mErrInfo[rpcError_notifyTimeOut] = "timeout";
        mErrInfo[rpcError_LoginParamNotAuth] = "login param is not authorized";
        mErrInfo[rpcError_trustedProvAlreadySet] = "trusted prov is already set";
        mErrInfo[rpcError_trustedProvNotSet] = "trusted prov not set";
        mErrInfo[rpcError_getLoginTempParam_failed] = "get Login Temp Param failed";

        mErrInfo[rpcError_key_failed] = "failed";
        mErrInfo[rpcError_key_notSupport] = "key driver not support";
        mErrInfo[rpcError_key_errorParameter] = "the parameter is incorrect";
        mErrInfo[rpcError_key_keyNotFound] = "key is not found";
        mErrInfo[rpcError_key_certNotFound] = "certification is not found";
        mErrInfo[rpcError_key_deviceRemoved] = "device removed";
        mErrInfo[rpcError_key_pinIncorrect] = "pin is incorrect";
        mErrInfo[rpcError_key_pinLocked] = "pin is locked";
        mErrInfo[rpcError_key_pinLengthError] = "pin length error";
        mErrInfo[rpcError_key_pinTypeInvalid] = "pinType is invalid";
        mErrInfo[rpcError_key_appExisted] = "appname is existed";
        mErrInfo[rpcError_key_userNotLogined] = "user is not login";
        mErrInfo[rpcError_key_appNotExisted] = "appname is not existed";
        mErrInfo[rpcError_key_fileExisted] = "file is existed";
        mErrInfo[rpcError_key_fileNotExisted] = "file is not existed";
        mErrInfo[rpcError_key_maxContainer] = "Out of maximum of container";
        mErrInfo[rpcError_key_conNotExisted] = "container is not existed";
        mErrInfo[rpcError_key_conExisted] = "container is existed";
        mErrInfo[rpcError_custom_conNoKeyPair] = "get key pair failure";

        mErrInfo[rpcError_custom_deviceNotExisted] = "device is not found";
        mErrInfo[rpcError_custom_srcDataTooLong] = "data is too long";
        mErrInfo[rpcError_custom_appOpenFailure] = "open application failure";
        mErrInfo[rpcError_custom_conOpenFailure] = "open container failure";
        mErrInfo[rpcError_custom_enckeyPairInvaild] = "encrypt Keypair invlid";

        mErrInfo[rpcError_custom_fieldEncFailure] = "field encrypt failure";
        mErrInfo[rpcError_custom_fieldDecFailure] = "field decrypt failure";
        mErrInfo[rpcError_custom_writeCacheFailure] = "write PIN cache failure";
        mErrInfo[rpcError_custom_readCacheFailure] = "read PIN cache failure";

        mErrInfo[rpcError_reg_failed] = "fido reg authoration failed";
        mErrInfo[rpcError_auth_failed] = "fido auth failed";
        mErrInfo[rpcError_regRequest_failed] = "fido reg request failed";
        mErrInfo[rpcError_regResponse_failed] = "fido reg resonse request failed";
        mErrInfo[rpcError_authResponse_failed] = "fido auth resonse request failed";
        mErrInfo[rpcError_logout_fido_user_failed] = "fido logout user failed";
        mErrInfo[rpcError_get_authRequest_failed] = "fido get auth request failed";
        mErrInfo[rpcError_parse_authRequest_failed] = "fido parse auth request return data failed";
        mErrInfo[rpcError_parse_regResponse_failed] = "fido parse reg request return data failed";
        mErrInfo[rpcError_parse_regResp_resp_failed] = "fido parse reg resp request return data failed";
        mErrInfo[rpcError_parse_authResp_resp_failed] = "fido parse auth resp request return data failed";
        mErrInfo[rpcError_general_keyPaire_failed] = "fido general user rsa key failed";
        mErrInfo[rpcError_build_TLV_failed] = "fido general tlv data failed";
        mErrInfo[rpcError_local_fidoInfo_notExist] = "fido user auth info not exist";
        mErrInfo[rpcError_start_auth_program_failed] = "fido start auth program failed";
        mErrInfo[rpcError_parse_uniSecMsg_failed] = "fido parse unisec msg failed";
        mErrInfo[rpcError_red_devil_auth_failed] = "fido the red devil auth failed";

        mErrInfo[rpcError_unified_usertoken_exist] = "ga union auth usertoken exist";
        mErrInfo[rpcError_unified_auth_busy] = "ga union auth is busing";
        mErrInfo[rpcError_get_terminfo_failed] = "ga union auth get terminfo failed";
        mErrInfo[rpcError_get_servercfg_failed] = "ga union auth get server config failed";
        mErrInfo[rpcError_unified_login_failed] = "ga union auth login failed";
        mErrInfo[rpcError_parse_loginmsg_failed] = "ga union auth parse login message failed";
        mErrInfo[rpcError_parse_userrequest_failed] = "ga union auth parse user request failed";
        mErrInfo[rpcError_get_usertoken_failed] = "ga union auth get usertoken request failed";
        mErrInfo[rpcError_get_authlist_failed] = "ga union auth get auth list failed";
        mErrInfo[rpcError_get_dlg_auth_failed] = "ga union auth get dialog auth param failed";
        mErrInfo[rpcError_parse_usertoken_failed] = "ga union auth parse usertoken response failed";
        mErrInfo[rpcError_verify_usertoken_failed] = "ga union auth verify usertoken request failed";
        mErrInfo[rpcError_logout_usertoken_failed] = "ga union auth logout usertoken request failed";
        mErrInfo[rpcError_usertoken_not_generated] = "ga union auth usertoken not generated";
        mErrInfo[rpcError_start_verify_auth_failed] = "ga union auth start verify auth failed";
        mErrInfo[rpcError_apptoken_not_generated] = "ga union auth apptoken not generated";
        mErrInfo[rpcError_verifyauth_not_exist] = "ga union auth verifyauth program not exist";
        mErrInfo[rpcError_request_apptoken_failed] = "ga union auth request apptoken failed";
        mErrInfo[rpcError_parse_apptoken_failed] = "ga union auth parse apptoken failed";
        mErrInfo[rpcError_renew_usrtoken_failed] = "ga union auth renew usrtoken failed";

        mErrInfo[rpcError_parameter] = "Parameter error";
        mErrInfo[rpcError_cds_version] = "Unsupported cds version";
        mErrInfo[rpcError_open_lua] = "Failed to open lua script";
        mErrInfo[rpcError_exec_lua] = "Failed to execute lua script";
        mErrInfo[rpcError_insufficient_buffer] = "Insufficient space for application";
        mErrInfo[rpcError_convert_object] = "Failed to dynamically convert object";
        mErrInfo[rpcError_generate_bizid] = "Failed to generate bizid";
        mErrInfo[rpcError_no_available_dev] = "No device available locally";
        mErrInfo[rpcError_get_common_policy] = "Failed to obtain general policy";
        mErrInfo[rpcError_get_person_policy] = "Failed to obtain personal strategy";
        mErrInfo[rpcError_parse_cds_response] = "Unable to parse cds response";
        mErrInfo[rpcError_cds_response_error] = "cds returns failed data";
        mErrInfo[rpcError_cds_get_fun_id] = "Get url error";
        mErrInfo[rpcError_initialize_resources] = "Failed to initialize resource";
        mErrInfo[rpcError_local_no_cert] = "The corresponding certificate was not found locally";
        mErrInfo[rpcError_get_authtype] = "Failed to obtain authentication type";
        mErrInfo[rpcError_key_status] = "Incorrect media status";
        mErrInfo[rpcError_key_no_policy] = "The server is not configured with a usable medium";
        mErrInfo[rpcError_key_not_register] = "Cannot register media";
        mErrInfo[rpcError_not_have_sopin] = "The server policy did not return the administrator PIN";
        mErrInfo[rpcError_cert_unlock] = "Failed to unlock certificate";
        mErrInfo[rpcError_cert_lock] = "Failed to lock certificate";
        mErrInfo[rpcError_upload_log] = "Failed to report log";
        mErrInfo[rpcError_personal_policy] = "Personal strategy error";
        mErrInfo[rpcError_local_no_key] = "No media available locally";
        mErrInfo[rpcError_set_cds_address] = "Failed to set cds address";
        mErrInfo[rpcError_register_terminal] = "Terminal registration failed";
        mErrInfo[rpcError_curl_send_request] = "Failed to send request";
        mErrInfo[rpcError_cert_status_incorrect] = "Certificate status error";
        mErrInfo[rpcError_json_parson] = "parson library error";

        mErrInfo[rpcError_jd_auth_busy] = "jd union auth is busing";
        mErrInfo[rpcError_jd_getcredentials_failed] = "jd union auth getcredentials failed";
        mErrInfo[rpcError_request_gettoken_failed] = "jd union auth request gettoken failed";
        mErrInfo[rpcError_parse_gettoken_resp_failed] = "jd union auth parse gettoken resp failed";
        mErrInfo[rpcError_jd_usertoken_exist] = "jd union auth uesrtoken has been existed";
        mErrInfo[rpcError_jd_parsegettokenreq_failed] = "jd union auth parse gettoken request failed";
        mErrInfo[rpcError_jd_startauthdlg_failed] = "jd union auth start auth dialog failed";
        mErrInfo[rpcError_jd_auth_method_error] = "jd union auth param incorrect";
        mErrInfo[rpcError_parse_signin_req_failed] = "jd union auth sign in auth failed";
        mErrInfo[rpcError_parse_auth_data_error] = "jd union auth parse auth data failed";
        mErrInfo[rpcError_parse_auth_param_error] = "jd union auth parse auth param failed";
        mErrInfo[rpcError_jd_auth_user_login_error] = "jd union auth user login failed";
        mErrInfo[rpcError_360_auth_getrandom_failed] = "360 trust id control get random failed";
        mErrInfo[rpcError_360_parseloginreq_failed] = "360 trust id control parse login request failed";
        mErrInfo[rpcError_360_auth_ssologin_failed] = "360 trust id control sso login failed";
        mErrInfo[rpcError_360_auth_ssoinit_failed] = "360 trust id control sso init failed";
        mErrInfo[rpcError_360_parse_init_resp_failed] = "360 trust parse init response failed";
        mErrInfo[rpcError_parse_getticket_req_failed] = "360 trust get ticket request failed";
        mErrInfo[rpcErro_360_auth_get_ticket_failed] = "360 trust get sso ticket failed";
        mErrInfo[rpcErro_360_build_ticket_json_failed] = "360 trust build ticket json failed";
        mErrInfo[rpcError_parse_getautoticket_req_failed] = "360 trust parse get auto ticket failed";
        mErrInfo[rpcError_generate_auto_ticket_failed] = "360 trust generate auto ticket failed";
        mErrInfo[rpcErro_build_autoticket_json_failed] = "360 trust build auto ticket json failed";
        mErrInfo[rpcError_build_logout_req_failed] = "360 trust build logout request json failed";
        mErrInfo[rpcError_360_auth_logout_failed] = "360 trust logout session failed";
        mErrInfo[rpcError_parse_logout_resp_failed] = "360 trust parse logout response failed";
        mErrInfo[rpcError_360_auth_renew_session_failed] = "360 trust renew session failed";
        mErrInfo[rpcError_360_parse_mobilereq_failed] = "360 trust parse mobile request failed";
        mErrInfo[rpcError_get_mobilecode_failed] = "360 trust get mobile code failed";
        mErrInfo[rpcError_parse_mobilecode_resp_failed] = "360 trust parse mobile code response failed";
        mErrInfo[rpcError_360_auth_random_empty] = "360 auth get random is empty";
        mErrInfo[rpcError_360_cert_verifypin_failed] = "360 auth cert verify pin failed";
        mErrInfo[rpcError_360_random_signdata_failed] = "360 auth generate signdata of random failed";
        mErrInfo[rpcError_360_build_login_req_failed] = "360 auth build login request failed";
        mErrInfo[rpcError_360_cert_login_failed] = "360 auth cert login failed";
        mErrInfo[rpcError_parse_cert_login_resp_failed] = "360 auth parse cert login response failed";
        mErrInfo[rpcError_360_pwd_login_failed] = "360 auth pwd login failed";
        mErrInfo[rpcError_parse_pwd_login_resp_failed] = "360 auth parse pwd login response failed";
    }

    std::map<unsigned long, const char *> mErrInfo;
};

}  // namespace koal

#endif