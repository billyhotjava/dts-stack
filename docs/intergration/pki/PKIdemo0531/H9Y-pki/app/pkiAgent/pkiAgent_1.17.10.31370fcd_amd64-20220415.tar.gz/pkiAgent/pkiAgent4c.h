/**
 * @brief PKI中间件AGENT的接口头文件
 * @author sharp
 * @email yangcp@koal.com
 */
#ifndef THIS_IS_PKIAGENT_4C_HEADER_201911261537
#define THIS_IS_PKIAGENT_4C_HEADER_201911261537

#include "agentCommon.h"
#include "byteArray.h"
#define MAX_JSON_LEN 8192

/**
 * @brief PKI中间件请求结构体
 */
struct kpkiReq {
    /// 请求ID, 登录请求reqid = 0 , 登录成功后每次请求该字段递增
    int reqid;
    /// 请求类型
    int msgType;
    /// 消息版本  body json模板的版本
    int version;
    /// 扩展 备用， 根据不同的msgType定义可能不一样
    int64 extend;
    /// JSON字符串
    char jsonBody[MAX_JSON_LEN];
    /// 动态数组
    koal::CByteArray *data;

    kpkiReq() {
        reqid = 0;
        msgType = 0;
        version = 0;
        extend = 0;
        memset(jsonBody, 0, sizeof(jsonBody));
        data = new koal::CByteArray();
    }
    ~kpkiReq() {
        if (data) {
            delete data;
            data = NULL;
        }
    }
};

/**
 * @brief PKI中间件相应
 */
struct kpkiResp {
    /// 异步请求的时候为reqAsync方法返回值
    int respid;
    /// 请求类型
    int msgType;
    /// 消息版本  body json模板的版本
    int version;
    /// 错误码，0为执行成功，
    int errCode;
    /// 扩展码
    int64 extend;
    /// json消息体, 如果errCode不为零，jsonbody = {"msg":"xxxxxxxxx"}
    char jsonBody[MAX_JSON_LEN];
    /// 动态数组
    koal::CByteArray *data;

    kpkiResp() {
        respid = 0;
        msgType = 0;
        version = 0;
        errCode = 0;
        extend = 0;
        data = new koal::CByteArray();
        memset(jsonBody, 0, sizeof(jsonBody));
    }
    ~kpkiResp() {
        if (data) delete data;
        data = NULL;
    }
};

/**
 * 服务分类
 */
enum PKI_SERVICE { ENROLLSERVICE, DEVSERVICE, SIGNXSERVICE, KMAILSERVICE, CERTQXJSERVICE, CERTTJJSERVICE, UNIAUTHSERVICE, COMMONSERVICE };

/**
 * 服务消息定义
 * kpkiReq的msgType字段赋值
 */

enum MSG_COMMMON {
    //获取版本号
    MSG_COMMMON_GETVERSIONS = 0x02,
    //获取系统信息
    MSG_COMMMON_GETSYSINFO = 0x03,
    ///设置可信驱动
    MSG_COMMMON_SETTRUSTEDDRIVES = 0x04,
    ///获取登录临时参数
    MSG_COMMON_GETLOGINTEMPPARAM = 0x05,
};

enum MSG_ENROLL {
    ///创建PKCS10 请求
    MSG_ENROLL_MKP10 = 0x20,
    ///生成密钥对
    MSG_ENROLL_KEYPAIR = 0x21,
    ///导入密钥对
    MSG_ENROLL_IMPORTKEYPAIR = 0x22,
    ///导入证书
    MSG_ENROLL_IMPORTX509 = 0x23,
    ///导入pfx证书
    MSG_ENROLL_IMPORTPFX = 0x24,
    ///导出证书
    MSG_ENROLL_GETCERT = 0x25,
    ///导入pfx证书-软设备
    MSG_ENROLL_IMPORTPFX2SKFILE = 0x26,
    /// 签发证书
    MSG_ENROLL_ISSUECERT = 0x27
};

enum MSG_DEVICE {
    ///获取设备列表
    MSG_DEVICE_GETDEVICES = 0x10,
    ///获取设备信息
    MSG_DEVICE_GETDEVINFO = 0x11,
    ///设置设备标签
    MSG_DEVICE_SETDEVLABLE = 0x12,
    ///设备命令传输
    MSG_DEVICE_TRANSMITDATA = 0x13,
    ///设备认证
    MSG_DEVICE_DEVAUTH = 0x14,
    ///修改设备认证密钥
    MSG_DEVICE_CHANGEAUTHKEY = 0x15,
    ///获取PIN
    MSG_DEVICE_GETPININFO = 0x16,
    ///修改PIN
    MSG_DEVICE_CHANGEPIN = 0x17,
    ///校验PIN
    MSG_DEVICE_VERIFYPIN = 0x18,
    ///解锁PIN码
    MSG_DEVICE_UNLOCKPIN = 0x19,
    ///获取应用列表
    MSG_DEVICE_GETAPPLIST = 0x1a,
    ///创建应用
    MSG_DEVICE_CREATEAPP = 0x1b,
    ///删除应用
    MSG_DEVICE_DELAPP = 0x1c,
    ///获取容器列表
    MSG_DEVICE_GETCONTAINERS = 0x1d,
    ///创建容器
    MSG_DEVICE_CREATECONTAINER = 0x1e,
    ///删除容器
    MSG_DEVICE_DELCONTAINER = 0x1f,
    ///获得容器类型
    MSG_DEVICE_GETCONTAINERTYPE = 0x20,
    ///导入数字证书
    MSG_DEVICE_IMPORTCERTIFICATE = 0x21,
    ///导出数字证书
    MSG_DEVICE_EXPORTCERTIFICATE = 0x22,
    ///导出公钥
    MSG_DEVICE_EXPORTPUBLICKEY = 0x23,
    ///获取Provider列表
    MSG_DEVICE_GETPROVIDERS = 0x24,
    ///设置Provider
    MSG_DEVICE_SETPROVIDER = 0x25,
    ///外来公钥加密
    MSG_DEVICE_EXTPUBKEYENCRYPT = 0x26,
    ///外来私钥解密
    MSG_DEVICE_EXTPRIKEYDECRYPT = 0x27,
    ///获取证书列表
    MSG_DEVICE_GETALLCERT = 0x28,
    ///指纹解锁
    MSG_DEVICE_UNBLOCKFINGER = 0x2f,
    ///指纹初始化
    MSG_DEVICE_INITFINGER = 0x30,
    ///是否存在指纹
    MSG_DEVICE_HASFINGER = 0x31,
    ///验证指纹
    MSG_DEVICE_VERIFYFINGER = 0x32,
    ///取消指纹
    MSG_DEVICE_CANCLEFINGER = 0x33,
    ///创建文件
    MSG_DEVICE_CERATEFILE = 0x35,
    ///删除文件
    MSG_DEVICE_DELETEFILE = 0x36,
    ///获取文件列表
    MSG_DEVICE_GETFILELIST = 0x37,
    ///获取文件信息
    MSG_DEVICE_GETFILEINFO = 0x38,
    ///读文件
    MSG_DEVICE_READFILE = 0x39,
    ///写文件
    MSG_DEVICE_WRITEFILE = 0x3a,
    ///清除应用安全状态
    MSG_DEVICE_CLEARAPPSECSTATE = 0x3b,
    /// RSA验签
    MSG_DEVICE_RSAVERIFY = 0x40,
    /// ECC验签
    MSG_DEVICE_ECCVERIFY = 0x41,
    ///生成随机数
    MSG_DEVICE_GENRANDOM = 0x42,
    ///获取缓存PIN
    MSG_DEVICE_GETCACHEDPIN = 0x51
};

enum MSG_SIGNX {
    ///数据签名
    MSG_SIGNX_SIGNDATA = 0x10,
    ///验证签名
    MSG_SIGNX_VERIFYSIGN = 0x11,
    ///数据签名P7
    MSG_SIGNX_SIGNP7 = 0x12,
    ///验证签名P7
    MSG_SIGNX_VERIFYSIGNP7 = 0x13,
    ///外部公钥ECC验签
    MSG_SIGNX_EXTECCPUBVERIFY = 0x14,
    ///外部证书ECC验签
    MSG_SIGNX_EXTECCCERTVERIFY = 0x15,
    ///根据模板生成证书
    MSG_SIGNX_MKCERTFROMTEMP = 0x16,
    ///解析证书
    MSG_SIGNX_PARSECERT = 0x17,
    ///构造P7数字信封
    MSG_SIGNX_ENVELOPEENC = 0x18,
    ///解析P7数字信封
    MSG_SIGNX_ENVELOPEDEC = 0x19,
    /// P7外部证书验签
    MSG_SIGNX_EXTECCCERTVERIFYP7 = 0x1A,
    ///获取证书拓展项
    MSG_SIGNX_GETEXTENSION = 0x1B
};

enum MSG_KMAIL {
    ///邮件加密
    MSG_KMAIL_ENCRYPT = 0x10,
    ///邮件解密
    MSG_KMAIL_DECRYPT = 0x11,
    ///添加附件
    MSG_KMAIL_ADDFILE = 0x12,
    ///保存附件
    MSG_KMAIL_SAVEFILE = 0x13,
    ///邮件签名
    MSG_KMAIL_SIGNDATA = 0x14,
    ///邮件验签
    MSG_KMAIL_VERIFY = 0x15
};

#ifdef THRFIT_SERVICE_UNIONAUTH
enum MSG_UNIONAUTH {
    /// 获取认证协议
    MSG_UNIONAUTH_GETMODULE = 0x00,
    /// 认证初始化
    MSG_UNIONAUTH_INITAUTH = 0x01,
    /// 开始认证
    MSG_UNIONAUTH_STARAUTH = 0x02,
    /// 校验认证
    MSG_UNIONAUTH_VERIFYAUTH = 0x03,
    /// 注销认证
    MSG_UNIONAUTH_CANCELAUTH = 0x04
};
#endif

#ifdef THRIFT_SERVICE_CERTHELPER
enum MSG_CERTQXJ {
    /// 注册终端
    MSG_CERTQXJ_REGISTETERMINAL = 0x20,
    /// 注册介质
    MSG_CERTQXJ_REGISTEDEVICE = 0x21,
    /// 下载通用策略
    MSG_CERTQXJ_DOWNLOADCOMMPOLICY = 0x22,
    /// 下载个人策略
    MSG_CERTQXJ_DOWNLOADPRIVACYPOLICY = 0x23,
    /// 短信验证码
    MSG_CERTQXJ_GETSMSCODE = 0x24,
    /// 图片验证码
    MSG_CERTQXJ_GETPICTURECODE = 0x25,
    /// 口令登录
    MSG_CERTQXJ_USERPWDLOGIN = 0x26,
    /// 短信登录
    MSG_CERTQXJ_USERSMSLOGIN = 0x27,
    /// 虚拟用户/正式身份用户登录接口
    MSG_CERTQXJ_USERVIRTUALORFORMALLOGIN = 0x28,
    /// 签发证书
    MSG_CERTQXJ_ISSURECERT = 0x29,
    /// 废除证书
    MSG_CERTQXJ_INVOKECERT = 0x30,
    /// 更新证书
    MSG_CERTQXJ_UPDATECERT = 0x31,
    /// 延期证书
    MSG_CERTQXJ_DELAYCERT = 0x32,
    /// 更新终端状态
    MSG_CERTQXJ_UPDATETERMINALSTATUS = 0x33,
    /// 查询终端状态
    MSG_CERTQXJ_QUERYTERMINALSTATUS = 0x34,
    /// 查询证书状态
    MSG_CERTQXJ_QUERYCERTSTATUS = 0x35,
    /// 环境修复
    MSG_CERTQXJ_REPAIRENVIROMENT = 0x36,
    /// 清除SSL状态
    MSG_CERTQXJ_CLEARSSLSESSION = 0x37,
    /// 上传日志
    MSG_CERTQXJ_REPORTLOGFILE = 0x38,
    /// 获取程序升级信息
    MSG_CERTQXJ_APPUPDATEINFO = 0x39,
    /// 推送介质插拔消息
    MSG_CERTQXJ_POPDEVNOTIFY = 0x40,
    /// 获取PIN验证状态消息
    MSG_CERTQXJ_QUERYPINSTATUS = 0x41,
    /// 设置PIN码消息
    MSG_CERTQXJ_SETPININFO = 0x42,
    /// 申请解锁证书
    MSG_CERTQXJ_APPLYUNLOCKCERT = 0x43,
    /// 执行解锁证书
    MSG_CERTQXJ_DOUNLOCKCERT = 0x44,
    /// 证书登录
    MSG_CERTQXJ_CERT_LOGIN = 0x45,
    /// 证书签名登录
    MSG_CERTQXJ_CERT_SIGN_LOGIN = 0x46,
    /// 设置CDS地址
    MSG_CERTQXJ_SET_CDS_ADDRESS = 0x47,
    /// 证书锁定
    MSG_CERTQXJ_DOLOCKCERT = 0x48,
    /// 清空缓存
    MSG_CERTQXJ_CLEAR_CACHE = 0x49,
    /// 换发证书
    MSG_CERTQXJ_RENEW_CERT = 0x50
};

enum MSG_CERTTJJ {
    /// 注册终端
    MSG_CERTTJJ_REGISTETERMINAL = 0x20,
    /// 注册介质
    MSG_CERTTJJ_REGISTEDEVICE = 0x21,
    /// 下载终端策略
    MSG_CERTTJJ_DOWNLOADTERMINALPOLICY = 0x22,
    /// 下载个人策略
    MSG_CERTTJJ_DOWNLOADPRIVACYPOLICY = 0x23,
    /// 下载SSL策略
    MSG_CERTTJJ_DOWNLOADSSLPOLICY = 0x24,
    /// 下载SSL应用扩展策略
    MSG_CERTTJJ_DOWNLOADSSLEXTPOLICY = 0x25,
    /// 图片验证码
    MSG_CERTTJJ_GETPICTURECODE = 0x26,
    /// 口令登录
    MSG_CERTTJJ_USERPWDLOGIN = 0x27,
    /// 证书登录
    MSG_CERTTJJ_CERTLOGIN = 0x28,
    /// 签发证书
    MSG_CERTTJJ_ISSUECERT = 0x29,
    /// 废除证书
    MSG_CERTTJJ_REVOKECERT = 0x30,
    /// 上传日志
    MSG_CERTTJJ_REPORTLOGFILE = 0x31,
    /// 获取升级信息
    MSG_CERTTJJ_GETUPDATEINFO = 0x32
};
#endif

///回调方法指针
typedef bool (*agentNotify)(const kpkiResp *pResp, void *pUserData);
typedef bool (*respCallBack)(const PKI_SERVICE *pSvc, const kpkiResp *pResp, void *pUserData);

/*
** @brief 获取ip
*/
std::string getServerAddress(const char *addresskeyName);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///导出接口
/**
 * @brief 初始化Agent
 * @param pcb  推送的回调方法
 * @return true 表示成功， false表示失败
 */
EXPORT_PKIAGENT bool createAgent(agentNotify pfunc, respCallBack cb, void *pUserData = NULL);

/**
 * @brief 获取中间件初始化状态
 * @return true 表示中间件初始化成功， false表示中间件初始化失败
 */
EXPORT_PKIAGENT bool getInitStat();
/**
 * @brief 应用登录
 * @param pAppName  应用名称
 * @param pAppID    应用ID
 * @param pToken    应用TOKEN
 * @return true 表示登录请求发送成功， false登录请求发送失败
 */
EXPORT_PKIAGENT bool loginAgent(const char *pAppName, const char *pAppID, const char *pToken);

/**
 * @brief 登出
 */
EXPORT_PKIAGENT bool logoutAgent();

/**
 * @brief 同步请求
 * @param svc 服务的类型
 * @param pReq 请求数据
 * @param pResp 返回数据
 * @return true 表示同步请求发送成功， false同步请求发送失败
 */
EXPORT_PKIAGENT bool reqSync(PKI_SERVICE svc, const kpkiReq *pReq, kpkiResp *pResp);

/**
 * @brief 异步请求
 * @param svc 服务的类型
 * @param pReq 请求数据
 * @param pUserData 为用户自定义数据,在回调接口里面会传入
 * @return 0标识发送异步请求失败，非0表示发送异步请求成功，返回值为resp.respid
 */
EXPORT_PKIAGENT int reqAsync(PKI_SERVICE svc, const kpkiReq *pReq, void *pUserData);

/**
 * 释放代理
 */
EXPORT_PKIAGENT void releaseAgent();

/**
 * 命令行kill进程KPKIService
 */
EXPORT_PKIAGENT void taskKill();

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#endif