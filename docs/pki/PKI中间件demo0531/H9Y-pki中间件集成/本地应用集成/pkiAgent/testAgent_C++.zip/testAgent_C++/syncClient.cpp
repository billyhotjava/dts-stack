#include "syncClient.h"
#include "pkiAgent4c.h"
#include "jsonProtocol.h"

namespace koal {
namespace testAgent {
/**
 * @description: 获取设备ID
 * @param {null}
 * @return: 设备ID
 */
std::string SyncDevice::syncGetDevID() {
    if (mDevID.empty()) {
        syncGetDevices();
    }
    return mDevID;
}

/**
 * @description: 获取设备type
 * @param {null}
 * @return: 设备type
 */
std::string SyncDevice::syncGetDevType() {
    if (mDevType.empty()) {
        syncGetDevices();
    }
    return mDevType;
}

/**
 * @description: 获取设备列表
 * @param {null}
 * @return: 0, 其他：失败
 */
int SyncDevice::syncGetDevices() {
    printf("=========================================================== getDevices\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_GETDEVICES;

    reqSync(DEVSERVICE, &req, &resp);

    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);

    std::vector<std::map<std::string, std::string> > arrayDevID;
    parseGetDevicesResponse(resp.data->getDataString(), arrayDevID);
    //提取一个devID
    std::vector<std::map<std::string, std::string> >::iterator it = arrayDevID.begin();
    if (it == arrayDevID.end()) {
        printf("without any SyncDevice, process exit\n");
        return -1;
    }
    mDevID = (*it)["devID"];
    mDevType = (*it)["devType"];
    printf("devID=%s\n", mDevID.c_str());
    printf("devType=%s\n", mDevType.c_str());
    return resp.errCode;
}

/**
 * @description: 获取设备信息
 * @param {devId} 设备ID
 * @return: 0：成功, 其他：失败
 */
int SyncDevice::syncGetDevInfo(const std::string &devId) {
    printf("=========================================================== getDevInfo\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_GETDEVINFO;

    std::string json = buildGetDevInfoReq(devId);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(DEVSERVICE, &req, &resp);
    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

/**
 * @description: 设置设备标签
 * @param {devId} 设备ID
 * @param {lable} 设备标签
 * @return: 0：成功, 其他：失败
 */
int SyncDevice::syncSetDevLable(const std::string &devId, const std::string &lable) {
    printf("=========================================================== setDevLable\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_SETDEVLABLE;

    std::string json = buildSetDevLableReq(devId, lable);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(DEVSERVICE, &req, &resp);

    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

/**
 * @description: 设备命令传输
 * @param {devId} 设备ID
 * @param {command} 用于填写与用户约定的命令号
 * @return: 0：成功, 其他：失败
 */
int SyncDevice::syncTransMitData(const std::string &devId, const std::string &command) {
    printf("=========================================================== transMitData\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_TRANSMITDATA;

    std::string json = buildTransMitDataReq(devId, command);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(DEVSERVICE, &req, &resp);
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

/**
 * @description: 设备认证
 * @param {devId} 设备ID
 * @param {authData} 认证数据(base64编码)
 * @return: 0：成功, 其他：失败
 */
int SyncDevice::syncDevAuth(const std::string &devId, const std::string &authData) {
    printf("============================================== devAuth\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_DEVAUTH;

    std::string json = buildDevAuthReq(devId, authData);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(DEVSERVICE, &req, &resp);
    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

/**
 * @description: 修改设备认证秘钥
 * @param {type} 设备ID
 * @param {type} 认证数据(base64编码)
 * @return: 0：成功, 其他：失败
 */
int SyncDevice::syncChangeAuthKey(const std::string &devId, const std::string &authData) {
    printf("============================================== changeAuthKey\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_CHANGEAUTHKEY;

    std::string json = buildChangeAuthKeyReq(devId, authData);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(DEVSERVICE, &req, &resp);
    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

/**
 * @description: 获取PIN
 * @param {devId} 设备ID
 * @param {appName} 应用名称
 * @param {PINType} PIN类型。0为ADMIN_TYPE，1为USER_TYPE
 * @return: 0：成功, 其他：失败
 */
int SyncDevice::syncGetPINInfo(const std::string &devId, const std::string &appName, const uint32 &PINType) {
    printf("============================================== getPINInfo\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_GETPININFO;

    std::string json = buildGetPINInfoReq(devId, appName, PINType);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(DEVSERVICE, &req, &resp);
    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

/**
 * @description: 修改PIN
 * @param {devId} 设备ID
 * @param {appName} 应用名称
 * @param {PINType} PIN类型。0为ADMIN_TYPE，1为USER_TYPE
 * @param {oldPIN} 旧PIN
 * @param {newPIN} 新PIN
 * @return: 0：成功, 其他：失败
 */
int SyncDevice::syncChangePIN(const std::string &devId, const std::string &appName, const uint32 &PINType, const std::string &oldPIN,
                              const std::string &newPIN) {
    printf("============================================== changePIN\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_CHANGEPIN;

    std::string json = buildChangePINReq(devId, appName, PINType, oldPIN, newPIN);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(DEVSERVICE, &req, &resp);
    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

/**
 * @description: 校验PIN
 * @param {devId} 设备ID
 * @param {appName} 应用名称
 * @param {PINType} PIN类型。0为ADMIN_TYPE，1为USER_TYPE
 * @param {PIN} PIN码
 * @return: 0：成功, 其他：失败
 */
int SyncDevice::syncVerifyPIN(const std::string &devId, const std::string &appName, const uint32 &PINType, const std::string &PIN) {
    printf("============================================== verifyPIN\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_VERIFYPIN;

    std::string json = buildVerifyPINReq(devId, appName, PINType, PIN);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(DEVSERVICE, &req, &resp);
    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

/**
 * @description: 解锁PIN码
 * @param {devId} 设备ID
 * @param {appName} 应用名称
 * @param {adminPIN} 管理员PIN
 * @param {userPIN} 用户PIN
 * @return: 0：成功, 其他：失败
 */
int SyncDevice::syncUnlockPIN(const std::string &devId, const std::string &appName, const std::string &adminPIN, const std::string &userPIN) {
    printf("============================================== unlockPIN\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_UNLOCKPIN;

    std::string json = buildUnlockPINReq(devId, appName, adminPIN, userPIN);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(DEVSERVICE, &req, &resp);
    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

/**
 * @description: 获取应用列表
 * @param {devId} 设备ID
 * @return: 0：成功, 其他：失败
 */
int SyncDevice::syncGetAppList(const std::string &devId) {
    printf("============================================== getAppList\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_GETAPPLIST;

    std::string json = buildGetAppListReq(devId);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(DEVSERVICE, &req, &resp);
    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

/**
 * @description: 创建应用
 * @param {devId} 设备ID
 * @param {appName} 应用名称
 * @param {admin_PIN} 管理员PIN
 * @param {admin_maxRetryCount} 最大重试次数
 * @param {user_PIN} 用户PIN
 * @param {user_maxRetryCount} 最大重试次数
 * @param {fileRight} 创建文件和容器的权限
 * @return: 0：成功, 其他：失败
 */
int SyncDevice::syncCreateApp(const std::string &devId, const std::string &appName, const std::string &admin_PIN, const uint32 &admin_maxRetryCount,
                              const std::string &user_PIN, const uint32 &user_maxRetryCount, const uint32 &fileRight) {
    printf("============================================== createApp\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_CREATEAPP;

    std::string json = buildCreateAppReq(devId, appName, admin_PIN, admin_maxRetryCount, user_PIN, user_maxRetryCount, fileRight);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(DEVSERVICE, &req, &resp);
    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

/**
 * @description: 删除应用
 * @param {devId} 设备ID
 * @param {appName} 应用名称
 * @return: 0：成功, 其他：失败
 */
int SyncDevice::syncDelApp(const std::string &devId, const std::string &appName) {
    printf("============================================== delApp\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_DELAPP;

    std::string json = buildDelAppReq(devId, appName);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(DEVSERVICE, &req, &resp);
    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

/**
 * @description: 获取容器列表
 * @param {devId} 设备ID
 * @param {appName} 应用名称
 * @return: 0：成功, 其他：失败
 */
int SyncDevice::syncGetContainers(const std::string &devId, const std::string &appName) {
    printf("============================================== getContainers\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_GETCONTAINERS;

    std::string json = buildGetContainersReq(devId, appName);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(DEVSERVICE, &req, &resp);
    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

/**
 * @description: 创建容器
 * @param {devId} 设备ID
 * @param {appName} 应用名称
 * @param {containerName} 容器名称
 * @return: 0：成功, 其他：失败
 */
int SyncDevice::syncCreateContainer(const std::string &devId, const std::string &appName, const std::string &containerName) {
    printf("============================================== createContainer\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_CREATECONTAINER;

    std::string json = buildCreateContainerReq(devId, appName, containerName);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(DEVSERVICE, &req, &resp);
    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

/**
 * @description: 删除容器
 * @param {devId} 设备ID
 * @param {appName} 应用名称
 * @param {containerName} 容器名称
 * @return: 0：成功, 其他：失败
 */
int SyncDevice::syncDelContainer(const std::string &devId, const std::string &appName, const std::string &containerName) {
    printf("============================================== delContainer\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_DELCONTAINER;

    std::string json = buildDelContainerReq(devId, appName, containerName);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(DEVSERVICE, &req, &resp);
    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

/**
 * @description: 获取容器类型
 * @param {devId} 设备ID
 * @param {appName} 应用名称
 * @param {containerName} 容器名称
 * @return: 0：成功, 其他：失败
 */
int SyncDevice::syncGetContainerType(const std::string &devId, const std::string &appName, const std::string &containerName) {
    printf("============================================== getContainerType\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_GETCONTAINERTYPE;

    std::string json = buildGetContainerTypeReq(devId, appName, containerName);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(DEVSERVICE, &req, &resp);
    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

/**
 * @description: 导入数字证书
 * @param {devId} 设备ID
 * @param {appName} 应用名称
 * @param {containerName} 容器名称
 * @param {signFlag} 1表示签名证书，0表示加密证书
 * @param {cert} 证书内容(base64编码)
 * @return: 0：成功, 其他：失败
 */
int SyncDevice::syncImportCertificate(const std::string &devId, const std::string &appName, const std::string &containerName, const uint32 &signFlag,
                                      const std::string &cert) {
    printf("============================================== importCertificate\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_IMPORTCERTIFICATE;

    std::string json = buildImportCertificateReq(devId, appName, containerName, signFlag, cert);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(DEVSERVICE, &req, &resp);
    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

/**
 * @description: 导出数字证书
 * @param {devId} 设备ID
 * @param {appName} 应用名称
 * @param {containerName} 容器名称
 * @param {signFlag} 1表示签名证书，0表示加密证书
 * @return: 0：成功, 其他：失败
 */
int SyncDevice::syncExportCertificate(const std::string &devId, const std::string &appName, const std::string &containerName,
                                      const uint32 &signFlag) {
    printf("============================================== exportCertificate\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_EXPORTCERTIFICATE;

    std::string json = buildExportCertificatReq(devId, appName, containerName, signFlag);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(DEVSERVICE, &req, &resp);
    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

/**
 * @description: 获取证书列表
 * @param {NULL}
 * @return: 0：成功, 其他：失败
 */
int SyncDevice::syncGetAllCert() {
    printf("============================================== GetAllCert\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_GETALLCERT;

    reqSync(DEVSERVICE, &req, &resp);
    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

/**
 * @description: 通过证书序列号获取证书列表
 * @param {NULL}
 * @return: 0：成功, 其他：失败
 */
int SyncDevice::syncGetAllCertBySN() {
    printf("============================================== GetAllCertBySN\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_GETALLCERT;

    // std::string json = "{\"includeSN\":[\"20250000000000000000001B\",\"20250000000000000000001C\"]}";
    std::string json = "{\"includeSN\":[\"20250000000000000000001B\"]}";

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(DEVSERVICE, &req, &resp);
    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

/**
 * @description: 导出公钥
 * @param {devId} 设备ID
 * @param {appName} 应用名称
 * @param {containerName} 容器名称
 * @param {signFlag} 1表示签名公钥，0表示加密公钥
 * @return: 0：成功, 其他：失败
 */
int SyncDevice::syncExportPublicKey(const std::string &devId, const std::string &appName, const std::string &containerName, const uint32 &signFlag) {
    printf("============================================== exportPublicKey\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_EXPORTPUBLICKEY;

    std::string json = buildExportPublicKeyReq(devId, appName, containerName, signFlag);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(DEVSERVICE, &req, &resp);
    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

/**
 * @description: 外来公钥加密
 * @param {devId} 设备ID
 * @param {pubKey} 公钥(base64编码)
 * @param {type} 1表示RSA,2表示ECC
 * @param {srcData} 源数据(base64编码)
 * @return: 0：成功, 其他：失败
 */
int SyncDevice::syncExtPubKeyEncrypt(const std::string &devId, const std::string &pubKey, const uint32 &type, const std::string &srcData) {
    printf("============================================== extPubKeyEncrypt\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_EXTPUBKEYENCRYPT;

    std::string json = buildExtPubKeyEncryptReq(devId, pubKey, type, srcData);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(DEVSERVICE, &req, &resp);
    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

/**
 * @description: 外来私钥解密
 * @param {devId} 设备ID
 * @param {priKey} 私钥(base64编码)
 * @param {type} 1表示RSA,2表示ECC
 * @param {encryptData} 密文数据(base64编码)
 * @return: 0：成功, 其他：失败
 */
int SyncDevice::syncExtPriKeyDecrypt(const std::string &devId, const std::string &priKey, const uint32 &type, const std::string &encryptData) {
    printf("============================================== extPriKeyDecrypt\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_EXTPRIKEYDECRYPT;

    std::string json = buildExtPriKeyDecryptReq(devId, priKey, type, encryptData);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(DEVSERVICE, &req, &resp);
    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

/**
 * @description: 获取provider列表
 * @param {NULL}
 * @return: 0：成功, 其他：失败
 */
int SyncDevice::syncGetProviders() {
    printf("============================================== getProviders\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_GETPROVIDERS;

    reqSync(DEVSERVICE, &req, &resp);

    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

/**
 * @description: 设置provider
 * @param {name} provider name
 * @param {VPID} provider VPID, like ["055C_F603","055C_F604"]
 * @return: 0：成功, 其他：失败
 */
int SyncDevice::syncSetProvider(const std::string &name, const std::string &VPID) {
    printf("============================================== setProvider\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_SETPROVIDER;

    std::string json = buildSetProviderReq(name, VPID);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(DEVSERVICE, &req, &resp);
    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

/**
 * @description:解锁指纹
 * @param {devId} 设备id
 * @param {appName} 应用名称
 * @param {type} 指纹类型
 * @return: 0：成功, 其他：失败
 */
int SyncDevice::syncUnblockFinger(const std::string &devId, const std::string &appName, const unsigned int &type) {
    printf("============================================== syncUnblockFinger\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_UNBLOCKFINGER;

    std::string json = buildUnblockFingerReq(devId, appName, type);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(DEVSERVICE, &req, &resp);
    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

/**
 * @description: 指纹初始化
 * @param {devId} 设备id
 * @param {type} 指纹类型
 * @return: 0：成功, 其他：失败
 */
int SyncDevice::syncInitFinger(const std::string &devId, const unsigned int &type) {
    printf("============================================== syncInitFinger\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_INITFINGER;

    std::string json = buildInitFingerReq(devId, type);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(DEVSERVICE, &req, &resp);
    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

/**
 * @description: 是否存在指纹
 * @param {devId} 设备id
 * @param {appName} 应用名称
 * @param {type} 指纹类型
 * @return: 0：成功, 其他：失败
 */
int SyncDevice::syncHasFinger(const std::string &devId, const std::string &appName, const unsigned int &type) {
    printf("============================================== syncHasFinger\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_HASFINGER;

    std::string json = buildHasFingerReq(devId, appName, type);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(DEVSERVICE, &req, &resp);
    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

/**
 * @description: 验证指纹
 * @param {devId} 设备id
 * @param {appName} 应用名称
 * @param {type} 指纹类型
 * @return: 0：成功, 其他：失败
 */
int SyncDevice::syncVerifyFinger(const std::string &devId, const std::string &appName, const unsigned int &type) {
    printf("============================================== syncVerifyFinger\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_VERIFYFINGER;

    std::string json = buildVerifyFingerReq(devId, appName, type);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(DEVSERVICE, &req, &resp);
    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

/**
 * @description: 取消指纹
 * @param {devId} 设备id
 * @param {type} 指纹类型
 * @return: 0：成功, 其他：失败
 */
int SyncDevice::syncCancleFinger(const std::string &devId) {
    printf("============================================== syncCancleFinger\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_CANCLEFINGER;

    std::string json = buildCancleFingerReq(devId);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(DEVSERVICE, &req, &resp);
    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

/**
 * @description: 创建文件
 * @param {devId} 设备id
 * @param {appName} 应用名
 * @param {fileName}	文件名
 * @param {fileSize} 文件大小
 * @param {readRights} 读权限
 * @param {writeRights} 写权限
 * @return: 0：成功, 其他：失败
 */
int SyncDevice::syncCreateFile(const std::string &devId, const std::string &appName, const std::string &fileName, const unsigned int &fileSize,
                               const unsigned int &readRights, const unsigned int &writeRights) {
    printf("============================================== syncCreateFile\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_CERATEFILE;

    std::string json = buildCreateFileReq(devId, appName, fileName, fileSize, readRights, writeRights);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(DEVSERVICE, &req, &resp);
    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

/**
 * @description: 删除文件
 * @param {devId} 设备id
 * @param {appName} 应用名
 * @param {fileName}	文件名
 * @return: 0：成功, 其他：失败
 */
int SyncDevice::syncDeleteFile(const std::string &devId, const std::string &appName, const std::string &fileName) {
    printf("============================================== syncDeleteFile\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_DELETEFILE;

    std::string json = buildDeleteFileReq(devId, appName, fileName);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(DEVSERVICE, &req, &resp);
    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

/**
 * @description: 获取文件列表
 * @param {devId} 设备id
 * @param {appName} 应用名
 * @return: 0：成功, 其他：失败
 */
int SyncDevice::syncGetFileList(const std::string &devId, const std::string &appName) {
    printf("============================================== syncGetFileList\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_GETFILELIST;

    std::string json = buildGetFileListReq(devId, appName);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(DEVSERVICE, &req, &resp);
    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

/**
 * @description: 获取文件属性
 * @param {devId} 设备id
 * @param {appName} 应用名
 * @param {fileName}	文件名
 * @return: 0：成功, 其他：失败
 */
int SyncDevice::syncGetFileInfo(const std::string &devId, const std::string &appName, const std::string &fileName) {
    printf("============================================== syncGetFileInfo\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_GETFILEINFO;

    std::string json = buildGetFileInfoReq(devId, appName, fileName);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(DEVSERVICE, &req, &resp);
    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

/**
 * @description: 读文件
 * @param {devId} 设备id
 * @param {appName} 应用名
 * @param {fileName}	文件名
 * @param {offset} 文件读取偏移位置
 * @param {size} 读取的长度
 * @return: 0：成功, 其他：失败
 */
int SyncDevice::syncReadFile(const std::string &devId, const std::string &appName, const std::string &fileName, const unsigned int &offset,
                             const unsigned int &size) {
    printf("============================================== syncReadFile\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_READFILE;

    std::string json = buildReadFileReq(devId, appName, fileName, offset, size);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(DEVSERVICE, &req, &resp);
    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

/**
 * @description: 写文件
 * @param {devId} 设备id
 * @param {appName} 应用名
 * @param {fileName}	文件名
 * @param {offset} 文件读取偏移位置
 * @param {data} 写入的数据
 * @return: 0：成功, 其他：失败
 */
int SyncDevice::syncWriteFile(const std::string &devId, const std::string &appName, const std::string &fileName, const unsigned int &offset,
                              const std::string &data) {
    printf("============================================== syncWriteFile\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_WRITEFILE;

    std::string json = buildWriteFileReq(devId, appName, fileName, offset, data);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(DEVSERVICE, &req, &resp);
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}
/* SyncEnRoll */

/**
 * @description: 创建P10请求
 * @param {devId} 设备ID
 * @param {appName} 应用名称
 * @param {conName} 容器名称
 * @param {dn} DN项
 * @param {extensionType} 临时密钥扩展项，1.不携带，2.携带临时密钥，其他值.协同模式
 * @return: 0：成功, 其他：失败
 */
int SyncEnRoll::syncMakePkcs10(const std::string &devId, const std::string &appName, const std::string &conName, const std::string &dn,
                               const int &extensionType, const int &reqDigst) {
    printf("============================================== makePkcs10\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_ENROLL_MKP10;

    std::string json = buildMakePkcs10Req(devId, appName, conName, dn, extensionType, reqDigst);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(ENROLLSERVICE, &req, &resp);
    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

/**
 * @description: 生成密钥对
 * @param {devId} 设备ID
 * @param {appName} 应用名称
 * @param {conName} 容器名称
 * @param {keyType} 0:SM2,1:RSA
 * @param {keyLen} KeyType为rsa时有效
 * @param {purpose} keyType为SM2时候有效（目前key不支持2）,1. SGD_SM2_1,2. SGD_SM2_3
 * @return: 0：成功, 其他：失败
 */
int SyncEnRoll::syncGenKeypair(const std::string &devId, const std::string &appName, const std::string &conName, const std::string &keyType,
                               const std::string &keyLen, const uint32 &purpose) {
    printf("============================================== genKeypair\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_ENROLL_KEYPAIR;

    std::string json = buildGenb64KeypairReq(devId, appName, conName, keyType, keyLen, purpose);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(ENROLLSERVICE, &req, &resp);
    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

/**
 * @description: 导入密钥对
 * @param {devId} 设备ID
 * @param {appName} 应用名称
 * @param {conName} 容器名称
 * @param {b64Key} 密钥对
 * @return: 0：成功, 其他：失败
 */
int SyncEnRoll::syncImportEncKeypair(const std::string &devId, const std::string &appName, const std::string &conName, const std::string &b64Key) {
    printf("============================================== importEncKeypair\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_ENROLL_IMPORTKEYPAIR;

    std::string json = buildImportEncReq(devId, appName, conName, b64Key);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(ENROLLSERVICE, &req, &resp);
    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

/**
 * @description: 导入证书
 * @param {devId} 设备ID
 * @param {appName} 应用名称
 * @param {conName} 容器名称
 * @param {tyb64certpe} 证书(base64编码)
 * @param {purpose} 1表示签名证书,0表示加密证书
 * @return: 0：成功, 其他：失败
 */
int SyncEnRoll::syncImportX509Cert(const std::string &devId, const std::string &appName, const std::string &conName, const std::string &b64cert,
                                   const std::string &purpose) {
    printf("============================================== importX509Cert\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_ENROLL_IMPORTX509;

    std::string json = buildInstallCertReq(devId, appName, conName, b64cert, purpose);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(ENROLLSERVICE, &req, &resp);
    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

/**
 * @description: 导入pfx证书
 * @param {devId} 设备ID
 * @param {appName} 应用名称
 * @param {conName} 容器名称
 * @param {b64cert} pfx证书(base64编码)
 * @param {certPass} 密码
 * @return: 0：成功, 其他：失败
 */
int SyncEnRoll::syncImportPfxCert(const std::string &devId, const std::string &appName, const std::string &conName, const std::string &b64cert,
                                  const std::string &certPass) {
    printf("============================================== importPfxCert\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_ENROLL_IMPORTPFX;

    std::string json = buildImportPfxReq(devId, appName, conName, b64cert, certPass);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(ENROLLSERVICE, &req, &resp);
    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

/**
 * @description: 导出证书
 * @param {devId} 设备ID
 * @param {appName} 应用名称
 * @param {conName} 容器名称
 * @param {certType} 1表示签名证书, 0表示加密证书
 * @return: 0：成功, 其他：失败
 */
int SyncEnRoll::syncGetCert(const std::string &devId, const std::string &appName, const std::string &conName, const std::string &certType) {
    printf("============================================== getCert\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_ENROLL_GETCERT;

    std::string json = buildGetb64certReq(devId, appName, conName, certType);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(ENROLLSERVICE, &req, &resp);
    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

/**
 * @description: 导入pfx证书到skffile
 * @param {devId} 设备ID
 * @param {appName} 应用名称
 * @param {conName} 容器名称
 * @param {b64cert} pfx证书(base64编码)
 * @param {certPass} 密码
 * @return: 0：成功, 其他：失败
 */
int SyncEnRoll::syncImportPfx2SkfFile(const std::string &devId, const std::string &appName, const std::string &conName, unsigned int signFlag,
                                      const std::string &certPass, const std::string &b64cert) {
    printf("============================================== importPfx2SkfFile\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_ENROLL_IMPORTPFX2SKFILE;

    std::string json = buildImportPfx2SkfFileReq(devId, appName, conName, signFlag, certPass, b64cert);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(ENROLLSERVICE, &req, &resp);
    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

/* SyncSignX */
/**
 * @description:  获取签名数据，用于测试
 * @param {null}
 * @return: std::string
 */
std::string &SyncSignX::syncGetSignData() { return mSignData; }

/**
 * @description: 获取签名数据，用于测试
 * @param {null}
 * @return: std::string
 */
std::string &SyncSignX::syncGetP7SignData() { return mP7SignData; }

/**
 * @description: 获取组p7数字信封数据，用于测试
 * @param {null}
 * @return: std::string
 */
std::string &SyncSignX::syncGetEnvelopeEncryptData() { return mEnvelopeEncrypt; }

/**
 * @description: 数据签名
 * @param {devId} 设备ID
 * @param {appName} 应用名称
 * @param {conName} 容器名称
 * @param {srcData} 待签名数据，base64编码
 * @param {isBase64SrcData} 是否为base64编码源数据，1表示是，0表示否
 * @param {type} 签名类型,1表示PM-BD签名,2表示SM2/RSA签名,3 SSL建链定制签名
 * @return: 0：成功, 其他：失败
 */
int SyncSignX::syncSignData(const std::string &devId, const std::string &appName, const std::string &conName, const std::string &srcData,
                            const uint32 &isBase64SrcData, const std::string &type) {
    printf("============================================== signData\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_SIGNX_SIGNDATA;

    std::string json = buildSignDataReq(devId, appName, conName, srcData, isBase64SrcData, type);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(SIGNXSERVICE, &req, &resp);
    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);

    /// 获取签名结果
    parseSignDatResp(resp.data->getDataString(), mSignData);
    return resp.errCode;
}

/**
 * @description: 验证签名
 * @param {devId} 设备ID
 * @param {appName} 应用名称
 * @param {conName} 容器名称
 * @param {srcData} 签名源数据，base64编码
 * @param {signData} 签名数据，base64编码
 * @param {isBase64SrcData} 是否为base64编码源数据，1表示是，0表示否
 * @param {type} 签名类型,1表示PM-BD验签,2表示SM2/RSA验签
 * @return: 0：成功, 其他：失败
 */
int SyncSignX::syncVerifySignData(const std::string &devId, const std::string &appName, const std::string &conName, const std::string &srcData,
                                  const std::string &signData, const uint32 &isBase64SrcData, const uint32 &type) {
    printf("============================================== verifySignData\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_SIGNX_VERIFYSIGN;

    std::string json = buildVerifyDataReq(devId, appName, conName, srcData, signData, isBase64SrcData, type);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(SIGNXSERVICE, &req, &resp);
    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

/**
 * @description: p7签名
 * @param {devId} 设备ID
 * @param {appName} 应用名称
 * @param {conName} 容器名称
 * @param {srcData} 待签名数据(base64编码)
 * @param {mdType} 0表示PKCS7_DETACHED
 * @param {attachData} 指定的摘要类型,"1"-MD5 "2"-SHA1 "3"-SM3 "4"-SHA256
 * @param {signwithSM2Std} 用于sm2签名，1表示使用SM2规范，0表示使用RFC规范，默认0
 * @return: 0：成功, 其他：失败
 */
int SyncSignX::syncSignMessage(const std::string &devId, const std::string &appName, const std::string &conName, const std::string &srcData,
                               const uint32 &mdType, const std::string &attachData, const uint32 &signwithSM2Std) {
    printf("============================================== signMessage\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_SIGNX_SIGNP7;

    std::string json = buildPkcs7SignReq(devId, appName, conName, srcData, mdType, attachData, signwithSM2Std);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(SIGNXSERVICE, &req, &resp);
    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);

    /// 获取签名结果
    parsePkcs7SignResp(resp.data->getDataString(), mP7SignData);

    return resp.errCode;
}

/**
 * @description: p7验证签名
 * @param {srcData} 签名数据的源数据(base64)
 * @param {signData} 签名数据(base64)
 * @return: 0：成功, 其他：失败
 */
int SyncSignX::syncVerifyMessage(const std::string &srcData, const std::string &signData) {
    printf("============================================== verifyMessage\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_SIGNX_VERIFYSIGNP7;

    std::string json = buildPkcs7VerifyReq(srcData, signData);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(SIGNXSERVICE, &req, &resp);
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

/**
 * @description: 外来公钥验签
 * @param {devId} 设备ID
 * @param {pubkey} 公钥
 * @param {srcData} 签名数据的源数据(base64编码)
 * @param {signData} 签名数据(base64编码)
 * @return: 0：成功, 其他：失败
 */
int SyncSignX::syncExtECCVerify(const std::string &devId, const std::string &pubkey, const std::string &srcData, const std::string &signData) {
    printf("============================================== extECCVerify\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_SIGNX_EXTECCPUBVERIFY;

    std::string json = buildExPubVerifyReq(devId, pubkey, srcData, signData);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(SIGNXSERVICE, &req, &resp);
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

/**
 * @description: 外来证书验签
 * @param {devId} 设备ID
 * @param {b64cert} 证书内容(base64)
 * @param {srcData} 签名数据的源数据(base64编码)
 * @param {signData} 签名数据(base64编码)
 * @return: 0：成功, 其他：失败
 */
int SyncSignX::syncExtECCVerifyEx(const std::string &devId, const std::string &b64cert, const std::string &srcData, const std::string &signData) {
    printf("============================================== extECCVerifyEx\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_SIGNX_EXTECCCERTVERIFY;

    std::string json = buildExCertVerifyReq(devId, b64cert, srcData, signData);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(SIGNXSERVICE, &req, &resp);
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

/**
 * @description: 生成证书
 * @param {devId} 设备ID
 * @param {appName} 应用名称
 * @param {conName} 容器名称
 * @param {signFlag} 1表示签名证书,0表示加密证书
 * @return: 0：成功, 其他：失败
 */
int SyncSignX::syncDupCertWithTemplate(const std::string &devId, const std::string &appName, const std::string &conName,
                                       const std::string &signFlag) {
    printf("============================================== dupCertWithTemplate\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_SIGNX_MKCERTFROMTEMP;

    std::string json = buildDupb64certWithTemplateReq(devId, appName, conName, signFlag);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(SIGNXSERVICE, &req, &resp);
    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

/**
 * @description: 解析证书
 * @param {cert} 证书内容(base64编码)
 * @return: 0：成功, 其他：失败
 */
int SyncSignX::syncParseCert(const std::string cert) {
    printf("============================================== parseCert\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_SIGNX_PARSECERT;

    std::string json = buildCertParseReq(cert);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(SIGNXSERVICE, &req, &resp);
    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

/**
 * @description: 组p7数字信封
 * @param {srcData} 待签名数据(base64编码)
 * @param {cert} 证书
 * @param {cihperType} 0"-DES "1"-3DES "2"-AES "3"-SM4
 * @return: 0：成功, 其他：失败
 */
int SyncSignX::syncEnvelopeEncrypt(const std::string &srcData, const std::string &cert, const uint32 &cihperType) {
    printf("============================================== envelopeEncrypt\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_SIGNX_ENVELOPEENC;

    std::string json = buildEnvelopeEncryptReq(srcData, cert, cihperType);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(SIGNXSERVICE, &req, &resp);
    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);

    parseEnvelopeEncryptResp(resp.data->getDataString(), mEnvelopeEncrypt);
    return resp.errCode;
}

/**
 * @description: 解p7数字信封
 * @param {devId} 设备ID
 * @param {appName} 应用名称
 * @param {conName} 容器名称
 * @param {srcData} 密文数据
 * @return: 0：成功, 其他：失败
 */
int SyncSignX::syncEnvelopeDecrypt(const std::string &devId, const std::string &appName, const std::string &conName, const std::string &srcData) {
    printf("============================================== envelopeDecrypt\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_SIGNX_ENVELOPEDEC;

    std::string json = buildEnvelopeDecryptReq(devId, appName, conName, srcData);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(SIGNXSERVICE, &req, &resp);
    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

/**
 * @description: p7外部证书验签
 * @param {srcData} 签名数据的源数据(base64)
 * @param {signData} 签名数据(base64)
 * @param {cert} 证书
 * @return: 0：成功, 其他：失败
 */
int SyncSignX::syncVerifySignedMessage(const std::string &srcData, const std::string &signData, const std::string &cert) {
    printf("============================================== verifySignedMessage\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_SIGNX_EXTECCCERTVERIFYP7;

    std::string json = buildVerifySignedMessageReq(srcData, signData, cert);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(SIGNXSERVICE, &req, &resp);
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

/**
 * @description: 获取证书扩展项
 * @param {cert} 证书
 * @param {oid} oid
 * @return: 0：成功, 其他：失败
 */
int SyncSignX::syncGetExtension(const std::string &cert, const std::string &oid) {
    printf("============================================== GetExtension\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_SIGNX_GETEXTENSION;

    std::string json = buildGetExtensionReq(cert, oid);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(SIGNXSERVICE, &req, &resp);
    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

#if 0
	/* kmail */

	/**
 	* @description: 设置文本主体
 	* @param {body} 文本主体
 	* @return: 0：成功, 其他：失败
 	*/ 
	int SyncKmail::syncSetTextBody(const std::string & body) {
		printf("============================================== SetTextBody\n");
		kpkiReq req;
		kpkiResp resp;
		req.reqid	= 1;
		req.version = 0x01;
		req.extend	= 0x00;
		req.msgType = MSG_KMAIL_SETTEXTBODY;

		std::string json = buildSetTextBodyReq(body);

		req.data->setSize(json.length()+1);
		strncpy((char *)req.data->getData(), json.c_str(), json.length());	

		reqSync(KMAILSERVICE, &req, &resp);
		printf("res.errCode=%#x\n", resp.errCode);
		return resp.errCode;
	}

	/**
 	* @description: 获取文本主体
 	* @return: 0：成功, 其他：失败
 	*/ 
	int SyncKmail::syncGetTextBody() {
		printf("============================================== GetTextBody\n");
		kpkiReq req;
		kpkiResp resp;
		req.reqid	= 1;
		req.version = 0x01;
		req.extend	= 0x00;
		req.msgType = MSG_KMAIL_GETTEXTBODY;

		reqSync(KMAILSERVICE, &req, &resp);
		printf("res.data=%s\n", resp.data->getDataString().c_str());
		printf("res.errCode=%#x\n", resp.errCode);
		return resp.errCode;
	}

	/**
 	* @description: 设置超文本主体
 	* @param {body} 超文本主体
 	* @return: 0：成功, 其他：失败
 	*/ 
	int SyncKmail::syncSetHtmlBody(const std::string & body) {
		printf("============================================== SetHtmlBody\n");
		kpkiReq req;
		kpkiResp resp;
		req.reqid	= 1;
		req.version = 0x01;
		req.extend	= 0x00;
		req.msgType = MSG_KMAIL_SETHTMLBODY;

		std::string json = buildSetHtmlBodyReq(body);

		req.data->setSize(json.length()+1);
		strncpy((char *)req.data->getData(), json.c_str(), json.length());	

		reqSync(KMAILSERVICE, &req, &resp);
		printf("res.errCode=%#x\n", resp.errCode);
		return resp.errCode;
	}

	/**
 	* @description: 获取超文本主体
 	* @return: 0：成功, 其他：失败
 	*/ 
	int SyncKmail::syncGetHtmlBody() {
		printf("============================================== GetHtmlBody\n");
		kpkiReq req;
		kpkiResp resp;
		req.reqid	= 1;
		req.version = 0x01;
		req.extend	= 0x00;
		req.msgType = MSG_KMAIL_GETHTMLBODY;

		reqSync(KMAILSERVICE, &req, &resp);
		printf("res.data=%s\n", resp.data->getDataString().c_str());
		printf("res.errCode=%#x\n", resp.errCode);
		return resp.errCode;
	}

	/**
 	* @description: 邮件内容组合
 	* @param {devId} 设备ID
	* @param {appName} 应用名称
	* @param {conName} 容器名称
 	* @return: 0：成功, 其他：失败
 	*/ 
	int SyncKmail::syncCompose(const std::string & devId, const std::string &appName, const std::string &conName) {
		printf("============================================== Compose\n");
		kpkiReq req;
		kpkiResp resp;
		req.reqid	= 1;
		req.version = 0x01;
		req.extend	= 0x00;
		req.msgType = MSG_KMAIL_COMPOSE;

		std::string json = buildComposeReq(devId, appName, conName);

		req.data->setSize(json.length()+1);
		strncpy((char *)req.data->getData(), json.c_str(), json.length());	

		reqSync(KMAILSERVICE, &req, &resp);
		printf("res.data=%s\n", resp.data->getDataString().c_str());
		printf("res.errCode=%#x\n", resp.errCode);
		return resp.errCode;
	}

	/**
 	* @description: 获取指定索引的数据包
 	* @param {index} 索引
 	* @return: 0：成功, 其他：失败
 	*/ 
	int SyncKmail::syncGetComposedData(const unsigned int & index) {
		printf("============================================== GetComposedData\n");
		kpkiReq req;
		kpkiResp resp;
		req.reqid	= 1;
		req.version = 0x01;
		req.extend	= 0x00;
		req.msgType = MSG_KMAIL_GETCOMPOSEDDATA;

		std::string json = buildGetComposedDataReq(index);

		req.data->setSize(json.length()+1);
		strncpy((char *)req.data->getData(), json.c_str(), json.length());	

		reqSync(KMAILSERVICE, &req, &resp);
		printf("res.data=%s\n", resp.data->getDataString().c_str());
		printf("res.errCode=%#x\n", resp.errCode);
		return resp.errCode;
	}

	/**
 	* @description: 准备解析邮件内容
 	* @param {index} 索引
	* @param {mail} 邮件内容
 	* @return: 0：成功, 其他：失败
 	*/ 
	int SyncKmail::syncPrepareParse(const unsigned int & index, const std::string &mail) {
		printf("============================================== PrepareParse\n");
		kpkiReq req;
		kpkiResp resp;
		req.reqid	= 1;
		req.version = 0x01;
		req.extend	= 0x00;
		req.msgType = MSG_KMAIL_PREPAREPARSE;

		std::string json = buildPrepareParseReq(index, mail);

		req.data->setSize(json.length()+1);
		strncpy((char *)req.data->getData(), json.c_str(), json.length());	

		reqSync(KMAILSERVICE, &req, &resp);
		printf("res.errCode=%#x\n", resp.errCode);
		return resp.errCode;
	}

	/**
 	* @description: 解析邮件内容
 	* @param {devId} 设备id
	* @param {appName} 应用名称
	* @param {conName} 容器名称
 	* @return: 0：成功, 其他：失败
 	*/ 
	int SyncKmail::syncParse(const std::string & devId, const std::string &appName, const std::string &conName) {
		printf("============================================== Parse\n");
		kpkiReq req;
		kpkiResp resp;
		req.reqid	= 1;
		req.version = 0x01;
		req.extend	= 0x00;
		req.msgType = MSG_KMAIL_PARSE;

		std::string json = buildParseReq(devId, appName, conName);

		req.data->setSize(json.length()+1);
		strncpy((char *)req.data->getData(), json.c_str(), json.length());	

		reqSync(KMAILSERVICE, &req, &resp);
		printf("res.data=%s\n", resp.data->getDataString().c_str());
		printf("res.errCode=%#x\n", resp.errCode);
		return resp.errCode;
	}

	/**
 	* @description: 清除邮件相关信息
 	* @return: 0：成功, 其他：失败
 	*/ 
	int SyncKmail::syncClear() {
		printf("============================================== Clear\n");
		kpkiReq req;
		kpkiResp resp;
		req.reqid	= 1;
		req.version = 0x01;
		req.extend	= 0x00;
		req.msgType = MSG_KMAIL_CLEAR;

		reqSync(KMAILSERVICE, &req, &resp);
		printf("res.errCode=%#x\n", resp.errCode);
		return resp.errCode;
	}

	/**
 	* @description: 添加附件
 	* @param {fileInfo} 附件信息
 	* @return: 0：成功, 其他：失败
 	*/ 
	int SyncKmail::syncAddAttachFile(const std::string fileInfo) {
		printf("============================================== AddAttachFile\n");
		kpkiReq req;
		kpkiResp resp;
		req.reqid	= 1;
		req.version = 0x01;
		req.extend	= 0x00;
		req.msgType = MSG_KMAIL_ADDATTACHFILE;

		std::string json = buildAddAttachFileReq(fileInfo);

		req.data->setSize(json.length()+1);
		strncpy((char *)req.data->getData(), json.c_str(), json.length());	

		reqSync(KMAILSERVICE, &req, &resp);
		printf("res.errCode=%#x\n", resp.errCode);
		return resp.errCode;
	}

	/**
 	* @description: 获取附件数量
 	* @return: 0：成功, 其他：失败
 	*/ 
	int SyncKmail::syncGetAttachCount() {
		printf("============================================== GetAttachCount\n");
		kpkiReq req;
		kpkiResp resp;
		req.reqid	= 1;
		req.version = 0x01;
		req.extend	= 0x00;
		req.msgType = MSG_KMAIL_GETATTACHCOUNT;

		reqSync(KMAILSERVICE, &req, &resp);
		printf("res.data=%s\n", resp.data->getDataString().c_str());
		printf("res.errCode=%#x\n", resp.errCode);
		return resp.errCode;
	}

	/**
 	* @description: 获取指定附件信息
 	* @param {index} 索引
 	* @return: 0：成功, 其他：失败
 	*/ 
	int SyncKmail::syncGetAttachFileInfo(const unsigned int & index) {
		printf("============================================== GetAttachFileInfo\n");
		kpkiReq req;
		kpkiResp resp;
		req.reqid	= 1;
		req.version = 0x01;
		req.extend	= 0x00;
		req.msgType = MSG_KMAIL_GETATTACHFILEINFO;

		std::string json = buildGetAttachFileInfoReq(index);

		req.data->setSize(json.length()+1);
		strncpy((char *)req.data->getData(), json.c_str(), json.length());	

		reqSync(KMAILSERVICE, &req, &resp);
		printf("res.data=%s\n", resp.data->getDataString().c_str());
		printf("res.errCode=%#x\n", resp.errCode);
		return resp.errCode;
	}

	/**
 	* @description: 指定附件另存为
 	* @param {index} 索引
	* @param {filePath} 文件路径
 	* @return: 0：成功, 其他：失败
 	*/ 
	int SyncKmail::syncDoAttachSaveAs(const unsigned int & index, const std::string & filePath) {
		printf("============================================== DoAttachSaveAs\n");
		kpkiReq req;
		kpkiResp resp;
		req.reqid	= 1;
		req.version = 0x01;
		req.extend	= 0x00;
		req.msgType = MSG_KMAIL_DOATTACHSAVEAS;

		std::string json = buildDoAttachSaveAsReq(index, filePath);

		req.data->setSize(json.length()+1);
		strncpy((char *)req.data->getData(), json.c_str(), json.length());	

		reqSync(KMAILSERVICE, &req, &resp);
		printf("res.errCode=%#x\n", resp.errCode);
		return resp.errCode;
	}

	/**
 	* @description: 获取指定附件的指定扩展字段
 	* @param {index} 索引
 	* @return: 0：成功, 其他：失败
 	*/ 
	int SyncKmail::syncGetAttachFieldInfo(const unsigned int & index) {
		printf("============================================== GetAttachFieldInfo\n");
		kpkiReq req;
		kpkiResp resp;
		req.reqid	= 1;
		req.version = 0x01;
		req.extend	= 0x00;
		req.msgType = MSG_KMAIL_GETATTACHFIELDINFO;

		std::string json = buildGetAttachFieldInfoReq(index);

		req.data->setSize(json.length()+1);
		strncpy((char *)req.data->getData(), json.c_str(), json.length());	

		reqSync(KMAILSERVICE, &req, &resp);
		printf("res.data=%s\n", resp.data->getDataString().c_str());
		printf("res.errCode=%#x\n", resp.errCode);
		return resp.errCode;
	}

	/**
 	* @description: 设置邮件类型
 	* @param {type} 邮件类型
 	* @return: 0：成功, 其他：失败
 	*/ 
	int SyncKmail::syncSetMailType(const unsigned int & type) {
		printf("============================================== SetMailType\n");
		kpkiReq req;
		kpkiResp resp;
		req.reqid	= 1;
		req.version = 0x01;
		req.extend	= 0x00;
		req.msgType = MSG_KMAIL_SETMAILTYPE;

		std::string json = buildSetMailTypeReq(type);

		req.data->setSize(json.length()+1);
		strncpy((char *)req.data->getData(), json.c_str(), json.length());	

		reqSync(KMAILSERVICE, &req, &resp);
		printf("res.errCode=%#x\n", resp.errCode);
		return resp.errCode;
	}

	/**
 	* @description: 获取邮件类型
 	* @return: 0：成功, 其他：失败
 	*/ 
	int SyncKmail::syncGetMailType() {
		printf("============================================== GetMailType\n");
		kpkiReq req;
		kpkiResp resp;
		req.reqid	= 1;
		req.version = 0x01;
		req.extend	= 0x00;
		req.msgType = MSG_KMAIL_GETMAILTYPE;

		reqSync(KMAILSERVICE, &req, &resp);
		printf("res.data=%s\n", resp.data->getDataString().c_str());
		printf("res.errCode=%#x\n", resp.errCode);
		return resp.errCode;
	}

	/**
 	* @description: 设置加密证书
 	* @param {encCert} 证书内容
 	* @return: 0：成功, 其他：失败
 	*/ 
	int SyncKmail::syncSetEncCerts(const std::string & encCert) {
		printf("============================================== SetEncCerts\n");
		kpkiReq req;
		kpkiResp resp;
		req.reqid	= 1;
		req.version = 0x01;
		req.extend	= 0x00;
		req.msgType = MSG_KMAIL_SETENCCERTS;

		std::string json = buildSetEncCerts(encCert);

		req.data->setSize(json.length()+1);
		strncpy((char *)req.data->getData(), json.c_str(), json.length());	

		reqSync(KMAILSERVICE, &req, &resp);
		printf("res.errCode=%#x\n", resp.errCode);
		return resp.errCode;
	}

	/**
 	* @description: 获取邮件中的签名证书
 	* @return: 0：成功, 其他：失败
 	*/ 
	int SyncKmail::syncGetMailSigner() {
		printf("============================================== GetMailSigner\n");
		kpkiReq req;
		kpkiResp resp;
		req.reqid	= 1;
		req.version = 0x01;
		req.extend	= 0x00;
		req.msgType = MSG_KMAIL_GETMAILSIGNER;

		reqSync(KMAILSERVICE, &req, &resp);
		printf("res.data=%s\n", resp.data->getDataString().c_str());
		printf("res.errCode=%#x\n", resp.errCode);
		return resp.errCode;
	}

	/**
 	* @description: 获取指定容器的签名证书
 	* @param {devId} 设备ID
	* @param {appName} 应用名称
	* @param {conName} 容器名称
 	* @return: 0：成功, 其他：失败
 	*/ 
	int SyncKmail::syncGetSignCert(const std::string & devId, const std::string &appName, const std::string &conName) {
		printf("============================================== GetSignCert\n");
		kpkiReq req;
		kpkiResp resp;
		req.reqid	= 1;
		req.version = 0x01;
		req.extend	= 0x00;
		req.msgType = MSG_KMAIL_GETSIGNCERT;

		std::string json = buildGetSignCertReq(devId, appName, conName);

		req.data->setSize(json.length()+1);
		strncpy((char *)req.data->getData(), json.c_str(), json.length());	

		reqSync(KMAILSERVICE, &req, &resp);
		printf("res.data=%s\n", resp.data->getDataString().c_str());
		printf("res.errCode=%#x\n", resp.errCode);
		return resp.errCode;
	}

	/**
 	* @description: 获取证书中的指定项的值
 	* @param {certb64} 证书内容
	* @param {key} 指定项
 	* @return: 0：成功, 其他：失败
 	*/ 
	int SyncKmail::syncGetCertItem(const std::string & certb64, const std::string & key) {
		printf("============================================== GetCertItem\n");
		kpkiReq req;
		kpkiResp resp;
		req.reqid	= 1;
		req.version = 0x01;
		req.extend	= 0x00;
		req.msgType = MSG_KMAIL_GETCERTITEM;

		std::string json = buildGetCertItemReq(certb64, key);

		req.data->setSize(json.length()+1);
		strncpy((char *)req.data->getData(), json.c_str(), json.length());	

		reqSync(KMAILSERVICE, &req, &resp);
		printf("res.data=%s\n", resp.data->getDataString().c_str());
		printf("res.errCode=%#x\n", resp.errCode);
		return resp.errCode;
	}

	/**
 	* @description: 签名
 	* @param {devId} 设备ID
	* @param {appName} 应用名称
	* @param {conName} 容器名称
	* @param {srcData} 待签名数据
	* @param {type} 1表示PM-BD签名,2表示SM2/RSA签名
 	* @return: 0：成功, 其他：失败
 	*/ 
	int SyncKmail::syncSignData(const std::string & devId, const std::string &appName, const std::string &conName,
		const std::string & srcData, const unsigned int & type) {
		printf("============================================== SignData\n");
		kpkiReq req;
		kpkiResp resp;
		req.reqid	= 1;
		req.version = 0x01;
		req.extend	= 0x00;
		req.msgType = MSG_KMAIL_SIGNDATA;

		std::string json = buildSignDataReq(devId, appName, conName, srcData, type);

		req.data->setSize(json.length()+1);
		strncpy((char *)req.data->getData(), json.c_str(), json.length());	

		reqSync(KMAILSERVICE, &req, &resp);
		printf("res.data=%s\n", resp.data->getDataString().c_str());
		printf("res.errCode=%#x\n", resp.errCode);
		return resp.errCode;
	}

#endif
/**
 * @description: 生成随机数
 * @param {devId} 设备ID
 * @param {randomLen} 随机数字节数
 * @return: 0：成功, 其他：失败
 */
int SyncDevice::syncGenRandom(const std::string &devId, const unsigned int &randomLen) {
    printf("============================================== GenRandom\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_GENRANDOM;

    std::string json = buildGenRandomReq(devId, randomLen);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(DEVSERVICE, &req, &resp);

    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

int SyncUnionAuth::syncGetAuthModule() {
    printf("============================================== GetAuthModule\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x01;
    req.msgType = MSG_UNIONAUTH_GETMODULE;

    reqSync(UNIAUTHSERVICE, &req, &resp);

    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);

    JSON_Value *root_value = json_parse_string(resp.data->getDataString().c_str());
    JSON_Object *root_object = json_value_get_object(root_value);
    JSON_Array *data_obj = json_object_get_array(root_object, "data");
    JSON_Object *auth_obj = json_array_get_object(data_obj, 2);
    if (json_object_has_value(auth_obj, "label")) {
        mLabel = json_object_get_string(auth_obj, "label");
    }

    printf("mLabel=%s\n", mLabel.c_str());
    return resp.errCode;
}

int SyncUnionAuth::syncInitAuth() {
    printf("============================================== InitAuth\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_UNIONAUTH_INITAUTH;

    std::string json = buildAuthInitReq(mLabel);
    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(UNIAUTHSERVICE, &req, &resp);

    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

int SyncUnionAuth::syncGetUserToken() {
    printf("============================================== getUserToken\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_UNIONAUTH_STARAUTH;

    std::string json = buildUnionAuthReq(mLabel, 0x00, "getUserToken");
    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(UNIAUTHSERVICE, &req, &resp);

    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

int SyncUnionAuth::syncRenewUserToken() {
    printf("============================================== renewUserToken\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_UNIONAUTH_STARAUTH;

    std::string json = buildUnionAuthReq(mLabel, 0x01, "renewUserToken");
    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(UNIAUTHSERVICE, &req, &resp);

    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

int SyncUnionAuth::syncGetAppToken() {
    printf("============================================== getAppToken\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_UNIONAUTH_STARAUTH;

    std::string json = buildAppTokenAuthReq(mLabel, 0x02, "111111111111", "getAppToken");
    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(UNIAUTHSERVICE, &req, &resp);

    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

int SyncUnionAuth::syncRenewAppToken() {
    printf("============================================== renewAppToken\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_UNIONAUTH_STARAUTH;

    std::string json = buildUnionAuthReq(mLabel, 0x03, "renewAppToken");
    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(UNIAUTHSERVICE, &req, &resp);

    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

int SyncUnionAuth::syncVerifyAppToken() {
    printf("============================================== verifyAppToken\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_UNIONAUTH_STARAUTH;

    std::string json = buildUnionAuthReq(mLabel, 0x04, "verifyAppToken");
    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(UNIAUTHSERVICE, &req, &resp);

    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

int SyncUnionAuth::syncOfflineAppToken() {
    printf("============================================== offlineAppToken\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_UNIONAUTH_STARAUTH;

    std::string json = buildUnionAuthReq(mLabel, 0x05, "offlineAppToken");
    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(UNIAUTHSERVICE, &req, &resp);

    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

int SyncUnionAuth::syncVerifyAuth() {
    printf("============================================== VerifyAuth\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_UNIONAUTH_VERIFYAUTH;

    std::string json = buildAuthInitReq(mLabel);
    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(UNIAUTHSERVICE, &req, &resp);

    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

int SyncUnionAuth::syncCancleAuth() {
    printf("============================================== CancleAuth\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_UNIONAUTH_CANCELAUTH;

    std::string json = buildAuthInitReq(mLabel);
    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(UNIAUTHSERVICE, &req, &resp);

    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

// JD多认证
int SyncJDAuth::syncGetAuthModule() {
    printf("============================================== GetAuthModule\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x01;
    req.msgType = MSG_UNIONAUTH_GETMODULE;

    reqSync(UNIAUTHSERVICE, &req, &resp);

    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);

    JSON_Value *root_value = json_parse_string(resp.data->getDataString().c_str());
    JSON_Object *root_object = json_value_get_object(root_value);
    JSON_Array *data_obj = json_object_get_array(root_object, "data");
    JSON_Object *auth_obj = json_array_get_object(data_obj, 3);
    if (json_object_has_value(auth_obj, "label")) {
        mLabel = json_object_get_string(auth_obj, "label");
    }

    printf("mLabel=%s\n", mLabel.c_str());
    return resp.errCode;
}

int SyncJDAuth::syncInitAuth() {
    printf("============================================== InitAuth\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_UNIONAUTH_INITAUTH;

    std::string json = buildAuthInitReq(mLabel);
    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(UNIAUTHSERVICE, &req, &resp);

    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

int SyncJDAuth::syncGetToken() {
    printf("============================================== getUserToken\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_UNIONAUTH_STARAUTH;

    std::string json = buildGetTokenReq(0x01, mLabel, 0x01, "", "", "", "", "getToken");
    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(UNIAUTHSERVICE, &req, &resp);

    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

int SyncJDAuth::syncGetTokenEx() {
    printf("============================================== GetTokenEx\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_UNIONAUTH_STARAUTH;

    std::string json = buildGetTokenReq(0x01, mLabel, 0x01, "0547211666485248", "A", "123456", "", "GetTokenEx");
    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(UNIAUTHSERVICE, &req, &resp);

    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

int SyncJDAuth::syncGetTokenSpecAuthType() {
    printf("============================================== getTokenSpecAuthType\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_UNIONAUTH_STARAUTH;

    std::string json = buildGetTokenReqByPwd(0x00, mLabel, 0x01, "", "", "", "", "getTokenSpecAuthType", "hejr", "123456");
    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(UNIAUTHSERVICE, &req, &resp);

    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

int SyncJDAuth::syncGetTokenSpecAuthTypeEx() {
    printf("============================================== getTokenSpecAuthTypeEx\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_UNIONAUTH_STARAUTH;

    std::string json = buildGetTokenReqByPwd(0x00, mLabel, 0x01, "0547211666485248", "A", "123456", "", "getTokenSpecAuthTypeEx", "hejr", "123456");
    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(UNIAUTHSERVICE, &req, &resp);

    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

int SyncJDAuth::syncCancleAuth() {
    printf("============================================== CancleAuth\n");
    kpkiReq req;
    kpkiResp resp;
    req.reqid = 1;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_UNIONAUTH_CANCELAUTH;

    std::string json = buildAuthInitReq(mLabel);
    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    reqSync(UNIAUTHSERVICE, &req, &resp);

    printf("res.data=%s\n", resp.data->getDataString().c_str());
    printf("res.errCode=%#x\n", resp.errCode);
    return resp.errCode;
}

}  // namespace testAgent
}  // namespace koal
