> ## testAgent使用文档

> ### 依赖库介绍
- parson：由pki中间件相关人员提供
- pkiAgent4c：[点击下载](http://git.koal.com/cbb-crypto/pki-mw-guide/-/releases)最新版本

> ### 使用
- 将parson的依赖库放置./parson/目录下；
    - *依赖库及路径示例 - windows：parson/vc_x64/parson_x64.lib 或 parson/vc_x86/parson.lib*
- [下载pkiAgent4c](http://git.koal.com/cbb-crypto/pki-mw-guide/-/releases)，将其解压到./pkiAgent/;
    - *依赖库及路径示例 - windows：pkiAgent/archs/x64/pkiAgent4c.lib 或 pkiAgent/archs/x86/pkiAgent4c.lib*

- 新建并进入build/
  - windows
    - cmake -G "Visual Studio 10 2010" .. 或 cmake -G "Visual Studio 10 2010 Win64" ..
    - cmake --build ./ --clean-first --config Release
  - Linux(ubuntu)
    - cd build; cmake ..; make
  - 中标麒麟(龙芯)
    - cd build; cmake -D PLATFORM=loongson ..; make
  - 银河麒麟(飞腾)
    - cd build; cmake -D PLATFORM=phytium ..; make 
