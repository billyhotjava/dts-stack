/**
 *  @file syncClient.h
 *  @brief 测试pkiAgent4c同步接口
 *  @date 2019年12月10日
 *  @author wangtao
 *  @email  wangtao1@koal.com
 */
#ifndef _SYNCCLIENT_H_
#define _SYNCCLIENT_H_
#include <iostream>
#include <vector>
#include <map>

namespace koal {
    namespace testAgent {
        class SyncDevice
        {
        public:
            int syncGetDevices();
            int syncGetDevInfo(const std::string & devId);
            int syncSetDevLable(const std::string & devId, const std::string & lable);
            int syncTransMitData(const std::string & devId, const std::string & command);
            int syncDevAuth(const std::string & devId, const std::string & authData);
            int syncChangeAuthKey(const std::string & devId, const std::string & authData);
            int syncGetPINInfo(const std::string & devId, const std::string & appName, const unsigned int & PINType);
            int syncChangePIN(const std::string & devId, const std::string & appName, const unsigned int & PINType,
                const std::string & oldPIN, const std::string & newPIN);
            int syncVerifyPIN(const std::string & devId, const std::string & appName, const unsigned int & PINType,
                const std::string & PIN);
            int syncUnlockPIN(const std::string & devID, const std::string & appName, const std::string & adminPIN,
                const std::string & userPIN);
            int syncGetAppList(const std::string & devId);
            int syncCreateApp(const std::string & devId, const std::string & appName, const std::string & admin_PIN,
                const unsigned int & admin_maxRetryCount, const std::string & user_PIN, const unsigned int & user_maxRetryCount,
                const unsigned int & fileRight);
            int syncDelApp(const std::string & devId, const std::string & appName);
            int syncGetContainers(const std::string & devId, const std::string & appName);
            int syncCreateContainer(const std::string & devId, const std::string & appName, const std::string & containerName);
            int syncDelContainer(const std::string & devId, const std::string & appName, const std::string & containerName);
            int syncGetContainerType(const std::string & devId, const std::string & appName, const std::string & containerName);
            int syncImportCertificate(const std::string & devId, const std::string & appName, const std::string & containerName,
                const unsigned int & signFlag, const std::string & cert);
            int syncExportCertificate(const std::string & devId, const std::string & appName, const std::string & containerName,
                const unsigned int & signFlag);
            int syncGetAllCert();
            int syncGetAllCertBySN();
            int syncExportPublicKey(const std::string & devId, const std::string & appName, const std::string & containerName,
                const unsigned int & signFlag);
            int syncExtPubKeyEncrypt(const std::string & devId, const std::string & pubKey, const unsigned int & type,
                const std::string & srcData);
            int syncExtPriKeyDecrypt(const std::string & devId, const std::string & priKey, const unsigned int & type,
                const std::string & encryptData);
            int syncGetProviders();
            int syncSetProvider(const std::string & name, const std::string & VPID);
            int syncUnblockFinger(const std::string & devId, const std::string & appName, const unsigned int & type);
            int syncInitFinger(const std::string & devId, const unsigned int & type);
            int syncHasFinger(const std::string & devId, const std::string & appName, const unsigned int & type);
            int syncVerifyFinger(const std::string & devId, const std::string & appName, const unsigned int & type);
            int syncCancleFinger(const std::string & devId);
            int syncCreateFile(const std::string & devId, const std::string & appName, const std::string & fileName,
                const unsigned int &fileSize, const unsigned int &readRights, const unsigned int &writeRights);
            int syncDeleteFile(const std::string & devId, const std::string & appName, const std::string & fileName);
            int syncGetFileList(const std::string & devId, const std::string & appName);
            int syncGetFileInfo(const std::string & devId, const std::string & appName, const std::string & fileName);
            int syncReadFile(const std::string & devId, const std::string & appName, const std::string & fileName,
                const unsigned int &offset, const unsigned int &size);
            int syncWriteFile(const std::string & devId, const std::string & appName, const std::string & fileName,
                const unsigned int &offset, const std::string & data);
            int syncGenRandom(const std::string & devId,const unsigned int &randomLen);


	public:
		std::string syncGetDevID();
        std::string syncGetDevType();
	private:
		std::string mDevID;
        std::string mDevType;
	};

	class SyncEnRoll {
	public:
		int syncMakePkcs10(const std::string & devId, const std::string & appName,
						const std::string & conName, const std::string & dn, const int & extensionType, const int & reqDigst);
		int syncGenKeypair(const std::string& devId, const std::string& appName, const std::string& conName, const std::string& keyType,
								const std::string& keyLen, const unsigned int & purpose);
		int syncImportEncKeypair(const std::string& devId, const std::string& appName, const std::string& conName, const std::string& b64Key);
		int syncImportX509Cert(const std::string & devId, const std::string & appName, const std::string & conName, const std::string & b64cert, 
							const std::string & purpose);
		int syncImportPfxCert(const std::string& devId, const std::string& appName, const std::string& conName, const std::string& b64cert,
							const std::string& certPass);
		int syncGetCert(const std::string & devId, const std::string & appName, const std::string & conName, const std::string & certType);

        int syncImportPfx2SkfFile(
        const std::string& devId, const std::string& appName, 
        const std::string& conName, unsigned int signFlag, 
        const std::string& certPass, const std::string& b64cert);
	};

	class SyncSignX {
	public:
		int syncSignData(const std::string& devId, const std::string& appName, const std::string& conName,  const std::string& srcData, const unsigned int & isBase64SrcData, const std::string& type);
		int syncVerifySignData(const std::string& devId, const std::string& appName, const std::string& conName, const std::string& srcData, 
							const std::string& signData, const unsigned int & isBase64SrcData, const unsigned int & type);
		int syncSignMessage(const std::string& devId, const std::string & appName, const std::string & conName, const std::string & srcData, const unsigned int & mdType, const std::string & attachData,  const unsigned int & signwithSM2Std);
		int syncVerifyMessage(const std::string& srcData, const std::string& signData);
		int syncExtECCVerify(const std::string& devId, const std::string& pubkey, const std::string& srcData, const std::string& signData);
		int syncExtECCVerifyEx(const std::string& devId, const std::string& b64cert,const std::string& srcData, const std::string& signData);
		int syncDupCertWithTemplate(const std::string& devId, const std::string& appName, const std::string& conName, const std::string& signFlag);
		int syncParseCert(const std::string cert);
		int syncEnvelopeEncrypt(const std::string& srcData,	const std::string& cert, const unsigned int & cihperType);
		int syncEnvelopeDecrypt(const std::string& devId, const std::string& appName, const std::string& conName, const std::string& srcData);
		int syncVerifySignedMessage(const std::string& srcData, const std::string& signData, const std::string& cert);
		int syncGetExtension(const std::string & cert, const std::string & oid);
	public:
		std::string & syncGetSignData();
		std::string & syncGetP7SignData();
		std::string & syncGetEnvelopeEncryptData();
	private:
		std::string mSignData;
		std::string mP7SignData;
		std::string mEnvelopeEncrypt;
	};
/*
		class SyncKmail
		{
		public:
			int syncSetTextBody(const std::string &body);
			int syncGetTextBody();
			int syncSetHtmlBody(const std::string &body);
			int syncGetHtmlBody();
			int syncCompose(const std::string &devId, const std::string &appName, const std::string &conName);
			int syncGetComposedData(const unsigned int &index);
			int syncPrepareParse(const unsigned int &index, const std::string &mail);
			int syncParse(const std::string &devId, const std::string &appName, const std::string &conName);
			int syncClear();
			int syncAddAttachFile(const std::string fileInfo);
			int syncGetAttachCount();
			int syncGetAttachFileInfo(const unsigned int &index);
			int syncDoAttachSaveAs(const unsigned int &index, const std::string &filePath);
			int syncGetAttachFieldInfo(const unsigned int &index);
			int syncSetMailType(const unsigned int &type);
			int syncGetMailType();
			int syncSetEncCerts(const std::string &encCert);
			int syncGetMailSigner();
			int syncGetSignCert(const std::string &devId, const std::string &appName, const std::string &conName);
			int syncGetCertItem(const std::string &certb64, const std::string &key);
			int syncSignData(const std::string &devId, const std::string &appName, const std::string &conName,
							 const std::string &srcData, const unsigned int &type);
		};
*/
		class SyncUnionAuth
		{
		public:
			int syncGetAuthModule();
			int syncInitAuth();
			int syncGetUserToken();
			int syncRenewUserToken();
			int syncGetAppToken();
			int syncRenewAppToken();
			int syncVerifyAppToken();
			int syncOfflineAppToken();
			int syncVerifyAuth();
			int syncCancleAuth();

		private:
			std::string mLabel;
		};

		class SyncJDAuth
		{
		public:
			int syncGetAuthModule();
			int syncInitAuth();
			int syncGetToken();
			int syncGetTokenEx();
			int syncGetTokenSpecAuthType();
			int syncGetTokenSpecAuthTypeEx();
			int syncCancleAuth();

		private:
			std::string mLabel;
		};

	} // namespace testAgent
} // namespace koal

#endif //_TESTCASE_H_
