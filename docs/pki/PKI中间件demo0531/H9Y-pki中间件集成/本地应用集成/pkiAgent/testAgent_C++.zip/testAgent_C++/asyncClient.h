/**
 *  @file syncClient.h
 *  @brief 测试pkiAgent4c异步接口
 *  @date 2019年12月17日
 *  @author wangtao
 *  @email  wangtao1@koal.com
 */
#ifndef _ASYNCCLIENT_H_
#define _ASYNCCLIENT_H_
#include <iostream>
#include <vector>
#include <map>

namespace koal {
namespace testAgent {	
	class AsyncDevice
	{
	public:
		int asyncGetDevices();
		int asyncGetDevInfo(const std::string & devId);
		int asyncSetDevLable(const std::string & devId, const std::string & lable);
		int asyncTransMitData(const std::string & devId, const std::string & command);
		int asyncDevAuth(const std::string & devId, const std::string & authData);
		int asyncChangeAuthKey(const std::string & devId, const std::string & authData);
		int asyncGetPINInfo(const std::string & devId, const std::string & appName, const unsigned int & PINType);
		int asyncChangePIN(const std::string & devId, const std::string & appName, const unsigned int & PINType,
				const std::string & oldPIN, const std::string & newPIN);
		int asyncVerifyPIN(const std::string & devId, const std::string & appName, const unsigned int & PINType,
				const std::string & PIN);
		int asyncUnlockPIN(const std::string & devId, const std::string & appName, const std::string & adminPIN,
				const std::string & userPIN);
		int asyncGetAppList(const std::string & devId);
		int asyncCreateApp(const std::string & devId, const std::string & appName, const std::string & admin_PIN,
				const unsigned int & admin_maxRetryCount, const std::string & user_PIN, const unsigned int & user_maxRetryCount,
				const unsigned int & fileRight);
		int asyncDelApp(const std::string & devId, const std::string & appName);
		int asyncGetContainers(const std::string & devId, const std::string & appName);
		int asyncCreateContainer(const std::string & devId, const std::string & appName, const std::string & containerName				);
		int asyncDelContainer(const std::string & devId, const std::string & appName, const std::string & containerName);
		int asyncGetContainerType(const std::string & devId, const std::string & appName, const std::string & containerName);
		int asyncImportCertificate(const std::string & devId, const std::string & appName, const std::string & containerName,
				const unsigned int & signFlag, const std::string & cert);
		int asyncExportCertificate(const std::string & devId, const std::string & appName, const std::string & containerName,
				const unsigned int & signFlag);
		int asyncGetAllCert();
		int asyncExportPublicKey(const std::string & devId, const std::string & appName, const std::string & containerName,
				const unsigned int & signFlag);
		int asyncExtPubKeyEncrypt(const std::string & devId, const std::string & pubKey, const unsigned int & type,
				const std::string & srcData);
		int asyncExtPriKeyDecrypt(const std::string & devId, const std::string & priKey, const unsigned int & type,
				const std::string & encryptData);
		int asyncGetProviders();
		int asyncSetProvider(const std::string & name, const std::string & VPID);
		int asyncInitFinger(const std::string & devId, const unsigned int & type);
		int asyncHasFinger(const std::string & devId, const std::string & appName, const unsigned int & type);
		int asyncVerifyFinger(const std::string & devId, const std::string & appName, const unsigned int & type);
		int asyncCancleFinger(const std::string & devId);
        int asyncCreateFile(const std::string & devId, const std::string & appName, const std::string & fileName,
                            const unsigned int &fileSize, const unsigned int &readRights, const unsigned int &writeRights);
        int asyncDeleteFile(const std::string & devId, const std::string & appName, const std::string & fileName);
        int asyncGetFileList(const std::string & devId, const std::string & appName);
        int asyncGetFileInfo(const std::string & devId, const std::string & appName, const std::string & fileName);
        int asyncReadFile(const std::string & devId, const std::string & appName, const std::string & fileName,
                            unsigned int &offset, unsigned int &size);
        int asyncWriteFile(const std::string & devId, const std::string & appName, const std::string & fileName,
                            unsigned int &offset, const std::string & data);

	public:
		std::string asyncGetDevID();
		bool asyncSetDevID(std::string devId);
	private:
		std::string mDevID;
	};

	class AsyncEnRoll {
	public:
		int asyncMakePkcs10(const std::string & devId, const std::string & appName,
				const std::string & conName, const std::string & dn, const int & extensionType, const int & reqDigst);
		int asyncGenKeypair(const std::string& devId, const std::string& appName, const std::string& conName, const std::string& keyType,
				const std::string& keyLen, const unsigned int & purpose);
		int asyncImportEncKeypair(const std::string& devId, const std::string& appName, const std::string& conName, const std::string& b64Key);
		int asyncImportX509Cert(const std::string & devId, const std::string & appName, const std::string & conName, const std::string & b64cert, 
				const std::string & purpose);
		int asyncImportPfxCert(const std::string& devId, const std::string& appName, const std::string& conName, const std::string& b64cert,
				const std::string& certPass);
		int asyncGetCert(const std::string & devId, const std::string & appName, const std::string & conName, const std::string & certType);
		int asyncImportPfx2SkfFile(
			const std::string& devId, const std::string& appName, 
			const std::string& conName, unsigned int signFlag, 
			const std::string& certPass, const std::string& b64cert);
	};

	class AsyncSignX {
	public:
		int asyncSignData(const std::string& devId, const std::string& appName, const std::string& conName,  const std::string& srcData, const unsigned int & isBase64SrcData, const std::string& type);
		int asyncVerifySignData(const std::string& devId, const std::string& appName, const std::string& conName, const std::string& srcData, 
				const std::string& signData, const unsigned int & isBase64SrcData, const unsigned int & type);
		int asyncSignMessage(const std::string& devId, const std::string & appName, const std::string & conName, 
				const std::string & srcData, const unsigned int & mdType, const std::string & attachData, const unsigned int & signwithSM2Std);
		int asyncVerifyMessage(const std::string& srcData, const std::string& signData);
		int asyncExtECCVerify(const std::string& devId, const std::string& pubkey, const std::string& srcData, const std::string& signData);
		int asyncExtECCVerifyEx(const std::string& devId, const std::string& b64cert,const std::string& srcData, const std::string& signData);
		int asyncDupCertWithTemplate(const std::string& devId, const std::string& appName, const std::string& conName, const std::string& signFlag);
		int asyncParseCert(const std::string cert);
		int asyncEnvelopeEncrypt(const std::string& srcData,const std::string& cert, const unsigned int & cihperType);
		int asyncEnvelopeDecrypt(const std::string& devId, const std::string& appName, const std::string& conName, const std::string& srcData);
		int asyncVerifySignedMessage(const std::string& srcData, const std::string& signData, const std::string& cert);
		int asyncGetExtension(const std::string & cert, const std::string & oid);
	public:
		std::string & asyncGetSignData();
		bool asyncSetSignData(std::string data);
		std::string & asyncGetP7SignData();
		bool asyncSetP7SignData(std::string data);
		std::string & asyncGetEnvelopeEncryptData();
		bool asyncSetEnvelopeEncryptData(std::string data);
	private:
		std::string mSignData;
		std::string mP7SignData;
		std::string mEnvelopeEncrypt;
	};
	/*
	class AsyncKmail {
	public:
		int asyncSetTextBody(const std::string & body);
		int asyncGetTextBody();
		int asyncSetHtmlBody(const std::string & body);
		int asyncGetHtmlBody();
		int asyncCompose(const std::string & devId, const std::string &appName, const std::string &conName);
		int asyncGetComposedData(const unsigned int & index);
		int asyncPrepareParse(const unsigned int & index, const std::string &mail);
		int asyncParse(const std::string & devId, const std::string &appName, const std::string &conName);
		int asyncClear();
		int asyncAddAttachFile(const std::string fileInfo);
		int asyncGetAttachCount();
		int asyncGetAttachFileInfo(const unsigned int & index);
		int asyncDoAttachSaveAs(const unsigned int & index, const std::string & filePath);
		int asyncGetAttachFieldInfo(const unsigned int & index); 
		int asyncSetMailType(const unsigned int & type);
		int asyncGetMailType();
		int asyncSetEncCerts(const std::string & encCert);
		int asyncGetMailSigner();
		int asyncGetSignCert(const std::string & devId, const std::string &appName, const std::string &conName);
		int asyncGetCertItem(const std::string & certb64, const std::string & key);
		int asyncSignData(const std::string & devId, const std::string &appName, const std::string &conName,
			const std::string & srcData, const unsigned int & type);
	};*/
} // namespace testAgent
} // namespace koal

#endif //_TESTCASE_H_
