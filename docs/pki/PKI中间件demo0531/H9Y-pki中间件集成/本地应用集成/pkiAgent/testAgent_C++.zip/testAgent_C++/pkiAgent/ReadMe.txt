【使用方法】
- 将提供的pkiAgent4c库，解压到此文件夹下，供testAgent依赖使用。