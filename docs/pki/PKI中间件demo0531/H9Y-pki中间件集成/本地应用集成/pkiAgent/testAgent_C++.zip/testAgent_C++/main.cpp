/**
 * @brief pkiAgent4c的测试文件，同步请求由测试工具doctest测试，异步请求仅写了部分示例
 * @author wangtao
 * @email wangtao1@koal.com
 */

#include <stdio.h>
#include "pkiAgent4c.h"
#include "jsonProtocol.h"

using namespace koal::testAgent;

#include "asyncClient.h"
std::map<int, std::string> mapRespData;  ///用于保存异步返回的消息id及数据，mapRespData[respid] = resp.jsonBody

#ifndef _ASYNC
#include "testCase.hpp"  //同步请求
#else
AsyncDevice gDevice;
AsyncSignX gSignx;
AsyncEnRoll gEnRoll;
std::string gDevId;
#endif

bool msgNotify(const kpkiResp *pResp, void *pUserData) {
    if (pUserData) {
        const char *pData = (const char *)pUserData;
        printf("get parm=\"%s\" from callBack msgNotify\n", pData);
    }

    switch (pResp->msgType) {
        case 0x0FFF0001: {  ///设备插入
            printf("key insert\n");
            break;
        }
        case 0x0FFF0002: {  ///设备拔出
            printf("key remove\n");
            break;
        }
        case 0x0FFF0003: {  ///设备修改
            printf("key changed\n");
            break;
        }
        case 0x0FFF0004: {  /// Session关闭
            printf("session closed\n");
            break;
        }
        case 0x0FFF0031: {
            printf("get user token\n");
            break;
        }
    }
    return true;
}

bool resp_DEVICESERVICE(const kpkiResp *pResp, void *pUserData) {
    /* device */
    switch (pResp->msgType) {
        case MSG_DEVICE_GETDEVICES: {
            printf("=========================================================== getDevices\n");
            printf("res.respid=%d\n", pResp->respid);
            printf("res.data=%s\n", pResp->data->getDataString().c_str());

            std::vector<std::map<std::string, std::string> > arrayDevID;
            parseGetDevicesResponse(pResp->data->getDataString(), arrayDevID);
            //提取一个devID
            std::vector<std::map<std::string, std::string> >::iterator it = arrayDevID.begin();
            if (it == arrayDevID.end()) {
                printf("without any device, process exit\n");
                return false;
            }
            AsyncDevice *pDevice = (AsyncDevice *)pUserData;
            pDevice->asyncSetDevID((*it)["devID"]);

            if (0 == pResp->errCode) {
                printf("successful...\n");
                mapRespData[pResp->respid] = pResp->data->getDataString();
            } else {
                printf("failure..., res.errCode=%#x\n", pResp->errCode);
            }
        } break;
        case MSG_DEVICE_GETDEVINFO: {
            printf("=========================================================== getDevInfo\n");
            printf("res.respid=%d\n", pResp->respid);
            printf("res.data=%s\n", pResp->data->getDataString().c_str());

            if (0 == pResp->errCode) {
                printf("successful...\n");
                mapRespData[pResp->respid] = pResp->data->getDataString();
            } else {
                printf("failure..., res.errCode=%#x\n", pResp->errCode);
            }
        } break;
        case MSG_DEVICE_SETDEVLABLE: {
            printf("=========================================================== setDevLable\n");
            printf("res.respid=%d\n", pResp->respid);

            if (0 == pResp->errCode) {
                printf("successful...\n");
            } else {
                printf("failure..., res.errCode=%#x\n", pResp->errCode);
            }
        } break;
        case MSG_DEVICE_TRANSMITDATA: {
            printf("=========================================================== transMitData\n");
            printf("res.respid=%d\n", pResp->respid);

            if (0 == pResp->errCode) {
                printf("successful...\n");
            } else {
                printf("failure..., res.errCode=%#x\n", pResp->errCode);
            }
        } break;
        case MSG_DEVICE_DEVAUTH: {
            printf("============================================== devAuth\n");
            printf("res.respid=%d\n", pResp->respid);
            printf("res.data=%s\n", pResp->data->getDataString().c_str());

            if (0 == pResp->errCode) {
                printf("successful...\n");
                mapRespData[pResp->respid] = pResp->data->getDataString();
            } else {
                printf("failure..., res.errCode=%#x\n", pResp->errCode);
            }
        } break;
        case MSG_DEVICE_CHANGEAUTHKEY: {
            printf("============================================== changeAuthKey\n");
            printf("res.respid=%d\n", pResp->respid);
            printf("res.data=%s\n", pResp->data->getDataString().c_str());

            if (0 == pResp->errCode) {
                printf("successful...\n");
                mapRespData[pResp->respid] = pResp->data->getDataString();
            } else {
                printf("failure..., res.errCode=%#x\n", pResp->errCode);
            }
        } break;
        case MSG_DEVICE_GETPININFO: {
            printf("============================================== getPINInfo\n");
            printf("res.respid=%d\n", pResp->respid);
            printf("res.data=%s\n", pResp->data->getDataString().c_str());

            if (0 == pResp->errCode) {
                printf("successful...\n");
                mapRespData[pResp->respid] = pResp->data->getDataString();
            } else {
                printf("failure..., res.errCode=%#x\n", pResp->errCode);
            }
        } break;
        case MSG_DEVICE_CHANGEPIN: {
            printf("============================================== changePIN\n");
            printf("res.respid=%d\n", pResp->respid);
            printf("res.data=%s\n", pResp->data->getDataString().c_str());

            if (0 == pResp->errCode) {
                printf("successful...\n");
                mapRespData[pResp->respid] = pResp->data->getDataString();
            } else {
                printf("failure..., res.errCode=%#x\n", pResp->errCode);
            }
        } break;
        case MSG_DEVICE_VERIFYPIN: {
            printf("============================================== verifyPIN\n");
            printf("res.respid=%d\n", pResp->respid);
            printf("res.data=%s\n", pResp->data->getDataString().c_str());

            if (0 == pResp->errCode) {
                printf("successful...\n");
                mapRespData[pResp->respid] = pResp->data->getDataString();
            } else {
                printf("failure..., res.errCode=%#x\n", pResp->errCode);
            }
        } break;
        case MSG_DEVICE_UNLOCKPIN: {
            printf("============================================== unlockPIN\n");
            printf("res.respid=%d\n", pResp->respid);
            printf("res.data=%s\n", pResp->data->getDataString().c_str());

            if (0 == pResp->errCode) {
                printf("successful...\n");
                mapRespData[pResp->respid] = pResp->data->getDataString();
            } else {
                printf("failure..., res.errCode=%#x\n", pResp->errCode);
            }
        } break;
        case MSG_DEVICE_GETAPPLIST: {
            printf("============================================== getAppList\n");
            printf("res.respid=%d\n", pResp->respid);
            printf("res.data=%s\n", pResp->data->getDataString().c_str());

            if (0 == pResp->errCode) {
                printf("successful...\n");
                mapRespData[pResp->respid] = pResp->data->getDataString();
            } else {
                printf("failure..., res.errCode=%#x\n", pResp->errCode);
            }
        } break;
        case MSG_DEVICE_CREATEAPP: {
            printf("============================================== createApp\n");
            printf("res.respid=%d\n", pResp->respid);
            printf("res.data=%s\n", pResp->data->getDataString().c_str());

            if (0 == pResp->errCode) {
                printf("successful...\n");
                mapRespData[pResp->respid] = pResp->data->getDataString();
            } else {
                printf("failure..., res.errCode=%#x\n", pResp->errCode);
            }
        } break;
        case MSG_DEVICE_DELAPP: {
            printf("============================================== delApp\n");
            printf("res.respid=%d\n", pResp->respid);
            printf("res.data=%s\n", pResp->data->getDataString().c_str());

            if (0 == pResp->errCode) {
                printf("successful...\n");
                mapRespData[pResp->respid] = pResp->data->getDataString();
            } else {
                printf("failure..., res.errCode=%#x\n", pResp->errCode);
            }
        } break;
        case MSG_DEVICE_GETCONTAINERS: {
            printf("============================================== getContainers\n");
            printf("res.respid=%d\n", pResp->respid);
            printf("res.data=%s\n", pResp->data->getDataString().c_str());

            if (0 == pResp->errCode) {
                printf("successful...\n");
                mapRespData[pResp->respid] = pResp->data->getDataString();
            } else {
                printf("failure..., res.errCode=%#x\n", pResp->errCode);
            }
        } break;
        case MSG_DEVICE_CREATECONTAINER: {
            printf("============================================== createContainer\n");
            printf("res.respid=%d\n", pResp->respid);
            printf("res.data=%s\n", pResp->data->getDataString().c_str());

            if (0 == pResp->errCode) {
                printf("successful...\n");
                mapRespData[pResp->respid] = pResp->data->getDataString();
            } else {
                printf("failure..., res.errCode=%#x\n", pResp->errCode);
            }
        } break;
        case MSG_DEVICE_DELCONTAINER: {
            printf("============================================== delContainer\n");
            printf("res.respid=%d\n", pResp->respid);
            printf("res.data=%s\n", pResp->data->getDataString().c_str());

            if (0 == pResp->errCode) {
                printf("successful...\n");
                mapRespData[pResp->respid] = pResp->data->getDataString();
            } else {
                printf("failure..., res.errCode=%#x\n", pResp->errCode);
            }
        } break;
        case MSG_DEVICE_GETCONTAINERTYPE: {
            printf("============================================== getContainerType\n");
            printf("res.respid=%d\n", pResp->respid);
            printf("res.data=%s\n", pResp->data->getDataString().c_str());

            if (0 == pResp->errCode) {
                printf("successful...\n");
                mapRespData[pResp->respid] = pResp->data->getDataString();
            } else {
                printf("failure..., res.errCode=%#x\n", pResp->errCode);
            }
        } break;
        case MSG_DEVICE_IMPORTCERTIFICATE: {
            printf("============================================== importCertificate\n");
            printf("res.respid=%d\n", pResp->respid);
            printf("res.data=%s\n", pResp->data->getDataString().c_str());

            if (0 == pResp->errCode) {
                printf("successful...\n");
                mapRespData[pResp->respid] = pResp->data->getDataString();
            } else {
                printf("failure..., res.errCode=%#x\n", pResp->errCode);
            }
        } break;
        case MSG_DEVICE_EXPORTCERTIFICATE: {
            printf("============================================== exportCertificate\n");
            printf("res.respid=%d\n", pResp->respid);
            printf("res.data=%s\n", pResp->data->getDataString().c_str());

            if (0 == pResp->errCode) {
                printf("successful...\n");
                mapRespData[pResp->respid] = pResp->data->getDataString();
            } else {
                printf("failure..., res.errCode=%#x\n", pResp->errCode);
            }
        } break;
        case MSG_DEVICE_EXPORTPUBLICKEY: {
            printf("============================================== exportPublicKey\n");
            printf("res.respid=%d\n", pResp->respid);
            printf("res.data=%s\n", pResp->data->getDataString().c_str());

            if (0 == pResp->errCode) {
                printf("successful...\n");
                mapRespData[pResp->respid] = pResp->data->getDataString();
            } else {
                printf("failure..., res.errCode=%#x\n", pResp->errCode);
            }
        } break;
        case MSG_DEVICE_GETPROVIDERS: {
            printf("============================================== getProviders\n");
            printf("res.respid=%d\n", pResp->respid);
            printf("res.data=%s\n", pResp->data->getDataString().c_str());

            if (0 == pResp->errCode) {
                printf("successful...\n");
                mapRespData[pResp->respid] = pResp->data->getDataString();
            } else {
                printf("failure..., res.errCode=%#x\n", pResp->errCode);
            }
        } break;
        case MSG_DEVICE_SETPROVIDER: {
            printf("============================================== setProvider\n");
            printf("res.respid=%d\n", pResp->respid);
            printf("res.data=%s\n", pResp->data->getDataString().c_str());

            if (0 == pResp->errCode) {
                printf("successful...\n");
                mapRespData[pResp->respid] = pResp->data->getDataString();
            } else {
                printf("failure..., res.errCode=%#x\n", pResp->errCode);
            }
        } break;
        case MSG_DEVICE_EXTPUBKEYENCRYPT: {
            printf("============================================== extPubKeyEncrypt\n");
            printf("res.respid=%d\n", pResp->respid);
            printf("res.data=%s\n", pResp->data->getDataString().c_str());

            if (0 == pResp->errCode) {
                printf("successful...\n");
                mapRespData[pResp->respid] = pResp->data->getDataString();
            } else {
                printf("failure..., res.errCode=%#x\n", pResp->errCode);
            }
        } break;
        case MSG_DEVICE_EXTPRIKEYDECRYPT: {
            printf("============================================== extPriKeyDecrypt\n");
            printf("res.respid=%d\n", pResp->respid);
            printf("res.data=%s\n", pResp->data->getDataString().c_str());

            if (0 == pResp->errCode) {
                printf("successful...\n");
                mapRespData[pResp->respid] = pResp->data->getDataString();
            } else {
                printf("failure..., res.errCode=%#x\n", pResp->errCode);
            }
        } break;
        case MSG_DEVICE_GETALLCERT: {
            printf("============================================== GetAllCert\n");
            printf("res.respid=%d\n", pResp->respid);
            printf("res.data=%s\n", pResp->data->getDataString().c_str());

            if (0 == pResp->errCode) {
                printf("successful...\n");
                mapRespData[pResp->respid] = pResp->data->getDataString();
            } else {
                printf("failure..., res.errCode=%#x\n", pResp->errCode);
            }
        } break;
        default:
            break;
    }
    return true;
}

bool resp_ENROLLSERVICE(const kpkiResp *pResp, void *pUserData) {
    /* enRoll  */
    switch (pResp->msgType) {
        case MSG_ENROLL_MKP10: {
            printf("============================================== makePkcs10\n");
            printf("res.respid=%d\n", pResp->respid);
            printf("res.data=%s\n", pResp->data->getDataString().c_str());
            if (0 == pResp->errCode) {
                printf("successful...\n");
                mapRespData[pResp->respid] = pResp->data->getDataString();
            } else {
                printf("failure..., res.errCode=%#x\n", pResp->errCode);
            }
        } break;
        case MSG_ENROLL_KEYPAIR: {
            printf("============================================== genKeypair\n");
            printf("res.respid=%d\n", pResp->respid);
            printf("res.data=%s\n", pResp->data->getDataString().c_str());
            if (0 == pResp->errCode) {
                printf("successful...\n");
                mapRespData[pResp->respid] = pResp->data->getDataString();
            } else {
                printf("failure..., res.errCode=%#x\n", pResp->errCode);
            }
        } break;
        case MSG_ENROLL_IMPORTKEYPAIR: {
            printf("============================================== importEncKeypair\n");
            printf("res.respid=%d\n", pResp->respid);
            printf("res.data=%s\n", pResp->data->getDataString().c_str());

            if (0 == pResp->errCode) {
                printf("successful...\n");
                mapRespData[pResp->respid] = pResp->data->getDataString();
            } else {
                printf("failure..., res.errCode=%#x\n", pResp->errCode);
            }
        } break;
        case MSG_ENROLL_IMPORTX509: {
            printf("============================================== importX509Cert\n");
            printf("res.respid=%d\n", pResp->respid);
            printf("res.data=%s\n", pResp->data->getDataString().c_str());
            if (0 == pResp->errCode) {
                printf("successful...\n");
                mapRespData[pResp->respid] = pResp->data->getDataString();
            } else {
                printf("failure..., res.errCode=%#x\n", pResp->errCode);
            }
        } break;
        case MSG_ENROLL_IMPORTPFX: {
            printf("============================================== importPfxCert\n");
            printf("res.respid=%d\n", pResp->respid);
            printf("res.data=%s\n", pResp->data->getDataString().c_str());
            if (0 == pResp->errCode) {
                printf("successful...\n");
                mapRespData[pResp->respid] = pResp->data->getDataString();
            } else {
                printf("failure..., res.errCode=%#x\n", pResp->errCode);
            }
        } break;
        case MSG_ENROLL_GETCERT: {
            printf("============================================== getCert\n");
            printf("res.respid=%d\n", pResp->respid);
            printf("res.data=%s\n", pResp->data->getDataString().c_str());
            if (0 == pResp->errCode) {
                printf("successful...\n");
                mapRespData[pResp->respid] = pResp->data->getDataString();
            } else {
                printf("failure..., res.errCode=%#x\n", pResp->errCode);
            }
        } break;
        default:
            break;
    }
    return true;
}

bool resp_SIGNXLSERVICE(const kpkiResp *pResp, void *pUserData) {
    /* Signx */
    switch (pResp->msgType) {
        case MSG_SIGNX_SIGNDATA: {
            printf("============================================== signData\n");
            printf("res.respid=%d\n", pResp->respid);
            printf("res.data=%s\n", pResp->data->getDataString().c_str());

            if (0 == pResp->errCode) {
                printf("successful...\n");
                mapRespData[pResp->respid] = pResp->data->getDataString();
            } else {
                printf("failure..., res.errCode=%#x\n", pResp->errCode);
            }

            /// 获取签名结果
            AsyncSignX *pSignx = (AsyncSignX *)pUserData;
            std::string signData;
            parseSignDatResp(pResp->data->getDataString(), signData);
            pSignx->asyncSetSignData(signData);
        } break;
        case MSG_SIGNX_VERIFYSIGN: {
            printf("============================================== verifySignData\n");
            printf("res.respid=%d\n", pResp->respid);
            printf("res.data=%s\n", pResp->data->getDataString().c_str());

            if (0 == pResp->errCode) {
                printf("successful...\n");
                mapRespData[pResp->respid] = pResp->data->getDataString();
            } else {
                printf("failure..., res.errCode=%#x\n", pResp->errCode);
            }
        } break;
        case MSG_SIGNX_SIGNP7: {
            printf("============================================== signMessage\n");
            printf("res.respid=%d\n", pResp->respid);
            printf("res.data=%s\n", pResp->data->getDataString().c_str());

            if (0 == pResp->errCode) {
                printf("successful...\n");
                mapRespData[pResp->respid] = pResp->data->getDataString();
            } else {
                printf("failure..., res.errCode=%#x\n", pResp->errCode);
            }

            /// 获取签名结果
            AsyncSignX *pSignx = (AsyncSignX *)pUserData;
            std::string P7SignData;
            parsePkcs7SignResp(pResp->data->getDataString(), P7SignData);
            pSignx->asyncSetP7SignData(P7SignData);
        } break;
        case MSG_SIGNX_VERIFYSIGNP7: {
            printf("============================================== verifyMessage\n");
            printf("res.respid=%d\n", pResp->respid);

            if (0 == pResp->errCode) {
                printf("successful...\n");
            } else {
                printf("failure..., res.errCode=%#x\n", pResp->errCode);
            }
        } break;
        case MSG_SIGNX_EXTECCPUBVERIFY: {
            printf("============================================== extECCVerify\n");
            printf("res.respid=%d\n", pResp->respid);

            if (0 == pResp->errCode) {
                printf("successful...\n");
            } else {
                printf("failure..., res.errCode=%#x\n", pResp->errCode);
            }
        } break;
        case MSG_SIGNX_EXTECCCERTVERIFY: {
            printf("============================================== extECCVerifyEx\n");
            printf("res.respid=%d\n", pResp->respid);

            if (0 == pResp->errCode) {
                printf("successful...\n");
            } else {
                printf("failure..., res.errCode=%#x\n", pResp->errCode);
            }
        } break;
        case MSG_SIGNX_MKCERTFROMTEMP: {
            printf("============================================== dupCertWithTemplate\n");
            printf("res.respid=%d\n", pResp->respid);
            printf("res.data=%s\n", pResp->data->getDataString().c_str());

            if (0 == pResp->errCode) {
                printf("successful...\n");
                mapRespData[pResp->respid] = pResp->data->getDataString();
            } else {
                printf("failure..., res.errCode=%#x\n", pResp->errCode);
            }
        } break;
        case MSG_SIGNX_PARSECERT: {
            printf("============================================== parseCert\n");
            printf("res.respid=%d\n", pResp->respid);
            printf("res.data=%s\n", pResp->data->getDataString().c_str());

            if (0 == pResp->errCode) {
                printf("successful...\n");
                mapRespData[pResp->respid] = pResp->data->getDataString();
            } else {
                printf("failure..., res.errCode=%#x\n", pResp->errCode);
            }
        } break;
        case MSG_SIGNX_ENVELOPEENC: {
            printf("============================================== envelopeEncrypt\n");
            printf("res.respid=%d\n", pResp->respid);
            printf("res.data=%s\n", pResp->data->getDataString().c_str());

            if (0 == pResp->errCode) {
                printf("successful...\n");
                mapRespData[pResp->respid] = pResp->data->getDataString();
            } else {
                printf("failure..., res.errCode=%#x\n", pResp->errCode);
            }

            AsyncSignX *pSignx = (AsyncSignX *)pUserData;
            std::string envelopeEncrypt;
            parseEnvelopeEncryptResp(pResp->data->getDataString(), envelopeEncrypt);
            pSignx->asyncSetEnvelopeEncryptData(envelopeEncrypt);
        } break;
        case MSG_SIGNX_ENVELOPEDEC: {
            printf("============================================== envelopeDecrypt\n");
            printf("res.respid=%d\n", pResp->respid);
            printf("res.data=%s\n", pResp->data->getDataString().c_str());

            if (0 == pResp->errCode) {
                printf("successful...\n");
                mapRespData[pResp->respid] = pResp->data->getDataString();
            } else {
                printf("failure..., res.errCode=%#x\n", pResp->errCode);
            }
        } break;
        case MSG_SIGNX_EXTECCCERTVERIFYP7: {
            printf("============================================== verifySignedMessage\n");
            printf("res.respid=%d\n", pResp->respid);

            if (0 == pResp->errCode) {
                printf("successful...\n");
            } else {
                printf("failure..., res.errCode=%#x\n", pResp->errCode);
            }
        } break;
        default:
            break;
    }
    return true;
}

bool callBack(const PKI_SERVICE *pSvc, const kpkiResp *pResp, void *pUserData) {
    if (NULL == pSvc || NULL == pResp) {
        printf("CallBack error, pSvc=%#x, pResp=%#x", pSvc, pResp);
        return false;
    }

    PKI_SERVICE svc = *pSvc;
    switch (svc) {
        case ENROLLSERVICE:
            resp_ENROLLSERVICE(pResp, pUserData);
            break;
        case DEVSERVICE:
            resp_DEVICESERVICE(pResp, pUserData);
            break;
        case SIGNXSERVICE:
            resp_SIGNXLSERVICE(pResp, pUserData);
            break;
        default:
            break;
    }
    return true;
}

#ifndef _ASYNC  ///同步请求
int main(int argc, char **argv) {
    doctest::Context context(argc, argv);
    int testResult = 0;

    const char *pTest = "this is testing";

    ///初始化AGENT
    do {
        if (!createAgent(&msgNotify, NULL, (void *)pTest)) {
            printf("create Agent failed\n");
            break;
        }
        ///登录
        if (!loginAgent("11111-111", "22222-222", "33333-33")) {
            printf("login failed");
            break;
        }

        /// do something
        // 启动doctest测试用例
        testResult = context.run();
        ///登出
        logoutAgent();
        ///释放agent
        releaseAgent();
    } while (0);

    if (context.shouldExit()) {
        return testResult;
    }

    return 0;
}
#else  ///异步请求
int main(int argc, char **argv) {
    std::list<int> listReqId;  ///管理异步请求的消息id
    int reqid = 0;

    ///初始化AGENT
    do {
        if (!createAgent(&msgNotify, &callBack)) {
            printf("create Agent failed\n");
            break;
        }
        ///登录
        if (!loginAgent("11111-111", "22222-222", "33333-33")) {
            printf("login failed");
            break;
        }

        /// 示例。与同步调用方式相同，故异步调用仅列举部分接口
        reqid = gDevice.asyncGetDevices();
        listReqId.push_back(reqid);

        /// devid
        Sleep(3 * 1000);
        gDevId = gDevice.asyncGetDevID();

        reqid = gDevice.asyncGetDevInfo(gDevId);
        listReqId.push_back(reqid);

        reqid = gDevice.asyncSetDevLable(gDevId, "GM3000");
        listReqId.push_back(reqid);

        reqid = gDevice.asyncGetAllCert();
        listReqId.push_back(reqid);

        /// reqid = gEnRoll.asyncGenKeypair(gDevId, "", ...);

        /// reqid = gSignx.asyncSignData(gDevId, "",  ...);
    } while (0);

    Sleep(3 * 1000);
    /**
            说明：若异步请求调用结束后，直接调用logoutAgent、releaseAgent可能会导致部分异步接口请求的数据未处理完。
                      故logoutAgent、releaseAgent交由上层,根据对应业务场景需求，决定何时调用登出、释放接口。
    */
    ///登出
    logoutAgent();
    ///释放agent
    releaseAgent();
    return 0;
}
#endif