#include "asyncClient.h"
#include "pkiAgent4c.h"
#include "jsonProtocol.h"

namespace koal {
namespace testAgent {
/**
 * @description: 获取设备ID
 * @param {null}
 * @return: 设备ID
 */
std::string AsyncDevice::asyncGetDevID() { return mDevID; }

/**
 * @description: 设置设备ID
 * @param {devId} 设备ID
 * @return: true：成功，false：失败
 */
bool AsyncDevice::asyncSetDevID(std::string devId) {
    if (devId.empty()) {
        return false;
    }
    mDevID = devId;
    return true;
}

/**
 * @description: 获取设备列表
 * @param {null}
 * @return: reqid，消息id。用于区分消息，与响应消息respid相同
 */
int AsyncDevice::asyncGetDevices() {
    kpkiReq req;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_GETDEVICES;
    return reqAsync(DEVSERVICE, &req, this);
}

/**
 * @description: 获取设备信息
 * @param {devId} 设备ID
 * @return: reqid，消息id。用于区分消息，与响应消息respid相同
 */
int AsyncDevice::asyncGetDevInfo(const std::string &devId) {
    kpkiReq req;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_GETDEVINFO;

    std::string json = buildGetDevInfoReq(devId);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());
    return reqAsync(DEVSERVICE, &req, NULL);
}

/**
 * @description: 设置设备标签
 * @param {devId} 设备ID
 * @param {lable} 设备标签
 * @return: reqid，消息id。用于区分消息，与响应消息respid相同
 */
int AsyncDevice::asyncSetDevLable(const std::string &devId, const std::string &lable) {
    kpkiReq req;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_SETDEVLABLE;

    std::string json = buildSetDevLableReq(devId, lable);
    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());
    return reqAsync(DEVSERVICE, &req, NULL);
}

/**
 * @description: 设备命令传输
 * @param {devId} 设备ID
 * @param {command} 用于填写与用户约定的命令号
 * @return: reqid，消息id。用于区分消息，与响应消息respid相同
 */
int AsyncDevice::asyncTransMitData(const std::string &devId, const std::string &command) {
    kpkiReq req;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_TRANSMITDATA;

    std::string json = buildTransMitDataReq(devId, command);
    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());
    return reqAsync(DEVSERVICE, &req, NULL);
}

/**
 * @description: 设备认证
 * @param {devId} 设备ID
 * @param {authData} 认证数据(base64编码)
 * @return: reqid，消息id。用于区分消息，与响应消息respid相同
 */
int AsyncDevice::asyncDevAuth(const std::string &devId, const std::string &authData) {
    kpkiReq req;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_DEVAUTH;

    std::string json = buildDevAuthReq(devId, authData);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());
    return reqAsync(DEVSERVICE, &req, NULL);
}

/**
 * @description: 修改设备认证秘钥
 * @param {type} 设备ID
 * @param {type} 认证数据(base64编码)
 * @return: reqid，消息id。用于区分消息，与响应消息respid相同
 */
int AsyncDevice::asyncChangeAuthKey(const std::string &devId, const std::string &authData) {
    kpkiReq req;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_CHANGEAUTHKEY;

    std::string json = buildChangeAuthKeyReq(devId, authData);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());
    return reqAsync(DEVSERVICE, &req, NULL);
}

/**
 * @description: 获取PIN
 * @param {devId} 设备ID
 * @param {appName} 应用名称
 * @param {PINType} PIN类型。0为ADMIN_TYPE，1为USER_TYPE
 * @return: reqid，消息id。用于区分消息，与响应消息respid相同
 */
int AsyncDevice::asyncGetPINInfo(const std::string &devId, const std::string &appName, const uint32 &PINType) {
    kpkiReq req;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_GETPININFO;

    std::string json = buildGetPINInfoReq(devId, appName, PINType);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());
    return reqAsync(DEVSERVICE, &req, NULL);
}

/**
 * @description: 修改PIN
 * @param {devId} 设备ID
 * @param {appName} 应用名称
 * @param {PINType} PIN类型。0为ADMIN_TYPE，1为USER_TYPE
 * @param {oldPIN} 旧PIN
 * @param {newPIN} 新PIN
 * @return: reqid，消息id。用于区分消息，与响应消息respid相同
 */
int AsyncDevice::asyncChangePIN(const std::string &devId, const std::string &appName, const uint32 &PINType, const std::string &oldPIN,
                                const std::string &newPIN) {
    kpkiReq req;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_CHANGEPIN;

    std::string json = buildChangePINReq(devId, appName, PINType, oldPIN, newPIN);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());
    return reqAsync(DEVSERVICE, &req, NULL);
}

/**
 * @description: 校验PIN
 * @param {devId} 设备ID
 * @param {appName} 应用名称
 * @param {PINType} PIN类型。0为ADMIN_TYPE，1为USER_TYPE
 * @param {PIN} PIN码
 * @return: reqid，消息id。用于区分消息，与响应消息respid相同
 */
int AsyncDevice::asyncVerifyPIN(const std::string &devId, const std::string &appName, const uint32 &PINType, const std::string &PIN) {
    kpkiReq req;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_VERIFYPIN;

    std::string json = buildVerifyPINReq(devId, appName, PINType, PIN);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());
    return reqAsync(DEVSERVICE, &req, NULL);
}

/**
 * @description: 解锁PIN码
 * @param {devId} 设备ID
 * @param {appName} 应用名称
 * @param {adminPIN} 管理员PIN
 * @param {userPIN} 用户PIN
 * @return: reqid，消息id。用于区分消息，与响应消息respid相同
 */
int AsyncDevice::asyncUnlockPIN(const std::string &devId, const std::string &appName, const std::string &adminPIN, const std::string &userPIN) {
    kpkiReq req;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_UNLOCKPIN;

    std::string json = buildUnlockPINReq(devId, appName, adminPIN, userPIN);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());
    return reqAsync(DEVSERVICE, &req, NULL);
}

/**
 * @description: 获取应用列表
 * @param {devId} 设备ID
 * @return: reqid，消息id。用于区分消息，与响应消息respid相同
 */
int AsyncDevice::asyncGetAppList(const std::string &devId) {
    kpkiReq req;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_GETAPPLIST;

    std::string json = buildGetAppListReq(devId);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());
    return reqAsync(DEVSERVICE, &req, NULL);
}

/**
 * @description: 创建应用
 * @param {devId} 设备ID
 * @param {appName} 应用名称
 * @param {admin_PIN} 管理员PIN
 * @param {admin_maxRetryCount} 最大重试次数
 * @param {user_PIN} 用户PIN
 * @param {user_maxRetryCount} 最大重试次数
 * @param {fileRight} 创建文件和容器的权限
 * @return: reqid，消息id。用于区分消息，与响应消息respid相同
 */
int AsyncDevice::asyncCreateApp(const std::string &devId, const std::string &appName, const std::string &admin_PIN, const uint32 &admin_maxRetryCount,
                                const std::string &user_PIN, const uint32 &user_maxRetryCount, const uint32 &fileRight) {
    kpkiReq req;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_CREATEAPP;

    std::string json = buildCreateAppReq(devId, appName, admin_PIN, admin_maxRetryCount, user_PIN, user_maxRetryCount, fileRight);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());
    return reqAsync(DEVSERVICE, &req, NULL);
}

/**
 * @description: 删除应用
 * @param {devId} 设备ID
 * @param {appName} 应用名称
 * @return: reqid，消息id。用于区分消息，与响应消息respid相同
 */
int AsyncDevice::asyncDelApp(const std::string &devId, const std::string &appName) {
    kpkiReq req;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_DELAPP;

    std::string json = buildDelAppReq(devId, appName);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());
    return reqAsync(DEVSERVICE, &req, NULL);
}

/**
 * @description: 获取容器列表
 * @param {devId} 设备ID
 * @param {appName} 应用名称
 * @return: reqid，消息id。用于区分消息，与响应消息respid相同
 */
int AsyncDevice::asyncGetContainers(const std::string &devId, const std::string &appName) {
    kpkiReq req;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_GETCONTAINERS;

    std::string json = buildGetContainersReq(devId, appName);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());
    return reqAsync(DEVSERVICE, &req, NULL);
}

/**
 * @description: 创建容器
 * @param {devId} 设备ID
 * @param {appName} 应用名称
 * @param {containerName} 容器名称
 * @return: reqid，消息id。用于区分消息，与响应消息respid相同
 */
int AsyncDevice::asyncCreateContainer(const std::string &devId, const std::string &appName, const std::string &containerName) {
    kpkiReq req;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_CREATECONTAINER;

    std::string json = buildCreateContainerReq(devId, appName, containerName);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());
    return reqAsync(DEVSERVICE, &req, NULL);
}

/**
 * @description: 删除容器
 * @param {devId} 设备ID
 * @param {appName} 应用名称
 * @param {containerName} 容器名称
 * @return: reqid，消息id。用于区分消息，与响应消息respid相同
 */
int AsyncDevice::asyncDelContainer(const std::string &devId, const std::string &appName, const std::string &containerName) {
    kpkiReq req;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_DELCONTAINER;

    std::string json = buildDelContainerReq(devId, appName, containerName);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());
    return reqAsync(DEVSERVICE, &req, NULL);
}

/**
 * @description: 获取容器类型
 * @param {devId} 设备ID
 * @param {appName} 应用名称
 * @param {containerName} 容器名称
 * @return: reqid，消息id。用于区分消息，与响应消息respid相同
 */
int AsyncDevice::asyncGetContainerType(const std::string &devId, const std::string &appName, const std::string &containerName) {
    kpkiReq req;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_GETCONTAINERTYPE;

    std::string json = buildGetContainerTypeReq(devId, appName, containerName);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());
    return reqAsync(DEVSERVICE, &req, NULL);
}

/**
 * @description: 导入数字证书
 * @param {devId} 设备ID
 * @param {appName} 应用名称
 * @param {containerName} 容器名称
 * @param {signFlag} 1表示签名证书，0表示加密证书
 * @param {cert} 证书内容(base64编码)
 * @return: reqid，消息id。用于区分消息，与响应消息respid相同
 */
int AsyncDevice::asyncImportCertificate(const std::string &devId, const std::string &appName, const std::string &containerName,
                                        const uint32 &signFlag, const std::string &cert) {
    kpkiReq req;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_IMPORTCERTIFICATE;

    std::string json = buildImportCertificateReq(devId, appName, containerName, signFlag, cert);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());
    return reqAsync(DEVSERVICE, &req, NULL);
}

/**
 * @description: 导出数字证书
 * @param {devId} 设备ID
 * @param {appName} 应用名称
 * @param {containerName} 容器名称
 * @param {signFlag} 1表示签名证书，0表示加密证书
 * @return: reqid，消息id。用于区分消息，与响应消息respid相同
 */
int AsyncDevice::asyncExportCertificate(const std::string &devId, const std::string &appName, const std::string &containerName,
                                        const uint32 &signFlag) {
    kpkiReq req;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_EXPORTCERTIFICATE;

    std::string json = buildExportCertificatReq(devId, appName, containerName, signFlag);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());
    return reqAsync(DEVSERVICE, &req, NULL);
}

/**
 * @description: 获取证书列表
 * @param {NULL}
 * @return: reqid，消息id。用于区分消息，与响应消息respid相同
 */
int AsyncDevice::asyncGetAllCert() {
    kpkiReq req;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_GETALLCERT;

    return reqAsync(DEVSERVICE, &req, NULL);
}

/**
 * @description: 导出公钥
 * @param {devId} 设备ID
 * @param {appName} 应用名称
 * @param {containerName} 容器名称
 * @param {signFlag} 1表示签名公钥，0表示加密公钥
 * @return: reqid，消息id。用于区分消息，与响应消息respid相同
 */
int AsyncDevice::asyncExportPublicKey(const std::string &devId, const std::string &appName, const std::string &containerName,
                                      const uint32 &signFlag) {
    kpkiReq req;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_EXPORTPUBLICKEY;

    std::string json = buildExportPublicKeyReq(devId, appName, containerName, signFlag);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());
    return reqAsync(DEVSERVICE, &req, NULL);
}

/**
 * @description: 外来公钥加密
 * @param {devId} 设备ID
 * @param {pubKey} 公钥(base64编码)
 * @param {type} 1表示RSA,2表示ECC
 * @param {srcData} 源数据(base64编码)
 * @return: reqid，消息id。用于区分消息，与响应消息respid相同
 */
int AsyncDevice::asyncExtPubKeyEncrypt(const std::string &devId, const std::string &pubKey, const uint32 &type, const std::string &srcData) {
    kpkiReq req;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_EXTPUBKEYENCRYPT;

    std::string json = buildExtPubKeyEncryptReq(devId, pubKey, type, srcData);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());
    return reqAsync(DEVSERVICE, &req, NULL);
}

/**
 * @description: 外来私钥解密
 * @param {devId} 设备ID
 * @param {priKey} 私钥(base64编码)
 * @param {type} 1表示RSA,2表示ECC
 * @param {encryptData} 密文数据(base64编码)
 * @return: reqid，消息id。用于区分消息，与响应消息respid相同
 */
int AsyncDevice::asyncExtPriKeyDecrypt(const std::string &devId, const std::string &priKey, const uint32 &type, const std::string &encryptData) {
    kpkiReq req;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_EXTPRIKEYDECRYPT;

    std::string json = buildExtPriKeyDecryptReq(devId, priKey, type, encryptData);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());
    return reqAsync(DEVSERVICE, &req, NULL);
}

/**
 * @description: 获取provider列表
 * @param {NULL}
 * @return: reqid，消息id。用于区分消息，与响应消息respid相同
 */
int AsyncDevice::asyncGetProviders() {
    kpkiReq req;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_GETPROVIDERS;

    return reqAsync(DEVSERVICE, &req, NULL);
}

/**
 * @description: 设置provider
 * @param {name} provider name
 * @param {VPID} provider VPID, like ["055C_F603","055C_F604"]
 * @return: reqid，消息id。用于区分消息，与响应消息respid相同
 */
int AsyncDevice::asyncSetProvider(const std::string &name, const std::string &VPID) {
    kpkiReq req;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_SETPROVIDER;

    std::string json = buildSetProviderReq(name, VPID);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());
    return reqAsync(DEVSERVICE, &req, NULL);
}

/**
 * @description: 指纹初始化
 * @param {devId} 设备id
 * @param {type} 指纹类型
 * @return: reqid，消息id。用于区分消息，与响应消息respid相同
 */
int AsyncDevice::asyncInitFinger(const std::string &devId, const unsigned int &type) {
    kpkiReq req;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_INITFINGER;

    std::string json = buildInitFingerReq(devId, type);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());
    return reqAsync(DEVSERVICE, &req, NULL);
}

/**
 * @description: 是否存在指纹
 * @param {devId} 设备id
 * @param {appName} 应用名称
 * @param {type} 指纹类型
 * @return: reqid，消息id。用于区分消息，与响应消息respid相同
 */
int AsyncDevice::asyncHasFinger(const std::string &devId, const std::string &appName, const unsigned int &type) {
    kpkiReq req;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_HASFINGER;

    std::string json = buildHasFingerReq(devId, appName, type);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());
    return reqAsync(DEVSERVICE, &req, NULL);
}

/**
 * @description: 验证指纹
 * @param {devId} 设备id
 * @param {appName} 应用名称
 * @param {type} 指纹类型
 * @return: reqid，消息id。用于区分消息，与响应消息respid相同
 */
int AsyncDevice::asyncVerifyFinger(const std::string &devId, const std::string &appName, const unsigned int &type) {
    kpkiReq req;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_VERIFYFINGER;

    std::string json = buildVerifyFingerReq(devId, appName, type);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());
    return reqAsync(DEVSERVICE, &req, NULL);
}

/**
 * @description: 取消指纹
 * @param {devId} 设备id
 * @return: reqid，消息id。用于区分消息，与响应消息respid相同
 */
int AsyncDevice::asyncCancleFinger(const std::string &devId) {
    kpkiReq req;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_SETPROVIDER;

    std::string json = buildCancleFingerReq(devId);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());
    return reqAsync(DEVSERVICE, &req, NULL);
}

/**
 * @description: 创建文件
 * @param {devId} 设备id
 * @param {appName} 应用名
 * @param {fileName}	文件名
 * @param {fileSize} 文件大小
 * @param {readRights} 读权限
 * @param {writeRights} 写权限
 * @return: reqid，消息id。用于区分消息，与响应消息respid相同
 */
int AsyncDevice::asyncCreateFile(const std::string &devId, const std::string &appName, const std::string &fileName, const unsigned int &fileSize,
                                 const unsigned int &readRights, const unsigned int &writeRights) {
    kpkiReq req;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_CERATEFILE;

    std::string json = buildCreateFileReq(devId, appName, fileName, fileSize, readRights, writeRights);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    return reqAsync(DEVSERVICE, &req, NULL);
}

/**
 * @description: 删除文件
 * @param {devId} 设备id
 * @param {appName} 应用名
 * @param {fileName}	文件名
 * @return: reqid，消息id。用于区分消息，与响应消息respid相同
 */
int AsyncDevice::asyncDeleteFile(const std::string &devId, const std::string &appName, const std::string &fileName) {
    kpkiReq req;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_DELETEFILE;

    std::string json = buildDeleteFileReq(devId, appName, fileName);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    return reqAsync(DEVSERVICE, &req, NULL);
}

/**
 * @description: 获取文件列表
 * @param {devId} 设备id
 * @param {appName} 应用名
 * @return: reqid，消息id。用于区分消息，与响应消息respid相同
 */
int AsyncDevice::asyncGetFileList(const std::string &devId, const std::string &appName) {
    kpkiReq req;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_GETFILELIST;

    std::string json = buildGetFileListReq(devId, appName);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    return reqAsync(DEVSERVICE, &req, NULL);
}

/**
 * @description: 获取文件属性
 * @param {devId} 设备id
 * @param {appName} 应用名
 * @param {fileName}	文件名
 * @return: reqid，消息id。用于区分消息，与响应消息respid相同
 */
int AsyncDevice::asyncGetFileInfo(const std::string &devId, const std::string &appName, const std::string &fileName) {
    kpkiReq req;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_GETFILEINFO;

    std::string json = buildGetFileInfoReq(devId, appName, fileName);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    return reqAsync(DEVSERVICE, &req, NULL);
}

/**
 * @description: 读文件
 * @param {devId} 设备id
 * @param {appName} 应用名
 * @param {fileName}	文件名
 * @param {offset} 文件读取偏移位置
 * @param {size} 读取的长度
 * @return: reqid，消息id。用于区分消息，与响应消息respid相同
 */
int AsyncDevice::asyncReadFile(const std::string &devId, const std::string &appName, const std::string &fileName, unsigned int &offset,
                               unsigned int &size) {
    kpkiReq req;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_READFILE;

    std::string json = buildReadFileReq(devId, appName, fileName, offset, size);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    return reqAsync(DEVSERVICE, &req, NULL);
}

/**
 * @description: 写文件
 * @param {devId} 设备id
 * @param {appName} 应用名
 * @param {fileName}	文件名
 * @param {offset} 文件读取偏移位置
 * @param {data} 写入的数据
 * @return: reqid，消息id。用于区分消息，与响应消息respid相同
 */
int AsyncDevice::asyncWriteFile(const std::string &devId, const std::string &appName, const std::string &fileName, unsigned int &offset,
                                const std::string &data) {
    kpkiReq req;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_DEVICE_WRITEFILE;

    std::string json = buildWriteFileReq(devId, appName, fileName, offset, data);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    return reqAsync(DEVSERVICE, &req, NULL);
}
/* enRoll */

/**
 * @description: 创建P10请求
 * @param {devId} 设备ID
 * @param {appName} 应用名称
 * @param {conName} 容器名称
 * @param {dn} DN项
 * @param {extensionType} 临时密钥扩展项，1.不携带，2.携带临时密钥，其他值.协同模式
 * @return: reqid，消息id。用于区分消息，与响应消息respid相同
 */
int AsyncEnRoll::asyncMakePkcs10(const std::string &devId, const std::string &appName, const std::string &conName, const std::string &dn,
                                 const int &extensionType, const int &reqDigst) {
    kpkiReq req;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_ENROLL_MKP10;

    std::string json = buildMakePkcs10Req(devId, appName, conName, dn, extensionType, reqDigst);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());
    return reqAsync(ENROLLSERVICE, &req, NULL);
}

/**
 * @description: 生成密钥对
 * @param {devId} 设备ID
 * @param {appName} 应用名称
 * @param {conName} 容器名称
 * @param {keyType} 0:SM2,1:RSA
 * @param {keyLen} KeyType为rsa时有效
 * @param {purpose} keyType为SM2时候有效（目前key不支持2）,1. SGD_SM2_1,2. SGD_SM2_3
 * @return: reqid，消息id。用于区分消息，与响应消息respid相同
 */
int AsyncEnRoll::asyncGenKeypair(const std::string &devId, const std::string &appName, const std::string &conName, const std::string &keyType,
                                 const std::string &keyLen, const uint32 &purpose) {
    kpkiReq req;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_ENROLL_KEYPAIR;

    std::string json = buildGenb64KeypairReq(devId, appName, conName, keyType, keyLen, purpose);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());
    return reqAsync(ENROLLSERVICE, &req, NULL);
}

/**
 * @description: 导入密钥对
 * @param {devId} 设备ID
 * @param {appName} 应用名称
 * @param {conName} 容器名称
 * @param {b64Key} 密钥对
 * @return: reqid，消息id。用于区分消息，与响应消息respid相同
 */
int AsyncEnRoll::asyncImportEncKeypair(const std::string &devId, const std::string &appName, const std::string &conName, const std::string &b64Key) {
    kpkiReq req;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_ENROLL_IMPORTKEYPAIR;

    std::string json = buildImportEncReq(devId, appName, conName, b64Key);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());
    return reqAsync(ENROLLSERVICE, &req, NULL);
}

/**
 * @description: 导入证书
 * @param {devId} 设备ID
 * @param {appName} 应用名称
 * @param {conName} 容器名称
 * @param {tyb64certpe} 证书(base64编码)
 * @param {purpose} 1表示签名证书,0表示加密证书
 * @return: reqid，消息id。用于区分消息，与响应消息respid相同
 */
int AsyncEnRoll::asyncImportX509Cert(const std::string &devId, const std::string &appName, const std::string &conName, const std::string &b64cert,
                                     const std::string &purpose) {
    kpkiReq req;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_ENROLL_IMPORTX509;

    std::string json = buildInstallCertReq(devId, appName, conName, b64cert, purpose);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());
    return reqAsync(ENROLLSERVICE, &req, NULL);
}

/**
 * @description: 导入pfx证书
 * @param {devId} 设备ID
 * @param {appName} 应用名称
 * @param {conName} 容器名称
 * @param {b64cert} pfx证书(base64编码)
 * @param {certPass} 密码
 * @return: reqid，消息id。用于区分消息，与响应消息respid相同
 */
int AsyncEnRoll::asyncImportPfxCert(const std::string &devId, const std::string &appName, const std::string &conName, const std::string &b64cert,
                                    const std::string &certPass) {
    kpkiReq req;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_ENROLL_IMPORTPFX;

    std::string json = buildImportPfxReq(devId, appName, conName, b64cert, certPass);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());
    return reqAsync(ENROLLSERVICE, &req, NULL);
}

/**
 * @description: 导出证书
 * @param {devId} 设备ID
 * @param {appName} 应用名称
 * @param {conName} 容器名称
 * @param {certType} 1表示签名证书, 0表示加密证书
 * @return: reqid，消息id。用于区分消息，与响应消息respid相同
 */
int AsyncEnRoll::asyncGetCert(const std::string &devId, const std::string &appName, const std::string &conName, const std::string &certType) {
    kpkiReq req;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_ENROLL_GETCERT;

    std::string json = buildGetb64certReq(devId, appName, conName, certType);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());
    return reqAsync(ENROLLSERVICE, &req, NULL);
}

/**
 * @description: 导入pfx证书到skffile
 * @param {devId} 设备ID
 * @param {appName} 应用名称
 * @param {conName} 容器名称
 * @param {b64cert} pfx证书(base64编码)
 * @param {certPass} 密码
 * @return: 0：成功, 其他：失败
 */
int AsyncEnRoll::asyncImportPfx2SkfFile(const std::string &devId, const std::string &appName, const std::string &conName, unsigned int signFlag,
                                        const std::string &certPass, const std::string &b64cert) {
    printf("============================================== importPfx2SkfFile\n");
    kpkiReq req;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_ENROLL_IMPORTPFX2SKFILE;

    std::string json = buildImportPfx2SkfFileReq(devId, appName, conName, signFlag, certPass, b64cert);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    return reqAsync(ENROLLSERVICE, &req, NULL);
}

/* signX */
/**
 * @description:  获取签名数据，用于测试
 * @param {null}
 * @return: std::string
 */
std::string &AsyncSignX::asyncGetSignData() { return mSignData; }

/**
 * @description:  设置签名数据，用于测试
 * @param {null}
 * @return: true: 成功， false：失败
 */
bool AsyncSignX::asyncSetSignData(std::string data) {
    if (data.empty()) {
        return false;
    }
    mSignData = data;
    return true;
}

/**
 * @description: 获取签名数据，用于测试
 * @param {null}
 * @return: std::string
 */
std::string &AsyncSignX::asyncGetP7SignData() { return mP7SignData; }

/**
 * @description:  设置签名数据，用于测试
 * @param {null}
 * @return: true: 成功， false：失败
 */
bool AsyncSignX::asyncSetP7SignData(std::string data) {
    if (data.empty()) {
        return false;
    }
    mP7SignData = data;
    return true;
}

/**
 * @description: 获取组p7数字信封数据，用于测试
 * @param {null}
 * @return: std::string
 */
std::string &AsyncSignX::asyncGetEnvelopeEncryptData() { return mEnvelopeEncrypt; }

/**
 * @description:  设置组p7数字信封数据，用于测试
 * @param {null}
 * @return: true: 成功， false：失败
 */
bool AsyncSignX::asyncSetEnvelopeEncryptData(std::string data) {
    if (data.empty()) {
        return false;
    }
    mEnvelopeEncrypt = data;
    return true;
}

/**
 * @description: 数据签名
 * @param {devId} 设备ID
 * @param {appName} 应用名称
 * @param {conName} 容器名称
 * @param {srcData} 待签名数据，base64加密
 * @param {isBase64SrcData} 是否为base64编码源数据，1表示是，0表示否
 * @param {type} 签名类型,1表示PM-BD签名,2表示SM2/RSA签名,3 SSL建链定制签名
 * @return: reqid，消息id。用于区分消息，与响应消息respid相同
 */
int AsyncSignX::asyncSignData(const std::string &devId, const std::string &appName, const std::string &conName, const std::string &srcData,
                              const uint32 &isBase64SrcData, const std::string &type) {
    kpkiReq req;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_SIGNX_SIGNDATA;

    std::string json = buildSignDataReq(devId, appName, conName, srcData, isBase64SrcData, type);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());
    return reqAsync(SIGNXSERVICE, &req, this);
}

/**
 * @description: 验证签名
 * @param {devId} 设备ID
 * @param {appName} 应用名称
 * @param {conName} 容器名称
 * @param {srcData} 签名源数据，base64编码
 * @param {signData} 签名数据，base64编码
 * @param {isBase64SrcData} 是否为base64编码源数据，1表示是，0表示否
 * @param {type} 签名类型,1表示PM-BD验签,2表示SM2/RSA验签
 * @return: reqid，消息id。用于区分消息，与响应消息respid相同
 */
int AsyncSignX::asyncVerifySignData(const std::string &devId, const std::string &appName, const std::string &conName, const std::string &srcData,
                                    const std::string &signData, const uint32 &isBase64SrcData, const uint32 &type) {
    kpkiReq req;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_SIGNX_VERIFYSIGN;

    std::string json = buildVerifyDataReq(devId, appName, conName, srcData, signData, isBase64SrcData, type);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());
    return reqAsync(SIGNXSERVICE, &req, NULL);
}

/**
 * @description: p7签名
 * @param {devId} 设备ID
 * @param {appName} 应用名称
 * @param {conName} 容器名称
 * @param {srcData} 待签名数据(base64编码)
 * @param {mdType} 0表示PKCS7_DETACHED
 * @param {attachData} 指定的摘要类型,"1"-MD5 "2"-SHA1 "3"-SM3 "4"-SHA256
 * @param {signwithSM2Std} 用于sm2签名，1表示使用SM2规范，0表示使用RFC规范，默认0
 * @return: reqid，消息id。用于区分消息，与响应消息respid相同
 */
int AsyncSignX::asyncSignMessage(const std::string &devId, const std::string &appName, const std::string &conName, const std::string &srcData,
                                 const uint32 &mdType, const std::string &attachData, const uint32 &signwithSM2Std) {
    kpkiReq req;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_SIGNX_SIGNP7;

    std::string json = buildPkcs7SignReq(devId, appName, conName, srcData, mdType, attachData, signwithSM2Std);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());
    return reqAsync(SIGNXSERVICE, &req, this);
}

/**
 * @description: p7验证签名
 * @param {srcData} 签名数据的源数据(base64)
 * @param {signData} 签名数据(base64)
 * @return: reqid，消息id。用于区分消息，与响应消息respid相同
 */
int AsyncSignX::asyncVerifyMessage(const std::string &srcData, const std::string &signData) {
    kpkiReq req;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_SIGNX_VERIFYSIGNP7;

    std::string json = buildPkcs7VerifyReq(srcData, signData);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());
    return reqAsync(SIGNXSERVICE, &req, NULL);
}

/**
 * @description: 外来公钥验签
 * @param {devId} 设备ID
 * @param {pubkey} 公钥
 * @param {srcData} 签名数据的源数据(base64编码)
 * @param {signData} 签名数据(base64编码)
 * @return: reqid，消息id。用于区分消息，与响应消息respid相同
 */
int AsyncSignX::asyncExtECCVerify(const std::string &devId, const std::string &pubkey, const std::string &srcData, const std::string &signData) {
    kpkiReq req;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_SIGNX_EXTECCPUBVERIFY;

    std::string json = buildExPubVerifyReq(devId, pubkey, srcData, signData);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());
    return reqAsync(SIGNXSERVICE, &req, NULL);
}

/**
 * @description: 外来证书验签
 * @param {devId} 设备ID
 * @param {b64cert} 证书内容(base64)
 * @param {srcData} 签名数据的源数据(base64编码)
 * @param {signData} 签名数据(base64编码)
 * @return: reqid，消息id。用于区分消息，与响应消息respid相同
 */
int AsyncSignX::asyncExtECCVerifyEx(const std::string &devId, const std::string &b64cert, const std::string &srcData, const std::string &signData) {
    kpkiReq req;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_SIGNX_EXTECCCERTVERIFY;

    std::string json = buildExCertVerifyReq(devId, b64cert, srcData, signData);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());
    return reqAsync(SIGNXSERVICE, &req, NULL);
}

/**
 * @description: 生成证书
 * @param {devId} 设备ID
 * @param {appName} 应用名称
 * @param {conName} 容器名称
 * @param {signFlag} 1表示签名证书,0表示加密证书
 * @return: reqid，消息id。用于区分消息，与响应消息respid相同
 */
int AsyncSignX::asyncDupCertWithTemplate(const std::string &devId, const std::string &appName, const std::string &conName,
                                         const std::string &signFlag) {
    kpkiReq req;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_SIGNX_MKCERTFROMTEMP;

    std::string json = buildDupb64certWithTemplateReq(devId, appName, conName, signFlag);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());
    return reqAsync(SIGNXSERVICE, &req, NULL);
}

/**
 * @description: 解析证书
 * @param {cert} 证书内容(base64编码)
 * @return: reqid，消息id。用于区分消息，与响应消息respid相同
 */
int AsyncSignX::asyncParseCert(const std::string cert) {
    kpkiReq req;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_SIGNX_PARSECERT;

    std::string json = buildCertParseReq(cert);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());
    return reqAsync(SIGNXSERVICE, &req, NULL);
}

/**
 * @description: 组p7数字信封
 * @param {srcData} 待签名数据(base64编码)
 * @param {cert} 证书
 * @param {cihperType} 0"-DES "1"-3DES "2"-AES "3"-SM4
 * @return: reqid，消息id。用于区分消息，与响应消息respid相同
 */
int AsyncSignX::asyncEnvelopeEncrypt(const std::string &srcData, const std::string &cert, const uint32 &cihperType) {
    kpkiReq req;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_SIGNX_ENVELOPEENC;

    std::string json = buildEnvelopeEncryptReq(srcData, cert, cihperType);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());
    return reqAsync(SIGNXSERVICE, &req, this);
}

/**
 * @description: 解p7数字信封
 * @param {devId} 设备ID
 * @param {appName} 应用名称
 * @param {conName} 容器名称
 * @param {srcData} 密文数据
 * @return: reqid，消息id。用于区分消息，与响应消息respid相同
 */
int AsyncSignX::asyncEnvelopeDecrypt(const std::string &devId, const std::string &appName, const std::string &conName, const std::string &srcData) {
    kpkiReq req;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_SIGNX_ENVELOPEDEC;

    std::string json = buildEnvelopeDecryptReq(devId, appName, conName, srcData);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());
    return reqAsync(SIGNXSERVICE, &req, NULL);
}

/**
 * @description: p7外部证书验签
 * @param {devId} 设备ID
 * @param {appName} 应用名称
 * @param {conName} 容器名称
 * @param {srcData} 签名数据的源数据(base64)
 * @param {signData} 签名数据(base64)
 * @param {cert} 证书
 * @return: reqid，消息id。用于区分消息，与响应消息respid相同
 */
int AsyncSignX::asyncVerifySignedMessage(const std::string &srcData, const std::string &signData, const std::string &cert) {
    kpkiReq req;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_SIGNX_EXTECCCERTVERIFYP7;

    std::string json = buildVerifySignedMessageReq(srcData, signData, cert);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());
    return reqAsync(SIGNXSERVICE, &req, NULL);
}

/**
 * @description: 获取证书扩展项
 * @param {cert} 证书
 * @param {oid} oid
 * @return: reqid，消息id。用于区分消息，与响应消息respid相同
 */
int AsyncSignX::asyncGetExtension(const std::string &cert, const std::string &oid) {
    kpkiReq req;
    req.version = 0x01;
    req.extend = 0x00;
    req.msgType = MSG_SIGNX_GETEXTENSION;

    std::string json = buildGetExtensionReq(cert, oid);

    req.data->setSize(json.length() + 1);
    strncpy((char *)req.data->getData(), json.c_str(), json.length());

    return reqAsync(SIGNXSERVICE, &req, NULL);
}
#if 0
	/**
 	* @description: 设置文本主体
 	* @param {body} 文本主体
 	* @return: reqid，消息id。用于区分消息，与响应消息respid相同
 	*/ 
	int AsyncKmail::asyncSetTextBody(const std::string & body) {
		kpkiReq req;
		req.version = 0x01;
		req.extend	= 0x00;
		req.msgType = MSG_KMAIL_SETTEXTBODY;

		std::string json = buildSetTextBodyReq(body);

		req.data->setSize(json.length()+1);
		strncpy((char *)req.data->getData(), json.c_str(), json.length()); 

		return reqAsync(KMAILSERVICE, &req, NULL);
	}

	/**
 	* @description: 获取文本主体
 	* @return: reqid，消息id。用于区分消息，与响应消息respid相同
 	*/ 
	int AsyncKmail::asyncGetTextBody() {
		kpkiReq req;
		req.version = 0x01;
		req.extend	= 0x00;
		req.msgType = MSG_KMAIL_GETTEXTBODY;

		return reqAsync(KMAILSERVICE, &req, NULL);
	}

	/**
 	* @description: 设置超文本主体
 	* @param {body} 超文本主体
 	* @return: reqid，消息id。用于区分消息，与响应消息respid相同
 	*/ 
	int AsyncKmail::asyncSetHtmlBody(const std::string & body) {
		kpkiReq req;
		req.version = 0x01;
		req.extend	= 0x00;
		req.msgType = MSG_KMAIL_SETHTMLBODY;

		std::string json = buildSetHtmlBodyReq(body);

		req.data->setSize(json.length()+1);
		strncpy((char *)req.data->getData(), json.c_str(), json.length()); 

		return reqAsync(KMAILSERVICE, &req, NULL);
	}

	/**
 	* @description: 获取超文本主体
 	* @return: reqid，消息id。用于区分消息，与响应消息respid相同
 	*/ 
	int AsyncKmail::asyncGetHtmlBody() {
		kpkiReq req;
		req.version = 0x01;
		req.extend	= 0x00;
		req.msgType = MSG_KMAIL_GETHTMLBODY;

		return reqAsync(KMAILSERVICE, &req, NULL);
	}

	/**
 	* @description: 邮件内容组合
 	* @param {devId} 设备ID
	* @param {appName} 应用名称
	* @param {conName} 容器名称
 	* @return: reqid，消息id。用于区分消息，与响应消息respid相同
 	*/ 
	int AsyncKmail::asyncCompose(const std::string & devId, const std::string &appName, const std::string &conName) {
		kpkiReq req;
		req.version = 0x01;
		req.extend	= 0x00;
		req.msgType = MSG_KMAIL_COMPOSE;

		std::string json = buildComposeReq(devId, appName, conName);
	
		req.data->setSize(json.length()+1);
		strncpy((char *)req.data->getData(), json.c_str(), json.length()); 

		return reqAsync(KMAILSERVICE, &req, NULL);
	}

	/**
 	* @description: 获取指定索引的数据包
 	* @param {index} 索引
 	* @return: reqid，消息id。用于区分消息，与响应消息respid相同
 	*/ 
	int AsyncKmail::asyncGetComposedData(const unsigned int & index) {
		kpkiReq req;
		req.version = 0x01;
		req.extend	= 0x00;
		req.msgType = MSG_KMAIL_GETCOMPOSEDDATA;

		std::string json = buildGetComposedDataReq(index);

		req.data->setSize(json.length()+1);
		strncpy((char *)req.data->getData(), json.c_str(), json.length()); 

		return reqAsync(KMAILSERVICE, &req, NULL);
	}

	/**
 	* @description: 准备解析邮件内容
 	* @param {index} 索引
	* @param {mail} 邮件内容
 	* @return: reqid，消息id。用于区分消息，与响应消息respid相同
 	*/ 
	int AsyncKmail::asyncPrepareParse(const unsigned int & index, const std::string &mail) {
		kpkiReq req;;
		req.version = 0x01;
		req.extend	= 0x00;
		req.msgType = MSG_KMAIL_PREPAREPARSE;

		std::string json = buildPrepareParseReq(index, mail);

		req.data->setSize(json.length()+1);
		strncpy((char *)req.data->getData(), json.c_str(), json.length()); 

		return reqAsync(KMAILSERVICE, &req, NULL);
	}

	/**
 	* @description: 解析邮件内容
 	* @param {devId} 设备id
	* @param {appName} 应用名称
	* @param {conName} 容器名称
 	* @return: reqid，消息id。用于区分消息，与响应消息respid相同
 	*/ 
	int AsyncKmail::asyncParse(const std::string & devId, const std::string &appName, const std::string &conName) {
		kpkiReq req;
		req.version = 0x01;
		req.extend	= 0x00;
		req.msgType = MSG_KMAIL_PARSE;

		std::string json = buildParseReq(devId, appName, conName);

		req.data->setSize(json.length()+1);
		strncpy((char *)req.data->getData(), json.c_str(), json.length()); 

		return reqAsync(KMAILSERVICE, &req, NULL);
	}

	/**
 	* @description: 清除邮件相关信息
 	* @return: reqid，消息id。用于区分消息，与响应消息respid相同
 	*/ 
	int AsyncKmail::asyncClear() {
		kpkiReq req;
		req.version = 0x01;
		req.extend	= 0x00;
		req.msgType = MSG_KMAIL_CLEAR;

		return reqAsync(KMAILSERVICE, &req, NULL);
	}

	/**
 	* @description: 添加附件
 	* @param {fileInfo} 附件信息
 	* @return: reqid，消息id。用于区分消息，与响应消息respid相同
 	*/ 
	int AsyncKmail::asyncAddAttachFile(const std::string fileInfo) {
		kpkiReq req;
		req.version = 0x01;
		req.extend	= 0x00;
		req.msgType = MSG_KMAIL_ADDATTACHFILE;

		std::string json = buildAddAttachFileReq(fileInfo);

		req.data->setSize(json.length()+1);
		strncpy((char *)req.data->getData(), json.c_str(), json.length()); 

		return reqAsync(KMAILSERVICE, &req, NULL);
	}

	/**
 	* @description: 获取附件数量
 	* @return: reqid，消息id。用于区分消息，与响应消息respid相同
 	*/ 
	int AsyncKmail::asyncGetAttachCount() {
		kpkiReq req;
		req.version = 0x01;
		req.extend	= 0x00;
		req.msgType = MSG_KMAIL_GETATTACHCOUNT;

		return reqAsync(KMAILSERVICE, &req, NULL);
	}

	/**
 	* @description: 获取指定附件信息
 	* @param {index} 索引
 	* @return: reqid，消息id。用于区分消息，与响应消息respid相同
 	*/ 
	int AsyncKmail::asyncGetAttachFileInfo(const unsigned int & index) {
		kpkiReq req;
		req.version = 0x01;
		req.extend	= 0x00;
		req.msgType = MSG_KMAIL_GETATTACHFILEINFO;

		std::string json = buildGetAttachFileInfoReq(index);

		req.data->setSize(json.length()+1);
		strncpy((char *)req.data->getData(), json.c_str(), json.length()); 

		return reqAsync(KMAILSERVICE, &req, NULL);
	}

	/**
 	* @description: 指定附件另存为
 	* @param {index} 索引
	* @param {filePath} 文件路径
 	* @return: reqid，消息id。用于区分消息，与响应消息respid相同
 	*/ 
	int AsyncKmail::asyncDoAttachSaveAs(const unsigned int & index, const std::string & filePath) {
		kpkiReq req;
		req.version = 0x01;
		req.extend	= 0x00;
		req.msgType = MSG_KMAIL_DOATTACHSAVEAS;

		std::string json = buildDoAttachSaveAsReq(index, filePath);

		req.data->setSize(json.length()+1);
		strncpy((char *)req.data->getData(), json.c_str(), json.length()); 

		return reqAsync(KMAILSERVICE, &req, NULL);
	}

	/**
 	* @description: 获取指定附件的指定扩展字段
 	* @param {index} 索引
 	* @return: reqid，消息id。用于区分消息，与响应消息respid相同
 	*/ 
	int AsyncKmail::asyncGetAttachFieldInfo(const unsigned int & index) {
		kpkiReq req;
		req.version = 0x01;
		req.extend	= 0x00;
		req.msgType = MSG_KMAIL_GETATTACHFIELDINFO;

		std::string json = buildGetAttachFieldInfoReq(index);

		req.data->setSize(json.length()+1);
		strncpy((char *)req.data->getData(), json.c_str(), json.length()); 

		return reqAsync(KMAILSERVICE, &req, NULL);
	}

	/**
 	* @description: 设置邮件类型
 	* @param {type} 邮件类型
 	* @return: reqid，消息id。用于区分消息，与响应消息respid相同
 	*/ 
	int AsyncKmail::asyncSetMailType(const unsigned int & type) {
		kpkiReq req;
		req.version = 0x01;
		req.extend	= 0x00;
		req.msgType = MSG_KMAIL_SETMAILTYPE;

		std::string json = buildSetMailTypeReq(type);

		req.data->setSize(json.length()+1);
		strncpy((char *)req.data->getData(), json.c_str(), json.length()); 

		return reqAsync(KMAILSERVICE, &req, NULL);
	}

	/**
 	* @description: 获取邮件类型
 	* @return: reqid，消息id。用于区分消息，与响应消息respid相同
 	*/ 
	int AsyncKmail::asyncGetMailType() {
		kpkiReq req;
		req.version = 0x01;
		req.extend	= 0x00;
		req.msgType = MSG_KMAIL_GETMAILTYPE;

		return reqAsync(KMAILSERVICE, &req, NULL);
	}

	/**
 	* @description: 设置加密证书
 	* @param {encCert} 证书内容
 	* @return: reqid，消息id。用于区分消息，与响应消息respid相同
 	*/ 
	int AsyncKmail::asyncSetEncCerts(const std::string & encCert) {
		kpkiReq req;
		req.version = 0x01;
		req.extend	= 0x00;
		req.msgType = MSG_KMAIL_SETENCCERTS;

		std::string json = buildSetEncCerts(encCert);

		req.data->setSize(json.length()+1);
		strncpy((char *)req.data->getData(), json.c_str(), json.length()); 

		return reqAsync(KMAILSERVICE, &req, NULL);
	}

	/**
 	* @description: 获取邮件中的签名证书
 	* @return: reqid，消息id。用于区分消息，与响应消息respid相同
 	*/ 
	int AsyncKmail::asyncGetMailSigner() {
		kpkiReq req;
		req.version = 0x01;
		req.extend	= 0x00;
		req.msgType = MSG_KMAIL_GETMAILSIGNER;

		return reqAsync(KMAILSERVICE, &req, NULL);
	}

	/**
 	* @description: 获取指定容器的签名证书
 	* @param {devId} 设备ID
	* @param {appName} 应用名称
	* @param {conName} 容器名称
 	* @return: reqid，消息id。用于区分消息，与响应消息respid相同
 	*/ 
	int AsyncKmail::asyncGetSignCert(const std::string & devId, const std::string &appName, const std::string &conName) {
		kpkiReq req;
		req.version = 0x01;
		req.extend	= 0x00;
		req.msgType = MSG_KMAIL_GETSIGNCERT;

		std::string json = buildGetSignCertReq(devId, appName, conName);

		req.data->setSize(json.length()+1);
		strncpy((char *)req.data->getData(), json.c_str(), json.length()); 

		return reqAsync(KMAILSERVICE, &req, NULL);
	}

	/**
 	* @description: 获取证书中的指定项的值
 	* @param {certb64} 证书内容
	* @param {key} 指定项
 	* @return: reqid，消息id。用于区分消息，与响应消息respid相同
 	*/ 
	int AsyncKmail::asyncGetCertItem(const std::string & certb64, const std::string & key) {
		kpkiReq req;
		req.version = 0x01;
		req.extend	= 0x00;
		req.msgType = MSG_KMAIL_GETCERTITEM;

		std::string json = buildGetCertItemReq(certb64, key);

		req.data->setSize(json.length()+1);
		strncpy((char *)req.data->getData(), json.c_str(), json.length()); 

		return reqAsync(KMAILSERVICE, &req, NULL);
	}

	/**
 	* @description: 签名
 	* @param {devId} 设备ID
	* @param {appName} 应用名称
	* @param {conName} 容器名称
	* @param {srcData} 待签名数据
	* @param {type} 1表示PM-BD签名,2表示SM2/RSA签名
 	* @return: reqid，消息id。用于区分消息，与响应消息respid相同
 	*/ 
	int AsyncKmail::asyncSignData(const std::string & devId, const std::string &appName, const std::string &conName,
		const std::string & srcData, const unsigned int & type) {
		kpkiReq req;
		req.version = 0x01;
		req.extend	= 0x00;
		req.msgType = MSG_KMAIL_SIGNDATA;

		std::string json = buildSignDataReq(devId, appName, conName, srcData, type);

		req.data->setSize(json.length()+1);
		strncpy((char *)req.data->getData(), json.c_str(), json.length()); 

		return reqAsync(KMAILSERVICE, &req, NULL);
	}
#endif
}  // namespace testAgent
}  // namespace koal