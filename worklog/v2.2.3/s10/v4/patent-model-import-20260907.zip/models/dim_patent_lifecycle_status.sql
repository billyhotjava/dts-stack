select
  cast(column1 as text) as patent_status_code,
  cast(column2 as text) as patent_status_name,
  cast(column3 as integer) as status_stage_order,
  cast(column4 as boolean) as is_active_status
from (
  values
    ('APPLICATION_SUBMITTED', '申请提交', 10, false),
    ('FORMALLY_ACCEPTED', '正式受理', 20, false),
    ('UNDER_EXAMINATION', '实质审查', 30, false),
    ('AUTHORIZED', '已授权', 40, true),
    ('MAINTAINED', '维持有效', 50, true),
    ('EXPIRED', '已失效', 60, false)
) as patent_statuses
