# 专利逆向建模离线验证包

该包用于离线 DTS 环境，仅包含 `dim_patent_lifecycle_status` 一个静态维度模型。业务分类为“研究所业务”，数据域编码为 `PATENT`。

## 离线边界

- 包内包含 dbt 项目源码和 `target/manifest.json`，不需要下载 dbt package。
- 不包含 `profiles.yml`、数据库地址、账号、密码或其他环境凭据。
- 不引用物理来源、现有 dbt 模型或 DTS ModelSpec。
- 包内携带“专利生命周期状态”维度定义蓝图；目标数据域不存在该定义时，导入事务会按稳定编码创建并确认，已存在时仅复用完全一致的定义。
- 4 个模型字段均显式映射到对应的业务维度属性，导入后应通过实现就绪门禁。
- 导入检查只读取 ZIP，不执行 SQL 或宏。

## 预期检查结果

- `CATALOG_MISSING`：离线验证包未连接目标数据库生成 `catalog.json`，该 WARNING 可忽略。
- `SQL_VALUES`、`SQL_CONSTANT`、`SQL_COMPLEX_EXPRESSION`：静态状态维度使用 `FROM (VALUES ...)` 内联常量产生，模型应以 `DBT_BACKED` 方式导入。
- 只有在页面显示“导入投影：IMPORTABLE”“可导入 1”“阻断 0”时才继续生成预览。

## 导入步骤

1. 在 DTS 逆向建模页面上传本 ZIP 并开始识别。
2. 选择已确认的规划上下文，将 `PATENT` 映射到目标“专利”数据域；无需预先手工创建维度定义。
3. 显式确认字段发布密级。
4. 确认预览为 `ready=1`、`blocked=0` 后生成模型。
5. 打开模型“交付检查”，确认 `IMPLEMENTATION_READY` 无属性映射阻断后即可物化。

导入后只生成模型草稿，不自动发布或物化。
