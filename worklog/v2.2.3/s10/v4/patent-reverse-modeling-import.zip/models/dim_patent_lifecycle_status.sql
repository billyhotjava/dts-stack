{{ config(materialized='table') }}

select
  cast(patent_status_code as text) as patent_status_code,
  cast(patent_status_name as text) as patent_status_name,
  cast(status_stage_order as integer) as status_stage_order,
  cast(is_active_status as boolean) as is_active_status
from (
  values
    ('APPLICATION_SUBMITTED', '申请提交', 10, false),
    ('FORMALLY_ACCEPTED', '正式受理', 20, false),
    ('UNDER_EXAMINATION', '实质审查', 30, false),
    ('AUTHORIZED', '已授权', 40, true),
    ('MAINTAINED', '维持有效', 50, true),
    ('EXPIRED', '已失效', 60, false)
) as patent_statuses(patent_status_code, patent_status_name, status_stage_order, is_active_status)
