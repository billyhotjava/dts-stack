# 专利逆向建模验证包

该包仅包含 `dim_patent_lifecycle_status` 一个静态维度模型，业务分类为“研究所业务”，数据域编码为 `PATENT`。

- 不引用物理来源。
- 不引用任何现有 dbt 模型或 DTS ModelSpec。
- 使用 DTS 已确认的“专利生命周期状态”维度定义。
- 用于验证 `dbt ZIP -> 检查 -> 预览 -> 应用 -> ModelSpec` 逆向建模链路。
