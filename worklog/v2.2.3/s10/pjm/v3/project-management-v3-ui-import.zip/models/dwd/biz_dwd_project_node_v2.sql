{{ config(materialized='table', tags=['project-management-v3', 'biz', 'dwd']) }}

SELECT
  -- === 主键 ===
  md5(
    COALESCE(btrim(o.project_no), '') || '|' ||
    COALESCE(btrim(o.subsystem), '') || '|' ||
    COALESCE(btrim(o.node_task), '') || '|' ||
    COALESCE(btrim(o.plan_date), '')
  ) AS node_id,

  -- === 原始业务字段 ===
  {{ nullif_placeholder("o.project_no") }}          AS project_no,
  {{ nullif_placeholder("o.subsystem") }}           AS subsystem,
  {{ nullif_placeholder("o.node_task") }}           AS node_task,
  {{ nullif_placeholder("o.owner") }}               AS owner,
  {{ nullif_placeholder("o.dept") }}                AS dept,
  {{ nullif_placeholder("o.dept_leader") }}         AS dept_leader,
  {{ nullif_placeholder("o.collab_dept") }}         AS collab_dept,
  {{ nullif_placeholder("o.supervisor_dept") }}     AS supervisor_dept,
  {{ nullif_placeholder("o.incomplete_reason") }}   AS incomplete_reason,
  {{ nullif_placeholder("o.risk_content") }}        AS risk_content,
  {{ nullif_placeholder("o.delay_impact") }}        AS delay_impact,
  {{ nullif_placeholder("o.institute_leader") }}    AS institute_leader,
  {{ nullif_placeholder("o.project_manager") }}     AS project_manager,
  {{ nullif_placeholder("o.filled_by") }}           AS filled_by,
  {{ nullif_placeholder("o.highlight") }}           AS highlight,
  {{ nullif_placeholder("o.deliverable") }}         AS deliverable,

  -- === 枚举标准化 ===
  {{ nullif_placeholder("o.completion_status") }}   AS completion_status,
  COALESCE(cs.is_completed, false)                  AS is_completed,
  COALESCE(cs.is_on_time, false)                    AS is_on_time,
  COALESCE(cs.is_overdue_completed, false)          AS is_overdue_completed,
  COALESCE(cs.is_incomplete, false)                 AS is_incomplete,
  COALESCE(cs.is_pending_normal, false)             AS is_pending_normal,
  COALESCE(cs.is_abnormal_pending, false)           AS is_abnormal_pending,
  COALESCE(cs.is_overdue_unchanged, false)          AS is_overdue_unchanged,
  COALESCE(cs.is_overdue_changed, false)            AS is_overdue_changed,
  COALESCE(cs.is_overdue_done_unchanged, false)     AS is_overdue_done_unchanged,
  COALESCE(cs.is_overdue_done_changed, false)       AS is_overdue_done_changed,
  -- 业务 4 大分类（含不正常待变更归并）
  COALESCE(cs.is_overdue_completed_effective, false)  AS is_overdue_completed_effective,
  COALESCE(cs.is_overdue_incomplete_effective, false) AS is_overdue_incomplete_effective,

  {{ nullif_placeholder("o.node_type") }}           AS node_type,
  COALESCE(nt.is_general, false)                    AS is_general_node,
  COALESCE(nt.is_important, false)                  AS is_important_node,
  COALESCE(nt.is_major, false)                      AS is_major_node,
  COALESCE(nt.is_milestone, false)                  AS is_milestone_node,

  {{ nullif_placeholder("o.risk_level") }}          AS risk_level,
  COALESCE(rl.is_high, false)                       AS is_high_risk,
  COALESCE(rl.is_mid, false)                        AS is_mid_risk,
  COALESCE(rl.is_low, false)                        AS is_low_risk,
  {{ nullif_placeholder("o.source") }}              AS data_source,
  {{ nullif_placeholder("o.delay_applied") }}       AS delay_applied,

  -- === 日期解析 ===
  {{ parse_date_safe("o.plan_start_date") }}        AS plan_start_date,
  {{ parse_date_safe("o.plan_date") }}              AS plan_date,
  {{ parse_date_safe("o.actual_start_date") }}      AS actual_start_date,
  {{ parse_date_safe("o.actual_date") }}            AS actual_date,
  {{ parse_date_safe("o.delay_expected_date") }}    AS delay_expected_date,
  {{ parse_date_safe("o.original_plan_date") }}     AS original_plan_date,
  {{ parse_date_safe("o.last_update_time") }}       AS last_update_time,

  -- === 周数 ===
  {{ parse_numeric_safe("o.plan_week") }}::int      AS plan_week,
  {{ parse_numeric_safe("o.actual_week") }}::int    AS actual_week,
  {{ parse_numeric_safe("o.last_update_week") }}::int AS last_update_week,

  -- === 时间维度标签 ===
  EXTRACT(YEAR FROM {{ parse_date_safe("o.plan_date") }})::int     AS plan_year,
  EXTRACT(QUARTER FROM {{ parse_date_safe("o.plan_date") }})::int  AS plan_quarter,
  to_char({{ parse_date_safe("o.plan_date") }}, 'YYYY-MM')         AS plan_month,

  EXTRACT(YEAR FROM {{ parse_date_safe("o.actual_date") }})::int   AS actual_year,
  to_char({{ parse_date_safe("o.actual_date") }}, 'YYYY-MM')       AS actual_month,

  -- === 衍生字段 ===
  CASE
    WHEN {{ parse_date_safe("o.plan_date") }} IS NOT NULL
     AND {{ parse_date_safe("o.actual_date") }} IS NOT NULL
    THEN ({{ parse_date_safe("o.actual_date") }} - {{ parse_date_safe("o.plan_date") }})::int
    WHEN {{ parse_date_safe("o.plan_date") }} IS NOT NULL
     AND {{ parse_date_safe("o.actual_date") }} IS NULL
     AND {{ parse_date_safe("o.plan_date") }} < current_date
    THEN (current_date - {{ parse_date_safe("o.plan_date") }})::int
  END AS delay_days,

  CASE
    WHEN {{ parse_date_safe("o.plan_date") }} IS NOT NULL
     AND {{ parse_date_safe("o.plan_date") }} <= current_date
    THEN true
    ELSE false
  END AS is_due,

  'ods_project_subject_domain_v2'::text AS source_table,
  now() AS etl_time

FROM {{ source('pm_ods_v2', 'project_subject_domain_v2') }} o
LEFT JOIN {{ ref('dim_completion_status_v2') }} cs
  ON cs.code = {{ nullif_placeholder("o.completion_status") }}
LEFT JOIN {{ ref('dim_node_type_v2') }} nt
  ON nt.code = {{ nullif_placeholder("o.node_type") }}
LEFT JOIN {{ ref('dim_risk_level_v2') }} rl
  ON rl.code = {{ nullif_placeholder("o.risk_level") }}
WHERE btrim(COALESCE(o.project_no, '')) != ''
  AND btrim(COALESCE(o.plan_date, '')) != ''
