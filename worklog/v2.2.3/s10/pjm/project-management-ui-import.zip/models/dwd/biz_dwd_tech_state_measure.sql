{{ config(materialized='table', tags=['project-management', 'biz', 'dwd', 'tech-state']) }}

SELECT
  -- === 主键 ===
  md5(
    COALESCE(btrim(o.project_no), '') || '|' ||
    COALESCE(btrim(o.tech_state_name), '') || '|' ||
    COALESCE(btrim(o.measure_title), '') || '|' ||
    COALESCE(btrim(o.follow_up_date), '')
  ) AS measure_id,

  -- === 技术状态主体字段 ===
  {{ nullif_placeholder("o.project_no") }}               AS project_no,
  {{ nullif_placeholder("o.tech_state_name") }}          AS tech_state_name,
  {{ nullif_placeholder("o.change_item") }}              AS change_item,
  {{ nullif_placeholder("o.owner") }}                    AS owner,
  {{ nullif_placeholder("o.dept") }}                     AS dept,
  {{ nullif_placeholder("o.dept_leader") }}              AS dept_leader,
  {{ nullif_placeholder("o.completion_signature") }}     AS completion_signature,
  {{ nullif_placeholder("o.change_reason") }}            AS change_reason,
  {{ nullif_placeholder("o.change_category") }}          AS change_category,
  {{ nullif_placeholder("o.plan_synced") }}              AS plan_synced,
  {{ nullif_placeholder("o.affected_files") }}           AS affected_files,
  {{ nullif_placeholder("o.affected_objects") }}         AS affected_objects,
  {{ nullif_placeholder("o.file_signature_status") }}    AS file_signature_status,
  {{ nullif_placeholder("o.reform_status") }}            AS reform_status,
  {{ nullif_placeholder("o.project_manager") }}          AS project_manager,

  -- === 跟进措施字段 ===
  {{ nullif_placeholder("o.measure_category") }}         AS measure_category,
  {{ nullif_placeholder("o.measure_title") }}            AS measure_title,
  {{ nullif_placeholder("o.follow_up_person") }}         AS follow_up_person,
  {{ nullif_placeholder("o.main_recipient") }}           AS main_recipient,
  {{ nullif_placeholder("o.cc_recipient") }}             AS cc_recipient,
  {{ nullif_placeholder("o.closure_status") }}           AS closure_status,
  {{ nullif_placeholder("o.closure_deliverable_type") }} AS closure_deliverable_type,
  {{ nullif_placeholder("o.closure_deliverable") }}      AS closure_deliverable,
  {{ nullif_placeholder("o.risk_content") }}             AS risk_content,
  {{ nullif_placeholder("o.remark") }}                   AS remark,
  {{ nullif_placeholder("o.filled_by") }}                AS filled_by,

  -- === 数值字段 ===
  {{ parse_numeric_safe("o.new_plan_count") }}::int      AS new_plan_count,

  -- === 日期解析 ===
  {{ parse_date_safe("o.change_submit_time") }}          AS change_submit_time,
  {{ parse_date_safe("o.signature_closure_date") }}      AS signature_closure_date,
  {{ parse_date_safe("o.plan_file_closure_date") }}      AS plan_file_closure_date,
  {{ parse_date_safe("o.plan_reform_date") }}            AS plan_reform_date,
  {{ parse_date_safe("o.follow_up_date") }}              AS follow_up_date,
  {{ parse_date_safe("o.final_closure_date") }}          AS final_closure_date,
  {{ parse_date_safe("o.last_update_time") }}            AS last_update_time,

  -- === 周数字段 ===
  {{ parse_numeric_safe("o.change_submit_week") }}::int          AS change_submit_week,
  {{ parse_numeric_safe("o.signature_closure_week") }}::int      AS signature_closure_week,
  {{ parse_numeric_safe("o.plan_file_closure_week") }}::int      AS plan_file_closure_week,
  {{ parse_numeric_safe("o.plan_reform_week") }}::int            AS plan_reform_week,
  {{ parse_numeric_safe("o.follow_up_week") }}::int              AS follow_up_week,
  {{ parse_numeric_safe("o.final_closure_week") }}::int          AS final_closure_week,
  {{ parse_numeric_safe("o.last_update_week") }}::int            AS last_update_week,

  -- === 闭环标志 ===
  CASE
    WHEN btrim(COALESCE({{ nullif_placeholder("o.closure_status") }}, '')) = '已闭环' THEN true
    ELSE false
  END AS is_closed,

  'ods_tech_state_measure'::text AS source_table,
  now() AS etl_time

FROM {{ source('pm_ods', 'tech_state_measure') }} o
WHERE o.project_no IS NOT NULL
  AND btrim(COALESCE(o.project_no, '')) != ''
