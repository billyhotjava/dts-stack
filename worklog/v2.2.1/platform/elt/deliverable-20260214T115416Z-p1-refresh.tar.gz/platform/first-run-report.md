# Platform 首轮实测回填报告

- 生成时间(UTC)：20260214T115349Z
- 观测窗口：最近 24 小时
- 模式：normal
- 架构：x86_64
- 时区标签：Asia/Shanghai

## 关键指标
- 总任务数：0
- 成功数：0
- 失败数：0
- 成功率：0%
- DAG 404 次数：0
- Task Log 404 次数：0

## 失败分类 Top
- collect_failed: 

## 原始数据
- 小时指标：
  `raw/hourly-metrics-20260214T115349Z.csv`
- 失败分类：
  `raw/failure-top-20260214T115349Z.csv`
- 采集摘要：
  `raw/summary-20260214T115349Z.txt`

## 结论（自动草稿）
- 当前窗口未采集到执行记录，请确认任务是否触发。
