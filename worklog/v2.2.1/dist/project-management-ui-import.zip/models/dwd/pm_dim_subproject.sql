{{ config(materialized='table', tags=['project-management', 'dim', 'project-cockpit', 'dwd']) }}

-- 从 ODS 节点数据自动推导子项目维度，无需 seed
WITH raw AS (
  SELECT
    NULLIF(btrim(o.project_no), '') AS project_no,
    NULLIF(btrim(o.subsystem), '') AS subsystem,
    CASE
      WHEN o.subsystem LIKE '%/%'
        THEN NULLIF(btrim(split_part(o.subsystem, '/', 2)), '')
      ELSE NULLIF(btrim(o.subsystem), '')
    END AS subproject_name,
    NULLIF(btrim(o.dept), '') AS dept,
    NULLIF(btrim(o.project_manager), '') AS project_manager,
    {{ parse_date_safe("o.plan_date") }} AS plan_date
  FROM {{ source('pm_ods', 'project_subject_domain') }} o
  WHERE btrim(COALESCE(o.project_no, '')) != ''
    AND btrim(COALESCE(o.subsystem, '')) != ''
)
SELECT
  md5(COALESCE(project_no, '') || '/' || COALESCE(subsystem, '')) AS subproject_id,
  project_no || '-' || left(COALESCE(subproject_name, ''), 8) AS subproject_code,
  subproject_name,
  project_no AS major_project_id,
  project_no,
  subsystem AS subsystem_name,
  dept AS owner_dept,
  '' AS owner_user,
  project_manager,
  min(plan_date) AS plan_start_date,
  max(plan_date) AS plan_end_date,
  NULL::date AS actual_end_date,
  '执行中' AS status,
  'A' AS priority_level,
  '' AS remark
FROM raw
GROUP BY project_no, subsystem, subproject_name, dept, project_manager
