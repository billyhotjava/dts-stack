{{ config(materialized='table', tags=['project-management', 'dim', 'project-cockpit', 'dwd']) }}

-- 从 ODS 节点数据自动推导重大项目维度，无需 seed
WITH raw AS (
  SELECT
    NULLIF(btrim(o.project_no), '') AS project_no,
    CASE
      WHEN o.subsystem LIKE '%/%'
        THEN NULLIF(btrim(split_part(o.subsystem, '/', 1)), '')
      ELSE NULLIF(btrim(o.subsystem), '')
    END AS major_project_name,
    NULLIF(btrim(o.dept), '') AS dept,
    NULLIF(btrim(o.dept_leader), '') AS dept_leader,
    {{ parse_date_safe("o.plan_date") }} AS plan_date
  FROM {{ source('pm_ods', 'project_subject_domain') }} o
  WHERE btrim(COALESCE(o.project_no, '')) != ''
)
SELECT
  project_no AS major_project_id,
  project_no AS major_project_code,
  major_project_name,
  'program-' || project_no AS program_id,
  major_project_name AS program_name,
  '重大项目' AS project_level,
  dept AS owner_dept,
  dept_leader AS owner_leader,
  'A' AS priority_level,
  min(plan_date) AS start_date,
  max(plan_date) AS plan_end_date,
  '执行中' AS status,
  '' AS remark
FROM raw
GROUP BY project_no, major_project_name, dept, dept_leader
