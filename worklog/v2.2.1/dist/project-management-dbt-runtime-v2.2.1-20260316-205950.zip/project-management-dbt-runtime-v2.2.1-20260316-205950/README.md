# 项目管理 dbt 运行包

来源：`project1.xlsx`（29 字段原始表）、`project2.xlsx`（枚举）、`project3.xlsx`（指标口径）。

使用说明：
1. 将现场真实 ODS 表通过 vars 绑定到逻辑源 `pm_ods.project_subject_domain`。
2. 推荐设置：`project_management_ods_schema`、`project_management_ods_table`。
3. 运行：`dbt seed && dbt build --select tag:project-management`。
