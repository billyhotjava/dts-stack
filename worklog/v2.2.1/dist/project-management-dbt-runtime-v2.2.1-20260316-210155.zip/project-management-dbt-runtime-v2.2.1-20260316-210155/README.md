# 项目管理 dbt 运行包

需求依据：`project1.xlsx`（29字段原始表）、`project2.xlsx`（枚举）、`project3.xlsx`（指标）。

运行时请通过 vars 绑定现场 ODS 表：
- `project_management_ods_schema`
- `project_management_ods_table`

推荐命令：`dbt seed && dbt build --select tag:project-management`。
